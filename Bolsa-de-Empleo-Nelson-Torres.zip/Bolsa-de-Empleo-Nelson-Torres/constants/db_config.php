<?php
$servername = "107.6.164.22";
$username = "granoblesapcolaa_bolsaempleoint";
$password = "(zio=}Uqny6j";
$dbname = "granoblesapcolaa_bolsaempleoint";
?>
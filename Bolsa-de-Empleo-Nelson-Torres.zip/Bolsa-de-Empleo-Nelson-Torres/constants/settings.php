<?php
$actual_link = $_SERVER['HTTP_HOST'];

// Definir la zona horaria (opcional, pero recomendable)
// Ajusta la zona horaria según tu ubicación (ejemplo: 'America/Mexico_City')
//date_default_timezone_set('America/Mexico_City');

// Configuración de SMTP para Gmail
$smtp_host = 'smtp.gmail.com';   // El servidor SMTP de Gmail
$smtp_user = 'bolsa.empleo@intsuperior.edu.ec'; // Tu dirección de correo Gmail
$smtp_pass = 'cbmi qxib oyyf jjce';     // Tu contraseña de Gmail (ver más abajo sobre la autenticación)

// Correo de contacto (puede ser el mismo correo de Gmail)
$contact_mail = 'bolsa.empleo@intsuperior.edu.ec';

?>


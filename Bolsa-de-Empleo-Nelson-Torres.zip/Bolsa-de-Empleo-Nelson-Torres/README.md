"# empleo-full" 
# Bolsa-de-Empleo-Nelson-Torres
Desarrollado por 

//////////////////////////////////////////////////////////////////

       ((())))     ||||    ||||      /|||\       (LL\\\\\\
      ((((())))    ||| |||| |||     ///  \\\     |||    )))
     (((      ))   |||  ||  |||    |||\\\\|||    |||\\\\\/
      ((((())))    |||      |||   |||      |||   |||   \\\
       (((()))     |||      |||  |||        |||  |||     \\

//////////////////////////////////////////////////////////////////
EmpleaTec fue desarrollada por Omar Sani y un equipo del Instituto Nelson Torres,bajo una base preEstablecida, integrando tecnologías con base de datos MySql para la autenticación y almacenamiento de datos, php para la lógica de la aplicación. BOOTRAP para la interfaz amigable y está optimizada para facilitar la navegación tanto para postulantes como para empresas.

EmpleaTec es una aplicación web y movil diseñada para facilitar la búsqueda de empleo para estudiantes y graduados del Instituto Nelson Torres. La aplicación está dirigida tanto a jóvenes profesionales en busca de su primera experiencia laboral como a empresas y departamentos de recursos humanos que buscan los mejores talentos emergentes. Los usuarios pueden registrarse, crear perfiles profesionales detallados, y acceder a oportunidades laborales publicadas por empresas. Los reclutadores pueden buscar y contactar directamente a candidatos adecuados para sus vacantes. 

Usando el Servidor Wampserver64  con la version 3.3.5 para levantar la aplicacion
php myadmin para gestionar la base de datos o Mysql

//Configuraciones Necesarias


Confifuracion a la base de datos
// contants/dbconfig.php


Configuracion de Gmail
// contans/settings.php

Para base de datos el archivo 
// Empleatec.db

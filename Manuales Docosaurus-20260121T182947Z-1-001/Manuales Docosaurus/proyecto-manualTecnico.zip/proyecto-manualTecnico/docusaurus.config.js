const config = {
  title: 'Mi Proyecto - Documentación',
  tagline: 'Manual Técnico y Guías',
  url: 'https://tu-dominio.com',
  baseUrl: '/',
  onBrokenLinks: 'throw',
  onBrokenMarkdownLinks: 'warn',
  favicon: 'img/favicon.ico',

  // Configuración de i18n (opcional)
  i18n: {
    defaultLocale: 'es',
    locales: ['es'],
  },

  presets: [
    [
      'classic',
      {
        docs: {
          sidebarPath: require.resolve('./sidebars.js'),
          // Ruta de edición (opcional)
          editUrl: 'https://github.com/tu-usuario/tu-repo/tree/main/',
        },
        blog: {
          showReadingTime: true,
          editUrl: 'https://github.com/tu-usuario/tu-repo/tree/main/',
        },
        theme: {
          customCss: require.resolve('./src/css/custom.css'),
        },
      },
    ],
  ],

  themeConfig: {
    navbar: {
      title: 'Mi Proyecto',
      logo: {
        alt: 'Logo',
        src: 'img/logo.svg',
      },
      items: [
        {
          type: 'doc',
          docId: 'intro',
          position: 'left',
          label: 'Documentación',
        },
        {
          type: 'doc',
          docId: 'manual-tecnico/introduccion',
          position: 'left',
          label: 'Manual Técnico',
        },
        {
          href: 'https://github.com/JuanChimarro/EmpleaTec.git',
          label: 'GitHub',
          position: 'right',
        },
      ],
    },
    footer: {
      style: 'dark',
      links: [
        {
          title: 'Documentación',
          items: [
            {
              label: 'Manual Técnico',
              to: '/docs/manual-tecnico/introduccion',
            },
            {
              label: 'Tutoriales',
              to: '/docs/intro',
            },
          ],
        },
        {
          title: 'Recursos',
          items: [
            {
              label: 'GitHub',
              href: 'https://github.com/JuanChimarro/EmpleaTec.git',
            },
          ],
        },
      ],
      copyright: `Copyright © ${new Date().getFullYear()} EmpleaTec. Construido con Docusaurus.`,
    },
  },
};

module.exports = config;
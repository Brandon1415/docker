# Requisitos de Software

Para el correcto funcionamiento y desarrollo de la plataforma EmpleaTec, es necesario contar con los siguientes requisitos de software.

## 1. Servidor Web

- **Software Recomendado**: Apache
- **Versión Sugerida**: Apache 2.4 o superior

## 2. Intérprete PHP

- **Software Recomendado**: PHP
- **Versión Sugerida**: PHP 7.4 o superior
- **Versión Mínima Soportada**: PHP 5.6 (ea-php56)

:::warning Compatibilidad
Aunque la plataforma funciona con PHP 5.6, se recomienda fuertemente usar PHP 7.4 o superior por razones de seguridad y rendimiento.
:::

## 3. Base de Datos

- **Software Recomendado**: MySQL
- **Versión Sugerida**: MySQL 5.7 o superior

## 4. Lenguajes y Librerías Frontend

### Lenguajes Base
- **HTML5**: Para la estructura del sitio web
- **CSS3 + Bootstrap 4/5**: Para el diseño responsivo y estilización
- **JavaScript + jQuery**: Para la interactividad y manejo dinámico de contenido

### Librerías PHP
- **PHPMailer**: Envío de correos electrónicos mediante protocolo SMTP
- **FPDF**: Generación de documentos en formato PDF desde la plataforma

## 5. Entorno de Desarrollo

### Sistema Operativo
Compatible con:
- Windows
- Linux
- macOS

### Servidor Local (para desarrollo)
Opciones recomendadas:
- **XAMPP** (recomendado para principiantes)
- **WAMP** (recomendado en el manual)
- **Laragon** (alternativa moderna)

### Editor de Código
- **Visual Studio Code** (recomendado)
- Sublime Text
- PHPStorm

### Navegadores Compatibles
- Google Chrome (últimas versiones)
- Mozilla Firefox (últimas versiones)
- Microsoft Edge (últimas versiones)

## Requisitos de Hardware Mínimos

| Componente | Especificación Mínima | Recomendado |
|------------|----------------------|-------------|
| Procesador | Intel Core i3 o equivalente | Intel Core i5 o superior |
| RAM | 4 GB | 8 GB o más |
| Disco Duro | 10 GB de espacio disponible | 20 GB o más |
| Conexión | Internet estable | Internet estable |

## Requisitos Adicionales

### Control de Versiones
- **Git**: Para control de versiones y clonación del repositorio
  - [Descargar Git](https://git-scm.com/downloads)

### Gestión de Dependencias (Opcional)
- **Composer**: Para gestión de dependencias PHP si se requiere en el futuro

## Requisitos para Producción

Para desplegar en un servidor de producción, asegúrate de tener:

- Certificado SSL/TLS (HTTPS)
- Acceso SSH al servidor
- Permisos de escritura en directorios específicos
- Configuración de cron jobs (si se requiere)
- Backup automático configurado

## Verificar Requisitos

Para verificar que tu entorno cumple con los requisitos:

### Verificar versión de PHP
```bash
php -v
```

### Verificar módulos PHP instalados
```bash
php -m
```

### Verificar versión de MySQL
```bash
mysql --version
```

### Verificar Apache (en Linux)
```bash
apache2 -v
```

---

**Siguiente paso**: Una vez verificados los requisitos, procede con la [Instalación](./instalacion.md).
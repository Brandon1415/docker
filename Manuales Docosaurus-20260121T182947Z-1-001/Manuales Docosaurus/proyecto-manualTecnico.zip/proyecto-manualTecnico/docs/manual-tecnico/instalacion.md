# Manual de Instalación Local

Esta guía describe los pasos necesarios para instalar y configurar la plataforma EmpleaTec en un entorno local.

## Requisitos Previos

Antes de comenzar, asegúrate de tener instalado:
- WAMP Server o XAMPP
- Git (para clonar el repositorio)
- Un editor de código (Visual Studio Code recomendado)

## Paso 1: Descargar el Proyecto

### Opción A: Clonar con Git (Recomendado)

#### 1.1 Instalar Git

Si aún no tienes Git instalado:

1. Descarga Git desde [https://git-scm.com/downloads](https://git-scm.com/downloads)
2. Selecciona tu sistema operativo (Windows, macOS, Linux)
3. Ejecuta el instalador
4. Sigue las instrucciones de instalación con las opciones por defecto

#### 1.2 Clonar el Repositorio

1. Crea una carpeta donde guardarás el proyecto (ejemplo: `C:/proyectos/`)

2. Haz clic derecho en la carpeta y selecciona **"Open Git Bash Here"** o **"Git Bash aquí"**

3. Se abrirá una ventana de terminal. Ejecuta el siguiente comando:

```bash
git clone https://github.com/JuanChimarro/EmpleaTec.git
```

4. Espera a que se complete la descarga. Verás una carpeta llamada `EmpleaTec`

### Opción B: Descargar ZIP

Si prefieres no usar Git:

1. Ve a [https://github.com/JuanChimarro/EmpleaTec](https://github.com/JuanChimarro/EmpleaTec)

2. Haz clic en el botón verde **"Code"**

3. Selecciona **"Download ZIP"**

4. Extrae el archivo ZIP en la carpeta de tu servidor local:
   - WAMP: `C:/wamp64/www/`
   - XAMPP: `C:/xampp/htdocs/`

## Paso 2: Configurar la Base de Datos

### 2.1 Iniciar el Servidor Local

1. Abre WAMP o XAMPP
2. Inicia los servicios de **Apache** y **MySQL**
3. Verifica que ambos estén en verde/corriendo

### 2.2 Acceder a phpMyAdmin

1. Abre tu navegador
2. Accede a: `http://localhost/phpmyadmin`
3. Inicia sesión (usuario por defecto: `root`, sin contraseña)

### 2.3 Crear la Base de Datos

1. En phpMyAdmin, haz clic en **"Nueva"** o **"New"** en el menú lateral

2. Ingresa el nombre de la base de datos: `empleatecsql`

3. Selecciona el cotejamiento: `utf8_general_ci` (recomendado)

4. Haz clic en **"Crear"**

### 2.4 Importar el Esquema

1. Selecciona la base de datos `empleatecsql` que acabas de crear

2. Haz clic en la pestaña **"Importar"**

3. Haz clic en **"Seleccionar archivo"** o **"Choose File"**

4. Busca el archivo SQL en el proyecto:
   - Generalmente está en: `EmpleaTec/database/empleatecsql.sql`
   - O busca un archivo `.sql` en la raíz del proyecto

5. Haz clic en **"Continuar"** o **"Go"**

6. Espera a que se complete la importación

:::tip Archivo SQL
Si no encuentras el archivo SQL, contacta al administrador del repositorio o revisa la carpeta `database/`, `sql/` o `docs/`.
:::

## Paso 3: Configurar la Conexión a la Base de Datos

### 3.1 Abrir el Proyecto en el Editor

1. Abre Visual Studio Code (o tu editor preferido)

2. Arrastra la carpeta `EmpleaTec` al editor, o:
   - Haz clic derecho en la carpeta
   - Selecciona **"Open with Code"** o **"Abrir con Visual Studio Code"**

Alternativamente, desde Git Bash en la carpeta del proyecto:

```bash
code .
```

### 3.2 Localizar el Archivo de Configuración

1. En el explorador de archivos del editor, navega a:
   ```
   EmpleaTec/
   └── Constants/
       └── db_config.php
   ```

2. Haz doble clic en `db_config.php` para abrirlo

### 3.3 Configurar las Credenciales

Actualiza el archivo con tus credenciales locales:

```php
<?php
$servername = "localhost";      // Servidor de la base de datos
$username = "root";              // Usuario por defecto de WAMP/XAMPP
$password = "";                  // Sin contraseña por defecto
$dbname = "empleatecsql";        // Nombre de la base de datos
?>
```

:::warning Credenciales de Producción
Estas son credenciales para desarrollo local. En producción, usa credenciales seguras y diferentes.
:::

4. Guarda los cambios con `Ctrl + S` (Windows/Linux) o `Cmd + S` (macOS)

## Paso 4: Configurar el Servidor SMTP (Opcional)

Para habilitar el envío de correos electrónicos:

### 4.1 Abrir Archivo de Configuración SMTP

1. Navega a: `EmpleaTec/Constants/settings.php`

2. Ábrelo en tu editor

### 4.2 Configurar Datos SMTP

Actualiza con tus datos de correo:

```php
<?php
$smtp_host = 'smtp.gmail.com';           // Servidor SMTP
$smtp_user = 'tuemail@gmail.com';        // Correo saliente
$smtp_pass = 'tucontraseña';             // Contraseña del correo
$contact_mail = 'contacto@empleatec.com'; // Correo de contacto
?>
```

### 4.3 Configuración para Gmail

Si usas Gmail, necesitas:

1. Ir a tu [Cuenta de Google](https://myaccount.google.com/)
2. Navegar a **Seguridad**
3. Activar **Verificación en dos pasos** (si no está activa)
4. Generar una **Contraseña de aplicación**:
   - Ve a **Contraseñas de aplicaciones**
   - Selecciona "Correo" y "Otro dispositivo"
   - Copia la contraseña generada
   - Úsala en `$smtp_pass`

:::tip Alternativas a Gmail
Puedes usar otros proveedores como:
- Outlook/Hotmail: `smtp.office365.com`
- Yahoo: `smtp.mail.yahoo.com`
- SMTP dedicado: Consulta con tu proveedor
:::

3. Guarda los cambios con `Ctrl + S`

## Paso 5: Configurar Permisos de Carpetas

Algunas carpetas necesitan permisos de escritura:

### En Windows (WAMP/XAMPP)

Generalmente no es necesario configurar permisos en Windows.

### En Linux/macOS

```bash
cd /ruta/a/EmpleaTec
chmod -R 755 uploads/
chmod -R 755 temp/
chmod -R 755 logs/
```

## Paso 6: Ejecutar la Plataforma

### 6.1 Iniciar Servicios

1. Asegúrate de que Apache y MySQL estén corriendo en WAMP/XAMPP

### 6.2 Acceder desde el Navegador

1. Abre tu navegador web

2. Accede a la URL local:

```
http://localhost/EmpleaTec/
```

O si instalaste en una subcarpeta diferente:

```
http://localhost/nombre-de-tu-carpeta/
```

3. Deberías ver la página de inicio de EmpleaTec

:::tip URL en Producción
En producción, la plataforma está disponible en: https://serviciosint.com/bolsadeempleo/
:::

### 6.3 Verificar Instalación

Verifica que:
- ✅ La página carga correctamente
- ✅ Los estilos CSS se aplican
- ✅ Puedes navegar entre secciones
- ✅ El formulario de login aparece

## Solución de Problemas Comunes

### Error de conexión a la base de datos

**Síntoma**: `Error establishing a database connection` o `Could not connect to database`

**Soluciones**:
1. Verifica que MySQL esté corriendo en WAMP/XAMPP
2. Confirma que las credenciales en `db_config.php` sean correctas
3. Asegúrate de que la base de datos `empleatecsql` exista
4. Verifica el nombre de usuario y contraseña en phpMyAdmin

### Error al importar la base de datos

**Síntoma**: Error al importar el archivo SQL en phpMyAdmin

**Soluciones**:
1. Verifica que el archivo SQL no esté corrupto
2. Aumenta los límites de importación en `php.ini`:
   ```ini
   upload_max_filesize = 64M
   post_max_size = 64M
   max_execution_time = 300
   ```
3. Si el archivo es muy grande, importa en partes
4. Usa la línea de comandos:
   ```bash
   mysql -u root -p empleatecsql < ruta/al/archivo.sql
   ```

### La página no carga estilos (CSS)

**Síntoma**: La página se ve sin estilos, solo texto plano

**Soluciones**:
1. Verifica que la ruta del proyecto sea correcta
2. Abre la consola del navegador (F12) y busca errores 404
3. Verifica que los archivos CSS estén en: `EmpleaTec/assets/css/`
4. Revisa las rutas en los archivos PHP (rutas relativas vs absolutas)

### Error 404 - Página no encontrada

**Síntoma**: Al acceder a una página aparece "404 Not Found"

**Soluciones**:
1. Verifica que el archivo exista en el proyecto
2. Revisa la configuración de Apache (`.htaccess`)
3. Asegúrate de que `mod_rewrite` esté habilitado en Apache
4. Verifica las rutas en el código

### Errores de PHP

**Síntoma**: Mensajes de error de PHP en pantalla

**Soluciones**:
1. Verifica que la versión de PHP sea compatible (7.4+)
2. Revisa los logs de PHP: `C:/wamp64/logs/php_error.log`
3. Activa el reporte de errores temporalmente en `php.ini`:
   ```ini
   display_errors = On
   error_reporting = E_ALL
   ```
4. Revisa que todas las extensiones PHP necesarias estén activas

### No se envían correos

**Síntoma**: Los correos electrónicos no llegan

**Soluciones**:
1. Verifica la configuración SMTP en `settings.php`
2. Asegúrate de usar una contraseña de aplicación (Gmail)
3. Revisa que el puerto SMTP sea correcto (587 o 465)
4. Verifica los logs de error de PHP
5. Prueba con un servicio SMTP de prueba como Mailtrap

## Configuración Adicional

### Configurar URL Base

Si la aplicación usa rutas absolutas, configura la URL base:

1. Busca el archivo de configuración general (puede variar)
2. Actualiza la constante de URL base:
   ```php
   define('BASE_URL', 'http://localhost/EmpleaTec/');
   ```

### Configurar Zona Horaria

En `php.ini` o en el código PHP:

```php
date_default_timezone_set('America/Guayaquil'); // Para Ecuador
```

## Siguientes Pasos

Una vez instalada la plataforma:

1. **Crea un usuario administrador** (si el sistema lo requiere)
2. **Revisa la configuración** en el panel de administración
3. **Prueba las funcionalidades** principales
4. **Lee la documentación de arquitectura** para entender el código
5. **Configura el entorno de desarrollo** según tus necesidades

---

**¿Problemas durante la instalación?** Revisa la sección de [Solución de Problemas](#solucion-de-problemas-comunes) o consulta los logs de error.
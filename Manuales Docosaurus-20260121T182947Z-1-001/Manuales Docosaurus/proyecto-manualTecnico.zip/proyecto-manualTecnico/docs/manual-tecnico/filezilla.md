---
sidebar_position: 2
title: Despliegue con FileZilla
---

# 📤 Despliegue con FileZilla

Esta guía te enseñará cómo desplegar tu proyecto Docusaurus en un servidor usando FileZilla.

---

## 📋 Requisitos Previos

Antes de comenzar, asegúrate de tener:

- ✅ FileZilla Client instalado ([Descargar aquí](https://filezilla-project.org/))
- ✅ Credenciales FTP/SFTP de tu servidor
- ✅ Proyecto Docusaurus construido (`npm run build`)

---

## 🛠️ Paso 1: Construir el Proyecto

### En tu computadora local:

```bash
# Navega a tu proyecto
cd C:\docusaurus\proyecto-manualUsuario

# Construye para producción
npm run build
```

:::tip Importante
Esto creará una carpeta `build/` con todos los archivos estáticos listos para desplegar.
:::

**Ubicación de los archivos:**
```
proyecto-manualUsuario/
└── build/               ← Esta carpeta es la que subirás
    ├── index.html
    ├── assets/
    ├── docs/
    ├── img/
    └── ...
```

---

## 🌐 Paso 2: Configurar FileZilla

### 2.1 Abrir Gestor de Sitios

1. Abre **FileZilla**
2. Ve a **Archivo → Gestor de sitios** (o `Ctrl + S`)
3. Haz clic en **"Nuevo sitio"**

<!-- ![Gestor de Sitios](/img/manual/filezilla-gestor.png) -->

### 2.2 Configurar Conexión

Completa los siguientes campos:

| Campo | Valor | Ejemplo |
|-------|-------|---------|
| **Protocolo** | FTP o SFTP | SFTP (más seguro) |
| **Servidor** | Dirección del servidor | `ftp.tudominio.com` o `192.168.1.100` |
| **Puerto** | 21 (FTP) o 22 (SFTP) | `22` |
| **Tipo de acceso** | Normal | Normal |
| **Usuario** | Tu usuario FTP | `usuario_ftp` |
| **Contraseña** | Tu contraseña | `********` |

:::warning Seguridad
- Usa **SFTP** cuando sea posible (más seguro que FTP)
- No compartas tus credenciales
- Usa contraseñas fuertes
:::

### 2.3 Configuración Avanzada (Opcional)

En la pestaña **"Configuración de transferencia"**:

- **Modo de transferencia**: Auto
- **Límite de conexiones simultáneas**: 2-4

En **"Avanzado"**:
- **Directorio remoto por defecto**: `/public_html` o `/htdocs` o `/www`

<!-- ![Configuración Avanzada](/img/manual/filezilla-config.png) -->

### 2.4 Guardar y Conectar

1. Haz clic en **"Conectar"**
2. Si aparece una advertencia de certificado (SFTP), verifica la huella digital y acepta

---

## 📂 Paso 3: Navegar en el Servidor

### 3.1 Ubicar la Carpeta Correcta

Una vez conectado, verás dos paneles:

- **Panel izquierdo**: Tu computadora local
- **Panel derecho**: El servidor remoto

**Carpetas comunes del servidor:**
```
/public_html/          ← Más común en cPanel
/htdocs/              ← Común en algunos hostings
/www/                 ← Alternativa
/var/www/html/        ← Servidores Linux
/home/usuario/public_html/  ← Hosting compartido
```

:::tip ¿Cuál usar?
Pregunta a tu proveedor de hosting o busca donde está el `index.html` actual de tu sitio.
:::

### 3.2 Limpiar Carpeta (Opcional)

Si ya tienes contenido anterior:

1. **Haz un backup** primero
2. Selecciona todos los archivos antiguos
3. Click derecho → **Eliminar**

:::warning ⚠️ Cuidado
Asegúrate de estar en la carpeta correcta antes de eliminar archivos.
:::

---

## 📤 Paso 4: Subir los Archivos

### 4.1 Preparar en Local

En el **panel izquierdo** (tu PC):

1. Navega a: `C:\docusaurus\proyecto-manualUsuario\build\`
2. Verás todos los archivos construidos

<!-- ![Panel Local](/img/manual/filezilla-local.png) -->

### 4.2 Subir Todo el Contenido

**Método 1: Seleccionar todo**

1. En el panel izquierdo, entra a la carpeta `build/`
2. Presiona `Ctrl + A` para seleccionar todo
3. Click derecho → **Subir** (o arrastra al panel derecho)

**Método 2: Arrastrar y soltar**

1. Selecciona todos los archivos y carpetas de `build/`
2. Arrástralos al panel derecho (servidor)

<!-- ![Subir Archivos](/img/manual/filezilla-upload.png) -->

:::info Progreso
En la parte inferior verás el progreso de la transferencia:
- Archivos en cola
- Archivos transferidos
- Velocidad de transferencia
:::

### 4.3 Esperar la Transferencia

⏱️ **Tiempo estimado:**
- Conexión rápida (100 Mbps): 2-5 minutos
- Conexión media (10 Mbps): 5-15 minutos
- Conexión lenta: 15+ minutos

:::warning No Interrumpir
No cierres FileZilla hasta que termine la transferencia.
:::

---

## ✅ Paso 5: Verificar el Despliegue

### 5.1 Estructura Final en el Servidor

Tu servidor debería verse así:

```
/public_html/
├── index.html           ← Página principal
├── 404.html            ← Página de error
├── assets/             ← CSS, JS, fuentes
├── docs/               ← Documentación generada
├── img/                ← Imágenes
├── sitemap.xml         ← Mapa del sitio
└── robots.txt          ← Reglas para bots
```

### 5.2 Comprobar Archivos Críticos

Verifica que estos archivos existan:

- ✅ `index.html`
- ✅ `404.html`
- ✅ Carpeta `assets/`
- ✅ Carpeta `docs/`
- ✅ Carpeta `img/`

### 5.3 Probar en el Navegador

1. Abre tu navegador
2. Ve a: `https://tudominio.com`
3. Deberías ver tu manual de usuario

**Rutas a probar:**
```
https://tudominio.com/                     → Página principal
https://tudominio.com/docs/intro           → Introducción
https://tudominio.com/docs/perfiles/       → Sección perfiles
```

:::tip Caché del Navegador
Si ves contenido antiguo, presiona `Ctrl + F5` para limpiar la caché.
:::

---

## 🔄 Paso 6: Actualizar el Sitio (Futuras Actualizaciones)

Cuando hagas cambios al manual:

### 6.1 En tu PC Local

```bash
# 1. Hacer cambios en los archivos .md
# 2. Probar localmente
npm start

# 3. Si todo está bien, construir de nuevo
npm run build
```

### 6.2 En FileZilla

**Opción A: Sobrescribir todo (Recomendado)**

1. Conecta con FileZilla
2. Sube la carpeta `build/` completa de nuevo
3. Cuando pregunte si sobrescribir, selecciona **"Sobrescribir"**

**Opción B: Solo archivos modificados**

1. En FileZilla, selecciona solo los archivos que cambiaron
2. Subirlos individualmente

:::tip Consejo
Es más seguro sobrescribir todo para evitar inconsistencias.
:::

---

## 🛡️ Configuraciones de Seguridad

### Permisos de Archivos

Los permisos correctos son:

| Tipo | Permisos | Numérico |
|------|----------|----------|
| **Carpetas** | `drwxr-xr-x` | `755` |
| **Archivos** | `-rw-r--r--` | `644` |

**Cambiar permisos en FileZilla:**

1. Click derecho en archivo/carpeta
2. **Permisos de archivo...**
3. Ingresa `755` para carpetas o `644` para archivos

<!-- ![Permisos](/img/manual/filezilla-permisos.png) -->

### .htaccess (Opcional)

Si tu servidor usa Apache, crea un archivo `.htaccess`:

```apache
# Redirigir HTTP a HTTPS
RewriteEngine On
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

# Caché de archivos estáticos
<IfModule mod_expires.c>
  ExpiresActive On
  ExpiresByType image/jpg "access plus 1 year"
  ExpiresByType image/jpeg "access plus 1 year"
  ExpiresByType image/png "access plus 1 year"
  ExpiresByType text/css "access plus 1 month"
  ExpiresByType application/javascript "access plus 1 month"
</IfModule>

# Compresión GZIP
<IfModule mod_deflate.c>
  AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css text/javascript application/javascript
</IfModule>
```

---

## ❌ Solución de Problemas

### Problema 1: No puedo conectarme

**Causas posibles:**

❌ Credenciales incorrectas
- **Solución**: Verifica usuario y contraseña

❌ Puerto bloqueado
- **Solución**: Verifica firewall, intenta puerto alternativo

❌ IP bloqueada
- **Solución**: Contacta a tu hosting para desbloquear tu IP

### Problema 2: Los archivos no se suben

**Causas posibles:**

❌ Sin permisos de escritura
- **Solución**: Verifica permisos del directorio remoto

❌ Espacio en disco lleno
- **Solución**: Elimina archivos antiguos o amplía el espacio

❌ Límite de tamaño de archivo
- **Solución**: Sube archivos más pequeños o ajusta límites del servidor

### Problema 3: El sitio muestra error 404

**Soluciones:**

1. Verifica que `index.html` esté en la raíz correcta
2. Revisa las rutas en el navegador
3. Comprueba configuración de Apache/Nginx

### Problema 4: CSS/JS no carga

**Soluciones:**

1. Verifica que la carpeta `assets/` se haya subido
2. Revisa permisos de la carpeta `assets/`
3. Limpia caché del navegador (`Ctrl + F5`)

### Problema 5: Enlaces rotos

**Soluciones:**

1. Verifica el `baseUrl` en `docusaurus.config.js`
2. Reconstruye el proyecto: `npm run build`
3. Sube de nuevo

---

## 📊 Verificación Post-Despliegue

### Checklist Final

Usa esta lista para verificar que todo funciona:

- [ ] Página principal carga correctamente
- [ ] Sidebar de navegación funciona
- [ ] Enlaces internos funcionan
- [ ] Imágenes se muestran (si las tienes)
- [ ] Búsqueda funciona (si está habilitada)
- [ ] Responsive design funciona en móvil
- [ ] No hay errores en consola del navegador (F12)
- [ ] SSL/HTTPS activo (candado verde)

### Herramientas de Verificación

**Google PageSpeed Insights:**
```
https://pagespeed.web.dev/
```

**GTmetrix:**
```
https://gtmetrix.com/
```

---

## 🚀 Optimizaciones Adicionales

### CDN (Opcional)

Para mejorar velocidad, considera usar un CDN:

- Cloudflare (gratuito)
- AWS CloudFront
- Google Cloud CDN

### Configuración de DNS

Asegúrate de que tu dominio apunte correctamente:

```
Tipo A:    @ → IP_DEL_SERVIDOR
Tipo A:    www → IP_DEL_SERVIDOR
```

---

## 📝 Comandos Útiles de FileZilla

| Acción | Atajo |
|--------|-------|
| **Conectar** | `Ctrl + C` |
| **Desconectar** | `Ctrl + D` |
| **Actualizar** | `F5` |
| **Subir** | `Ctrl + U` |
| **Descargar** | `Ctrl + Shift + D` |
| **Eliminar** | `Delete` |
| **Renombrar** | `F2` |


**Última actualización**: Enero 2026
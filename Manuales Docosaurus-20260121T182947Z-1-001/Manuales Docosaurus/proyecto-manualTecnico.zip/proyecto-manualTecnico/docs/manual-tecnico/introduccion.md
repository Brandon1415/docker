# Introducción

## Objetivo del Proyecto

Desarrollar una plataforma tecnológica híbrida (web y móvil) de acceso abierto y administrativa de uso cerrado, que facilite la inserción laboral de recién graduados y el acceso a datos de la plataforma para el Instituto Nelson Torres.

La plataforma integra módulos interactivos que permiten:
- Visualización de reportes generales de los graduados
- Conexión eficiente con departamentos de Recursos Humanos
- Búsqueda de talento especializado

## Tecnologías Utilizadas

La plataforma EmpleaTec ha sido desarrollada utilizando las siguientes tecnologías:

### Frontend
- **HTML5**: Lenguaje de marcado para la estructura y contenido
- **JavaScript (JS)**: Programación para interactividad y funcionalidad dinámica
- **Bootstrap**: Framework CSS para diseño responsivo
- **jQuery**: Manejo dinámico de contenido

### Backend
- **PHP**: Lenguaje de programación del lado del servidor
- **MySQL**: Sistema de gestión de bases de datos relacional

### Librerías Adicionales
- **PHPMailer**: Envío de correos electrónicos mediante SMTP
- **FPDF**: Generación de documentos en formato PDF

## Características Principales

- ✅ Plataforma híbrida (web y móvil)
- ✅ Gestión de perfiles de graduados
- ✅ Sistema de publicación de ofertas laborales
- ✅ Reportes y estadísticas
- ✅ Conexión directa con empleadores

## Alcance del Manual

Este manual técnico está diseñado para:
- Desarrolladores que necesiten instalar, mantener o extender la plataforma
- Administradores de sistemas encargados del despliegue
- Personal técnico del Instituto Nelson Torres

---

**Versión del Manual**: 1.0  
**Última Actualización**: Enero 2025
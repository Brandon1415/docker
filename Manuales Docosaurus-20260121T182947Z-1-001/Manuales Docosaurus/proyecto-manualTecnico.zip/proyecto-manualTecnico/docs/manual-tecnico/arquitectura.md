# Arquitectura del Sistema

La arquitectura del proyecto EmpleaTec sigue un modelo basado en **MVC (Modelo-Vista-Controlador)** con una estructura modular que separa la lógica del negocio, la presentación y la gestión de datos.

## Estructura General del Proyecto

```
EmpleaTec/
├── app/                          # Lógica de aplicación
├── constants/                    # Archivos de configuración
│   ├── db_config.php            # Configuración de BD
│   └── settings.php             # Configuración SMTP
├── employee/                     # Módulo de empleados
│   ├── register.php             # Registro
│   ├── profile.php              # Perfil
│   ├── search.php               # Búsqueda de empleos
│   └── applications.php         # Aplicaciones
├── employer/                     # Módulo de empleadores
│   ├── register.php             # Registro empresas
│   ├── dashboard.php            # Panel de control
│   ├── post_job.php             # Publicar ofertas
│   └── candidates.php           # Gestión candidatos
├── admin/                        # Panel administrativo
├── assets/                       # Recursos estáticos
│   ├── css/                     # Hojas de estilo
│   ├── js/                      # JavaScript
│   ├── images/                  # Imágenes
│   └── vendor/                  # Librerías de terceros
├── uploads/                      # Archivos subidos
│   ├── cvs/                     # Currículums
│   └── photos/                  # Fotos de perfil
├── includes/                     # Archivos incluidos
│   ├── header.php               # Encabezado común
│   ├── footer.php               # Pie de página común
│   └── functions.php            # Funciones globales
├── index.php                     # Página principal
├── login.php                     # Inicio de sesión
├── register.php                  # Registro
├── job_list.php                  # Lista de empleos
└── .htaccess                     # Configuración Apache
```

## Patrón de Diseño: MVC

### Modelo (Model)

Representa la capa de datos y lógica de negocio.

**Responsabilidades:**
- Interacción con la base de datos
- Validación de datos
- Reglas de negocio
- Consultas SQL

**Ubicación típica:**
- `app/models/`
- Clases PHP que representan entidades

**Ejemplo de estructura:**
```php
class Employee {
    private $db;
    
    public function __construct() {
        $this->db = new Database();
    }
    
    public function getById($id) {
        // Lógica de consulta
    }
    
    public function create($data) {
        // Lógica de inserción
    }
}
```

### Vista (View)

Representa la capa de presentación.

**Responsabilidades:**
- Mostrar datos al usuario
- Interfaces HTML
- Renderizado de contenido
- Interacción con el usuario

**Ubicación típica:**
- Archivos `.php` en las carpetas principales
- `employee/`, `employer/`, etc.

**Características:**
- Uso de PHP embebido en HTML
- Bootstrap para diseño responsivo
- JavaScript/jQuery para interactividad

### Controlador (Controller)

Actúa como intermediario entre Modelo y Vista.

**Responsabilidades:**
- Procesar solicitudes del usuario
- Invocar métodos del modelo
- Seleccionar la vista apropiada
- Manejar la lógica de aplicación

**Ubicación típica:**
- `app/controllers/`
- Archivos PHP que procesan formularios

## Componentes Principales

### 1. Sistema de Autenticación

**Archivos relacionados:**
- `login.php` - Formulario de inicio de sesión
- `register.php` - Formulario de registro
- `logout.php` - Cierre de sesión
- `includes/auth.php` - Funciones de autenticación

**Flujo de autenticación:**
```mermaid
graph TD
    A[Usuario ingresa credenciales] --> B{Validar datos}
    B -->|Válido| C[Consultar BD]
    B -->|Inválido| D[Mostrar error]
    C --> E{Usuario existe?}
    E -->|Sí| F[Verificar contraseña]
    E -->|No| D
    F -->|Correcta| G[Crear sesión]
    F -->|Incorrecta| D
    G --> H[Redirigir a dashboard]
```

**Seguridad implementada:**
- Hashing de contraseñas (MD5/SHA256/bcrypt)
- Sesiones PHP
- Validación de entradas
- Prevención de inyección SQL

### 2. Gestión de Base de Datos

**Archivo de conexión:** `constants/db_config.php`

```php
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "empleatecsql";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
```

**Patrón de uso:**
```php
// Incluir configuración
require_once 'constants/db_config.php';

// Prepared statement para seguridad
$stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
```

### 3. Módulo de Empleados (employee/)

**Estructura:**
```
employee/
├── index.php           # Dashboard del empleado
├── register.php        # Registro de cuenta
├── profile.php         # Ver/editar perfil
├── edit_profile.php    # Formulario de edición
├── search_jobs.php     # Búsqueda de empleos
├── job_detail.php      # Detalle de oferta
├── apply_job.php       # Procesar aplicación
├── applications.php    # Mis aplicaciones
├── messages.php        # Mensajería
├── notifications.php   # Notificaciones
└── settings.php        # Configuración
```

**Funcionalidades principales:**

#### Gestión de Perfil
- Actualizar información personal
- Subir foto de perfil
- Agregar experiencia laboral
- Agregar educación
- Gestionar habilidades
- Cargar CV (PDF)

#### Búsqueda de Empleo
- Búsqueda por palabra clave
- Filtros avanzados:
  - Ubicación
  - Tipo de empleo
  - Salario
  - Fecha de publicación
- Guardar ofertas favoritas
- Compartir ofertas

#### Sistema de Aplicaciones
- Postularse a ofertas
- Seguimiento de estado
- Cancelar aplicaciones
- Ver historial

### 4. Módulo de Empleadores (employer/)

**Estructura:**
```
employer/
├── index.php           # Dashboard del empleador
├── register.php        # Registro de empresa
├── profile.php         # Perfil de empresa
├── post_job.php        # Publicar oferta
├── edit_job.php        # Editar oferta
├── my_jobs.php         # Mis ofertas
├── candidates.php      # Ver candidatos
├── candidate_detail.php # Detalle de candidato
├── search_talent.php   # Buscar talento
├── messages.php        # Mensajería
└── reports.php         # Reportes
```

**Funcionalidades principales:**

#### Gestión de Ofertas
- Crear nuevas ofertas
- Editar ofertas existentes
- Pausar/reactivar ofertas
- Cerrar vacantes
- Estadísticas por oferta

#### Gestión de Candidatos
- Ver aplicaciones recibidas
- Filtrar candidatos
- Cambiar estados
- Descargar CVs
- Contactar candidatos

#### Búsqueda Activa
- Buscar en base de datos
- Filtros por habilidades
- Invitar a aplicar

### 5. Panel Administrativo (admin/)

**Estructura:**
```
admin/
├── index.php           # Dashboard admin
├── users.php           # Gestión de usuarios
├── jobs.php            # Aprobar/moderar ofertas
├── reports.php         # Reportes generales
├── settings.php        # Configuración del sistema
└── logs.php            # Logs de actividad
```

**Funcionalidades:**
- Aprobar cuentas de empleadores
- Moderar ofertas de empleo
- Gestionar usuarios
- Generar reportes
- Configurar parámetros del sistema

## Base de Datos

### Diagrama ER Simplificado

```
┌─────────────────┐         ┌─────────────────┐
│     users       │         │   employees     │
├─────────────────┤         ├─────────────────┤
│ id (PK)         │────────<│ user_id (FK)    │
│ email           │         │ first_name      │
│ password        │         │ last_name       │
│ user_type       │         │ phone           │
│ created_at      │         │ cv_path         │
└─────────────────┘         │ photo_path      │
                            └─────────────────┘
        │
        │
        ▼
┌─────────────────┐         ┌─────────────────┐
│   employers     │         │      jobs       │
├─────────────────┤         ├─────────────────┤
│ user_id (FK)    │────────<│ id (PK)         │
│ company_name    │         │ employer_id (FK)│
│ ruc             │         │ title           │
│ address         │         │ description     │
│ phone           │         │ requirements    │
└─────────────────┘         │ salary          │
                            │ location        │
                            │ status          │
                            └─────────────────┘
                                    │
                                    │
                                    ▼
                            ┌─────────────────┐
                            │  applications   │
                            ├─────────────────┤
                            │ id (PK)         │
                            │ job_id (FK)     │
                            │ employee_id (FK)│
                            │ status          │
                            │ applied_date    │
                            └─────────────────┘
```

### Tablas Principales

#### Tabla: `users`
```sql
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    user_type ENUM('employee', 'employer', 'admin'),
    status ENUM('active', 'inactive', 'pending'),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### Tabla: `employees`
```sql
CREATE TABLE employees (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    phone VARCHAR(20),
    date_of_birth DATE,
    address TEXT,
    cv_path VARCHAR(255),
    photo_path VARCHAR(255),
    FOREIGN KEY (user_id) REFERENCES users(id)
);
```

#### Tabla: `employers`
```sql
CREATE TABLE employers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    company_name VARCHAR(255),
    ruc VARCHAR(50),
    address TEXT,
    phone VARCHAR(20),
    website VARCHAR(255),
    description TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
```

#### Tabla: `jobs`
```sql
CREATE TABLE jobs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employer_id INT,
    title VARCHAR(255),
    description TEXT,
    requirements TEXT,
    salary_min DECIMAL(10,2),
    salary_max DECIMAL(10,2),
    location VARCHAR(255),
    job_type ENUM('full-time', 'part-time', 'internship'),
    status ENUM('active', 'closed', 'pending'),
    deadline DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employer_id) REFERENCES employers(id)
);
```

#### Tabla: `applications`
```sql
CREATE TABLE applications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    job_id INT,
    employee_id INT,
    status ENUM('sent', 'reviewing', 'shortlisted', 'rejected', 'hired'),
    cover_letter TEXT,
    applied_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (job_id) REFERENCES jobs(id),
    FOREIGN KEY (employee_id) REFERENCES employees(id)
);
```

### Relaciones

- **users → employees**: 1:1 (Un usuario empleado tiene un perfil)
- **users → employers**: 1:1 (Un usuario empleador tiene un perfil)
- **employers → jobs**: 1:N (Un empleador puede publicar muchas ofertas)
- **jobs → applications**: 1:N (Una oferta puede tener muchas aplicaciones)
- **employees → applications**: 1:N (Un empleado puede tener muchas aplicaciones)

## Flujo de Datos

### Flujo de Aplicación a Empleo

```mermaid
sequenceDiagram
    participant E as Empleado
    participant V as Vista (job_detail.php)
    participant C as Controlador (apply_job.php)
    participant M as Modelo (Application)
    participant BD as Base de Datos
    
    E->>V: Ve detalle de oferta
    E->>V: Click en "Postularme"
    V->>C: POST application data
    C->>M: create($job_id, $employee_id, $data)
    M->>BD: INSERT INTO applications
    BD-->>M: Application ID
    M-->>C: Success
    C-->>V: Redirect to applications
    V-->>E: Confirmación de aplicación
```

## Configuraciones Importantes

### .htaccess

Configuración de Apache para URLs amigables:

```apache
RewriteEngine On
RewriteBase /

# Redirigir a HTTPS (en producción)
# RewriteCond %{HTTPS} off
# RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

# Ocultar extensión .php
RewriteCond %{REQUEST_FILENAME} !-d
RewriteCond %{REQUEST_FILENAME}.php -f
RewriteRule ^(.*)$ $1.php [L]

# Proteger archivos de configuración
<FilesMatch "^(db_config|settings)\.php$">
    Order allow,deny
    Deny from all
</FilesMatch>
```

### php.ini (Configuraciones recomendadas)

```ini
; Límites de carga
upload_max_filesize = 10M
post_max_size = 10M

; Límites de ejecución
max_execution_time = 300
memory_limit = 256M

; Zona horaria
date.timezone = America/Guayaquil

; Reportar errores (desarrollo)
display_errors = On
error_reporting = E_ALL

; Reportar errores (producción)
; display_errors = Off
; error_reporting = E_ALL & ~E_DEPRECATED & ~E_STRICT
; log_errors = On
; error_log = /ruta/a/logs/php_error.log
```

## Seguridad

### Medidas Implementadas

1. **Autenticación y Autorización**
   - Sesiones PHP seguras
   - Verificación de permisos por rol
   - Tokens anti-CSRF (recomendado implementar)

2. **Prevención de Inyección SQL**
   - Uso de prepared statements
   - Validación de entradas
   - Escape de caracteres especiales

3. **Protección de Contraseñas**
   - Hashing (bcrypt recomendado)
   - No almacenar en texto plano
   - Requisitos de complejidad

4. **Validación de Archivos**
   - Verificación de tipos permitidos
   - Límite de tamaño
   - Nombres de archivo sanitizados

5. **Protección de Datos**
   - HTTPS en producción
   - Sanitización de salidas
   - Headers de seguridad

### Recomendaciones Adicionales

```php
// Prevenir clickjacking
header('X-Frame-Options: SAMEORIGIN');

// Prevenir XSS
header('X-XSS-Protection: 1; mode=block');

// Forzar tipo de contenido
header('X-Content-Type-Options: nosniff');

// Política de contenido (CSP)
header("Content-Security-Policy: default-src 'self'");
```

## Escalabilidad

### Consideraciones para Crecimiento

1. **Caché**
   - Implementar Redis o Memcached
   - Caché de consultas frecuentes
   - Caché de sesiones

2. **CDN**
   - Servir recursos estáticos desde CDN
   - Reducir carga del servidor

3. **Optimización de Base de Datos**
   - Índices en columnas frecuentes
   - Particionamiento de tablas grandes
   - Consultas optimizadas

4. **Balanceo de Carga**
   - Múltiples servidores web
   - Load balancer (Nginx/HAProxy)

5. **Microservicios**
   - Separar servicios críticos
   - API RESTful
   - Comunicación asíncrona

---

**Siguiente sección**: [Conclusiones y Recomendaciones](./conclusiones.md)
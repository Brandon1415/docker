export default [
  require("C:\\docusaurus\\proyecto-manualTecnico\\node_modules\\infima\\dist\\css\\default\\default.css"),
  require("C:\\docusaurus\\proyecto-manualTecnico\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages"),
  require("C:\\docusaurus\\proyecto-manualTecnico\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress"),
  require("C:\\docusaurus\\proyecto-manualTecnico\\src\\css\\custom.css"),
];

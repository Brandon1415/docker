export default [
  require("C:\\docusaurus\\proyecto-manualInstalacion\\.docusaurus\\docusaurus-plugin-css-cascade-layers\\default\\layers.css"),
  require("C:\\docusaurus\\proyecto-manualInstalacion\\node_modules\\infima\\dist\\css\\default\\default.css"),
  require("C:\\docusaurus\\proyecto-manualInstalacion\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages"),
  require("C:\\docusaurus\\proyecto-manualInstalacion\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress"),
  require("C:\\docusaurus\\proyecto-manualInstalacion\\src\\css\\custom.css"),
];

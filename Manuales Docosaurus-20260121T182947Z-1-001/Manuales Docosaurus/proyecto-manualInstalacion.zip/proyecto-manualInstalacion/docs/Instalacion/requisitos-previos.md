# Requisitos Previos

Antes de instalar EmpleaTec, asegúrate de tener todos los requisitos necesarios en tu sistema.

## 🖥️ Requisitos de Hardware

### Entorno de Desarrollo (Local)

| Componente | Mínimo | Recomendado |
|------------|--------|-------------|
| **Procesador** | Intel Core i3 / AMD equivalente | Intel Core i5 o superior |
| **RAM** | 4 GB | 8 GB o más |
| **Disco Duro** | 10 GB libres | 20 GB SSD |
| **Conexión Internet** | 5 Mbps | 10 Mbps o más |

### Entorno de Producción (Servidor)

| Componente | Mínimo | Recomendado |
|------------|--------|-------------|
| **CPU** | 2 cores | 4+ cores |
| **RAM** | 4 GB | 8 GB o más |
| **Disco** | 50 GB SSD | 100 GB SSD |
| **Ancho de Banda** | 100 Mbps | 1 Gbps |

## 💻 Requisitos de Software

### 1. Sistema Operativo

EmpleaTec es compatible con:

**Para Desarrollo Local:**
- ✅ Windows 10/11
- ✅ macOS 10.15 (Catalina) o superior
- ✅ Linux (Ubuntu 20.04+, Debian 10+, CentOS 8+)

**Para Producción:**
- ✅ Ubuntu Server 20.04 LTS o superior (recomendado)
- ✅ Debian 10 o superior
- ✅ CentOS/RHEL 8 o superior
- ✅ Amazon Linux 2

### 2. Servidor Web

**Apache HTTP Server**
- Versión mínima: 2.4.x
- Versión recomendada: 2.4.52 o superior

**Módulos Apache requeridos:**
```bash
# Verificar módulos instalados
apache2 -M  # Linux
httpd -M    # CentOS/RHEL

# Módulos necesarios:
- mod_rewrite   # Para URLs amigables
- mod_headers   # Para headers de seguridad
- mod_ssl       # Para HTTPS (producción)
- mod_expires   # Para caché del navegador
```

**Alternativa: Nginx**
- Versión: 1.18 o superior (si prefieres Nginx sobre Apache)

### 3. PHP

**Versión PHP:**
- Mínima soportada: PHP 5.6
- Recomendada: PHP 7.4 o superior
- Ideal: PHP 8.0+ (mejor rendimiento)

:::warning Seguridad
PHP 5.6 ya no recibe actualizaciones de seguridad. Se recomienda encarecidamente usar PHP 7.4 o superior.
:::

**Extensiones PHP Requeridas:**

```bash
# Verificar extensiones instaladas
php -m

# Extensiones necesarias:
✓ mysqli         # Conexión MySQL/MariaDB
✓ pdo_mysql      # PDO para MySQL
✓ mbstring       # Manejo de strings multibyte
✓ json           # Manejo de JSON
✓ curl           # Peticiones HTTP
✓ openssl        # Encriptación y SSL
✓ fileinfo       # Información de archivos
✓ gd o imagick   # Procesamiento de imágenes
✓ zip            # Manejo de archivos ZIP
```

**Configuración PHP (php.ini):**

```ini
# Límites de carga de archivos
upload_max_filesize = 10M
post_max_size = 10M
max_file_uploads = 20

# Límites de ejecución
max_execution_time = 300
max_input_time = 300
memory_limit = 256M

# Zona horaria (ajustar según ubicación)
date.timezone = America/Guayaquil

# Manejo de errores (desarrollo)
display_errors = On
error_reporting = E_ALL

# Manejo de errores (producción)
display_errors = Off
error_reporting = E_ALL & ~E_DEPRECATED & ~E_STRICT
log_errors = On
error_log = /var/log/php/error.log

# Sesiones
session.gc_maxlifetime = 1440
session.cookie_httponly = 1
session.cookie_secure = 1  # Si usas HTTPS
```

### 4. Base de Datos

**MySQL**
- Versión mínima: 5.7
- Versión recomendada: 8.0+

**O MariaDB** (alternativa compatible)
- Versión mínima: 10.3
- Versión recomendada: 10.6+

**Configuración MySQL (my.cnf):**

```ini
[mysqld]
# Codificación de caracteres
character-set-server = utf8mb4
collation-server = utf8mb4_unicode_ci

# Límites
max_connections = 150
max_allowed_packet = 64M

# InnoDB (motor recomendado)
default-storage-engine = InnoDB
innodb_buffer_pool_size = 1G  # Ajustar según RAM disponible
innodb_log_file_size = 256M

# Consultas lentas (para optimización)
slow_query_log = 1
slow_query_log_file = /var/log/mysql/slow-query.log
long_query_time = 2
```

### 5. Herramientas de Desarrollo

**Git** (Control de versiones)
- Versión: 2.x o superior
- Descargar: https://git-scm.com/downloads

**Composer** (Gestor de dependencias PHP - opcional)
- Versión: 2.x
- Descargar: https://getcomposer.org/

**Node.js y npm** (Para herramientas frontend - opcional)
- Node.js: 14.x o superior
- npm: 6.x o superior
- Descargar: https://nodejs.org/

### 6. Servidor de Correo SMTP

Para el envío de correos electrónicos necesitarás:

**Opciones:**
- Gmail con contraseña de aplicación
- SendGrid (gratuito hasta 100 emails/día)
- Amazon SES
- Mailgun
- SMTP corporativo propio

**Información necesaria:**
```
SMTP Host: smtp.example.com
SMTP Port: 587 (TLS) o 465 (SSL)
SMTP User: usuario@example.com
SMTP Password: contraseña_segura
```

## 🛠️ Herramientas Recomendadas

### Para Desarrollo Local

**Servidores Locales Todo-en-Uno:**

1. **XAMPP** (Recomendado para principiantes)
   - Incluye: Apache, MySQL, PHP, phpMyAdmin
   - Plataformas: Windows, Linux, macOS
   - Descarga: https://www.apachefriends.org/

2. **WAMP** (Solo Windows)
   - Incluye: Apache, MySQL, PHP
   - Descarga: https://www.wampserver.com/

3. **MAMP** (macOS y Windows)
   - Incluye: Apache, MySQL, PHP
   - Descarga: https://www.mamp.info/

4. **Laragon** (Windows - Moderno)
   - Incluye: Apache/Nginx, MySQL, PHP
   - Descarga: https://laragon.org/

### Editores de Código

**Visual Studio Code** (Recomendado)
- Gratuito y potente
- Extensiones útiles:
  - PHP Intelephense
  - PHP Debug
  - MySQL
  - GitLens
- Descarga: https://code.visualstudio.com/

**Alternativas:**
- PHPStorm (Pago, muy completo)
- Sublime Text
- Atom
- Notepad++

### Gestores de Base de Datos

1. **phpMyAdmin** (Web)
   - Incluido en XAMPP/WAMP
   - Acceso: http://localhost/phpmyadmin

2. **MySQL Workbench** (Desktop)
   - Oficial de MySQL
   - Descarga: https://www.mysql.com/products/workbench/

3. **DBeaver** (Desktop)
   - Gratuito, soporta múltiples BD
   - Descarga: https://dbeaver.io/

4. **HeidiSQL** (Windows)
   - Ligero y rápido
   - Descarga: https://www.heidisql.com/

## ✅ Verificar Requisitos

### Script de Verificación PHP

Crea un archivo `check_requirements.php` en tu servidor web:

```php
<?php
/**
 * Script de verificación de requisitos para EmpleaTec
 */

echo "<h1>Verificación de Requisitos - EmpleaTec</h1>";

// Versión PHP
echo "<h2>1. Versión PHP</h2>";
$phpVersion = phpversion();
echo "Versión instalada: <strong>$phpVersion</strong><br>";
if (version_compare($phpVersion, '7.4.0', '>=')) {
    echo "✅ Cumple con requisitos (7.4+)<br>";
} elseif (version_compare($phpVersion, '5.6.0', '>=')) {
    echo "⚠️ Funcional pero desactualizado (mínimo 5.6)<br>";
} else {
    echo "❌ No cumple requisitos mínimos<br>";
}

// Extensiones PHP
echo "<h2>2. Extensiones PHP</h2>";
$required_extensions = [
    'mysqli', 'pdo_mysql', 'mbstring', 'json', 
    'curl', 'openssl', 'fileinfo', 'gd', 'zip'
];

foreach ($required_extensions as $ext) {
    if (extension_loaded($ext)) {
        echo "✅ $ext<br>";
    } else {
        echo "❌ $ext (NO INSTALADA)<br>";
    }
}

// Configuración PHP
echo "<h2>3. Configuración PHP</h2>";
echo "upload_max_filesize: " . ini_get('upload_max_filesize') . "<br>";
echo "post_max_size: " . ini_get('post_max_size') . "<br>";
echo "memory_limit: " . ini_get('memory_limit') . "<br>";
echo "max_execution_time: " . ini_get('max_execution_time') . " segundos<br>";

// Permisos de escritura
echo "<h2>4. Permisos de Escritura</h2>";
$test_file = 'test_write.txt';
if (is_writable('.')) {
    file_put_contents($test_file, 'test');
    if (file_exists($test_file)) {
        echo "✅ Permisos de escritura OK<br>";
        unlink($test_file);
    }
} else {
    echo "❌ Sin permisos de escritura en directorio actual<br>";
}

// Conexión MySQL
echo "<h2>5. Conexión MySQL</h2>";
echo "⚠️ Configurar credenciales y probar manualmente<br>";

echo "<h2>✅ Verificación Completa</h2>";
echo "<p>Revisa los resultados arriba para asegurarte de cumplir todos los requisitos.</p>";
?>
```

Accede a: `http://localhost/check_requirements.php`

### Verificar desde Terminal

**Linux/macOS:**

```bash
# Versión PHP
php -v

# Extensiones PHP
php -m

# Versión MySQL
mysql --version

# Versión Apache
apache2 -v   # Ubuntu/Debian
httpd -v     # CentOS/RHEL

# Git
git --version

# Espacio en disco
df -h
```

**Windows (PowerShell):**

```powershell
# Versión PHP (si está en PATH)
php -v

# MySQL
mysql --version

# Espacio en disco
Get-PSDrive C
```

## 📦 Instalación de Requisitos

### Ubuntu/Debian

```bash
# Actualizar repositorios
sudo apt update
sudo apt upgrade -y

# Instalar Apache
sudo apt install apache2 -y

# Instalar PHP y extensiones
sudo apt install php php-mysqli php-mbstring php-json php-curl \
                 php-openssl php-fileinfo php-gd php-zip -y

# Instalar MySQL
sudo apt install mysql-server -y

# Instalar Git
sudo apt install git -y

# Habilitar módulos Apache
sudo a2enmod rewrite
sudo a2enmod headers
sudo systemctl restart apache2
```

### CentOS/RHEL

```bash
# Instalar Apache
sudo yum install httpd -y
sudo systemctl start httpd
sudo systemctl enable httpd

# Instalar PHP (repositorio Remi)
sudo yum install epel-release -y
sudo yum install https://rpms.remirepo.net/enterprise/remi-release-8.rpm -y
sudo yum module enable php:remi-7.4 -y
sudo yum install php php-mysqli php-mbstring php-json php-curl \
                 php-openssl php-gd php-zip -y

# Instalar MySQL
sudo yum install mysql-server -y
sudo systemctl start mysqld
sudo systemctl enable mysqld

# Git
sudo yum install git -y
```

### macOS (con Homebrew)

```bash
# Instalar Homebrew (si no lo tienes)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Instalar PHP
brew install php@7.4

# Instalar MySQL
brew install mysql
brew services start mysql

# Apache (ya incluido en macOS)
sudo apachectl start

# Git (ya incluido en macOS)
git --version
```

### Windows

**Opción 1: XAMPP (Recomendado)**
1. Descarga XAMPP: https://www.apachefriends.org/
2. Ejecuta el instalador
3. Selecciona componentes: Apache, MySQL, PHP, phpMyAdmin
4. Instala en `C:\xampp`
5. Inicia Apache y MySQL desde el Panel de Control

**Opción 2: Manual**
- Descargar e instalar cada componente individualmente
- Configurar PATH de sistema para PHP y MySQL

## 🔍 Problemas Comunes

### PHP no reconocido en terminal

**Solución Windows:**
1. Agregar PHP al PATH del sistema
2. Panel de Control > Sistema > Variables de entorno
3. Agregar: `C:\xampp\php` (o ruta donde instalaste PHP)

**Solución Linux:**
```bash
# Verificar instalación
which php

# Si no está instalado
sudo apt install php-cli
```

### Módulo Apache no carga

```bash
# Verificar módulos disponibles
apache2ctl -M

# Habilitar módulo
sudo a2enmod rewrite
sudo systemctl restart apache2
```

### MySQL no inicia

```bash
# Verificar estado
sudo systemctl status mysql

# Ver logs
sudo tail -f /var/log/mysql/error.log

# Reiniciar servicio
sudo systemctl restart mysql
```

## ✅ Checklist Final

Antes de continuar con la instalación, verifica:

- [ ] Sistema operativo compatible instalado
- [ ] Apache o Nginx funcionando
- [ ] PHP 7.4+ instalado con todas las extensiones
- [ ] MySQL/MariaDB instalado y funcionando
- [ ] Git instalado
- [ ] Acceso root/administrador para configuración
- [ ] Conexión a Internet estable
- [ ] Editor de código instalado
- [ ] Espacio en disco suficiente (mínimo 10 GB)

---

**Siguiente paso**: Una vez verificados todos los requisitos, continúa con la [Instalación Principal](./instalacion-principal.md).
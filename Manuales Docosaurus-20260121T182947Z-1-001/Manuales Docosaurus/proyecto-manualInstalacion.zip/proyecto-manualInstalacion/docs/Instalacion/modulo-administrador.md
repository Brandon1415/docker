# Módulo Administrador

Guía de instalación y configuración del panel administrativo de EmpleaTec.

## 📍 Ubicación del Módulo

El módulo administrativo se encuentra en:
```
EmpleaTec/
└── Administrador-Bolsa-de-Empleo/
    ├── admin/
    ├── assets/
    ├── config/
    ├── includes/
    ├── index.php
    └── login.php
```

## 🌐 Acceso al Panel Administrativo

### URL de Acceso

**Desarrollo Local:**
- XAMPP: `http://localhost/EmpleaTec/Administrador-Bolsa-de-Empleo/`
- WAMP: `http://localhost/EmpleaTec/Administrador-Bolsa-de-Empleo/`
- Con VirtualHost: `http://empleatec.local/Administrador-Bolsa-de-Empleo/`

**Producción:**
- `https://serviciosint.com/bolsadeempleo/admin/`
- O la URL que configures para administración

:::warning Seguridad
En producción, considera usar una URL no obvia para el panel de administración, como:
- `/gestion-interna/`
- `/panel-control/`
- `/backend-access/`
:::

## 🔐 Configuración Inicial

### 1. Conexión a Base de Datos

El módulo administrador usa la misma configuración de BD que la aplicación principal.

Verifica que existe: `Administrador-Bolsa-de-Empleo/config/db_config.php`

```php
<?php
/**
 * Configuración de Base de Datos - Módulo Administrador
 */

$servername = "localhost";
$username = "root";                // O el usuario que creaste
$password = "";                    // O la contraseña correspondiente
$dbname = "empleatecsql";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Configurar charset
$conn->set_charset("utf8mb4");

// Zona horaria
date_default_timezone_set('America/Guayaquil');
?>
```

### 2. Crear Usuario Administrador

#### Opción A: Desde phpMyAdmin

1. Accede a phpMyAdmin: `http://localhost/phpmyadmin`
2. Selecciona la base de datos `empleatecsql`
3. Ve a la tabla `users`
4. Haz clic en "Insertar"
5. Completa los datos:

```
email: admin@empleatec.com
password: (genera hash MD5 o usa función de PHP)
user_type: admin
status: active
email_verified: 1
```

**Para generar password hash:**

```php
<?php
// Crear archivo temp_hash.php
$password = 'Admin123!';

// MD5 (básico - no recomendado para producción)
echo "MD5: " . md5($password) . "<br>";

// SHA256 (mejor)
echo "SHA256: " . hash('sha256', $password) . "<br>";

// bcrypt (recomendado para producción)
echo "bcrypt: " . password_hash($password, PASSWORD_BCRYPT) . "<br>";
?>
```

#### Opción B: Mediante SQL

```sql
-- Usar MD5 (compatible con sistema actual)
INSERT INTO users (email, password, user_type, status, email_verified) 
VALUES ('admin@empleatec.com', MD5('Admin123!'), 'admin', 'active', 1);

-- O con SHA256
INSERT INTO users (email, password, user_type, status, email_verified) 
VALUES ('admin@empleatec.com', SHA2('Admin123!', 256), 'admin', 'active', 1);

-- Verificar inserción
SELECT id, email, user_type FROM users WHERE user_type = 'admin';
```

#### Opción C: Script de Instalación

Crea `create_admin.php` en el directorio del módulo administrador:

```php
<?php
require_once 'config/db_config.php';

// Datos del administrador
$admin_email = 'admin@empleatec.com';
$admin_password = 'Admin123!'; // Cambiar después del primer login

// Verificar si ya existe
$check = $conn->query("SELECT id FROM users WHERE email = '$admin_email'");

if ($check->num_rows > 0) {
    echo "❌ El usuario administrador ya existe<br>";
    echo "Email: $admin_email<br>";
    echo "Usa la opción de recuperar contraseña si la olvidaste.";
} else {
    // Crear usuario administrador
    $password_hash = md5($admin_password);
    
    $sql = "INSERT INTO users (email, password, user_type, status, email_verified) 
            VALUES (?, ?, 'admin', 'active', 1)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $admin_email, $password_hash);
    
    if ($stmt->execute()) {
        echo "✅ Usuario administrador creado exitosamente<br><br>";
        echo "📧 Email: $admin_email<br>";
        echo "🔑 Contraseña: $admin_password<br><br>";
        echo "⚠️ <strong>IMPORTANTE:</strong> Cambia esta contraseña después del primer login<br><br>";
        echo "<a href='login.php'>Ir al Login Administrativo</a>";
    } else {
        echo "❌ Error al crear usuario: " . $conn->error;
    }
}

$conn->close();
?>
```

Accede a: `http://localhost/EmpleaTec/Administrador-Bolsa-de-Empleo/create_admin.php`

:::danger Eliminar Después
**Elimina** el archivo `create_admin.php` después de crear el administrador por seguridad.
:::

## 🎛️ Funcionalidades del Panel Administrativo

### Dashboard Principal

Al iniciar sesión verás:

```
┌─────────────────────────────────────────────────┐
│  Dashboard Administrativo - EmpleaTec            │
├─────────────────────────────────────────────────┤
│                                                  │
│  📊 Estadísticas Generales                      │
│  ┌──────────┬──────────┬──────────┬──────────┐ │
│  │ Usuarios │ Empleados│ Empresas │  Ofertas │ │
│  │   Total  │  Activos │  Activas │  Activas │ │
│  │   1,245  │    856   │    89    │   142    │ │
│  └──────────┴──────────┴──────────┴──────────┘ │
│                                                  │
│  📈 Resumen del Mes                             │
│  • Nuevos registros: 45 empleados, 8 empresas   │
│  • Ofertas publicadas: 23                        │
│  • Aplicaciones: 456                             │
│  • Tasa de éxito: 12% (contrataciones)         │
│                                                  │
│  ⚠️ Acciones Pendientes                         │
│  • 5 empresas pendientes de aprobación          │
│  • 3 ofertas en revisión                        │
│  • 12 reportes sin revisar                      │
│                                                  │
└─────────────────────────────────────────────────┘
```

### Módulos Administrativos

#### 1. Gestión de Usuarios

**Funcionalidades:**
- Listar todos los usuarios (empleados, empresas, admins)
- Ver detalles completos de cada usuario
- Activar/desactivar cuentas
- Eliminar usuarios
- Resetear contraseñas
- Enviar notificaciones masivas

**Acceso:** `admin/users.php` o similar

#### 2. Gestión de Empleados

**Funcionalidades:**
- Ver lista de graduados registrados
- Filtrar por carrera, año de graduación, ubicación
- Ver perfiles completos
- Verificar información
- Generar reportes de inserción laboral
- Exportar datos a Excel/PDF

**Reportes disponibles:**
- Graduados por carrera
- Tasa de inserción laboral
- Tiempo promedio para conseguir empleo
- Salarios promedio por carrera
- Graduados por año

#### 3. Gestión de Empresas

**Funcionalidades:**
- Aprobar/rechazar solicitudes de registro
- Ver información completa de empresas
- Verificar documentación (RUC, representante)
- Activar/suspender cuentas empresariales
- Ver historial de publicaciones
- Estadísticas por empresa

**Proceso de aprobación:**
```
1. Nueva empresa se registra
2. Aparece en "Pendientes de Aprobación"
3. Administrador revisa:
   - Documentación (RUC, cédula)
   - Información de contacto
   - Legitimidad de la empresa
4. Aprobar o Rechazar con motivo
5. Empresa recibe notificación por correo
```

#### 4. Gestión de Ofertas

**Funcionalidades:**
- Ver todas las ofertas (activas, cerradas, pendientes)
- Aprobar/rechazar ofertas publicadas
- Moderar contenido inapropiado
- Editar ofertas si es necesario
- Cerrar ofertas vencidas
- Ver estadísticas de cada oferta

**Criterios de moderación:**
- Información clara y veraz
- Salario acorde al mercado
- Sin discriminación
- Empresa legítima verificada
- Requisitos realistas

#### 5. Reportes y Estadísticas

**Tipos de reportes:**

1. **Reporte General:**
   - Usuarios totales y activos
   - Ofertas publicadas por período
   - Aplicaciones totales
   - Tasa de éxito (contrataciones)

2. **Reporte de Empleados:**
   - Graduados por carrera
   - Inserción laboral por período
   - Tiempo promedio de búsqueda
   - Salarios por carrera
   - Ubicación de empleos

3. **Reporte de Empresas:**
   - Empresas más activas
   - Sectores que más contratan
   - Ofertas por empresa
   - Tasa de respuesta a candidatos

4. **Reporte Financiero:**
   - Ingresos por suscripciones (si aplica)
   - Planes contratados
   - Renovaciones

**Exportar reportes:**
- PDF para impresión
- Excel para análisis
- CSV para procesamiento

#### 6. Configuración del Sistema

**Opciones configurables:**

```php
// config/settings.php

// General
define('SITE_NAME', 'EmpleaTec');
define('ADMIN_EMAIL', 'admin@empleatec.com');
define('SUPPORT_EMAIL', 'soporte@empleatec.com');

// Límites
define('MAX_FILE_SIZE', 5 * 1024 * 1024);  // 5MB
define('MAX_APPLICATIONS_PER_DAY', 10);
define('MAX_JOB_DURATION', 30);  // días

// Aprobaciones
define('REQUIRE_EMPLOYER_APPROVAL', true);
define('REQUIRE_JOB_APPROVAL', true);

// Notificaciones
define('NOTIFY_NEW_APPLICATIONS', true);
define('NOTIFY_NEW_EMPLOYER', true);
```

#### 7. Logs de Actividad

Ver registros de:
- Inicios de sesión
- Cambios en perfiles
- Ofertas publicadas
- Aplicaciones enviadas
- Acciones administrativas
- Errores del sistema

```sql
-- Ver logs recientes
SELECT * FROM activity_logs 
ORDER BY created_at DESC 
LIMIT 100;

-- Ver logs de un usuario específico
SELECT * FROM activity_logs 
WHERE user_id = 123 
ORDER BY created_at DESC;

-- Ver logs por acción
SELECT * FROM activity_logs 
WHERE action = 'login_failed' 
ORDER BY created_at DESC;
```

## 🔒 Seguridad del Panel Administrativo

### 1. Restricción de Acceso

```php
// includes/admin_auth.php

session_start();

function checkAdminAuth() {
    if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
        header('Location: login.php');
        exit();
    }
}

// Verificar en cada página administrativa
checkAdminAuth();
```

### 2. Protección con .htaccess

Crea `.htaccess` en el directorio del módulo administrador:

```apache
# Protección adicional para el panel de administración

# Denegar acceso directo a archivos de configuración
<FilesMatch "^(config|db_config|settings)\.php$">
    Order allow,deny
    Deny from all
</FilesMatch>

# Limitar acceso por IP (producción)
# Descomenta y ajusta las IPs permitidas
#<Limit GET POST>
#    Order deny,allow
#    Deny from all
#    Allow from 192.168.1.100  # IP de la oficina
#    Allow from 203.0.113.0    # IP del administrador
#</Limit>

# Proteger contra inyección SQL
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteCond %{QUERY_STRING} [a-zA-Z0-9_]=http:// [OR]
    RewriteCond %{QUERY_STRING} [a-zA-Z0-9_]=(\.\.//?)+ [OR]
    RewriteCond %{QUERY_STRING} [a-zA-Z0-9_]=/([a-z0-9_.]//?)+ [NC,OR]
    RewriteCond %{QUERY_STRING} \=PHP[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12} [NC,OR]
    RewriteCond %{QUERY_STRING} (\.\./|\.\.) [OR]
    RewriteCond %{QUERY_STRING} ftp\: [NC,OR]
    RewriteCond %{QUERY_STRING} http\: [NC,OR]
    RewriteCond %{QUERY_STRING} https\: [NC,OR]
    RewriteCond %{QUERY_STRING} \=\|w\| [NC,OR]
    RewriteCond %{QUERY_STRING} ^(.*)/self/(.*)$ [NC,OR]
    RewriteCond %{QUERY_STRING} ^(.*)cPath=http://(.*)$ [NC,OR]
    RewriteCond %{QUERY_STRING} (\<|%3C).*script.*(\>|%3E) [NC,OR]
    RewriteCond %{QUERY_STRING} (<|%3C)([^s]*s)+cript.*(>|%3E) [NC,OR]
    RewriteCond %{QUERY_STRING} (\<|%3C).*iframe.*(\>|%3E) [NC,OR]
    RewriteCond %{QUERY_STRING} (<|%3C)([^i]*i)+frame.*(>|%3E) [NC,OR]
    RewriteCond %{QUERY_STRING} base64_encode.*\(.*\) [NC,OR]
    RewriteCond %{QUERY_STRING} base64_(en|de)code[^(]*\([^)]*\) [NC,OR]
    RewriteCond %{QUERY_STRING} GLOBALS(=|\[|\%[0-9A-Z]{0,2}) [OR]
    RewriteCond %{QUERY_STRING} _REQUEST(=|\[|\%[0-9A-Z]{0,2}) [OR]
    RewriteCond %{QUERY_STRING} ^.*(\[|\]|\(|\)|<|>).* [NC,OR]
    RewriteCond %{QUERY_STRING} (NULL|OUTFILE|LOAD_FILE) [OR]
    RewriteCond %{QUERY_STRING} (\./|\../|\.;/|\.\.;/).*\.* [NC,OR]
    RewriteCond %{QUERY_STRING} (;|<|>|'|"|\)|%0A|%0D|%22|%27|%3C|%3E|%00).*(/\*|union|select|insert|drop|delete|update|cast|create|char|convert|alter|declare|order|script|set|md5|benchmark|encode) [NC,OR]
    RewriteCond %{QUERY_STRING} (sp_executesql) [NC]
    RewriteRule ^(.*)$ - [F,L]
</IfModule>

# Deshabilitar listado de directorios
Options -Indexes

# Proteger archivos sensibles
<Files "error_log">
    Order allow,deny
    Deny from all
</Files>
```

### 3. Autenticación de Dos Factores (Recomendado)

Para mayor seguridad en producción, implementa 2FA.

```php
// Ejemplo básico con código enviado por email

// Al hacer login exitoso
$verification_code = rand(100000, 999999);
$_SESSION['temp_user_id'] = $user_id;
$_SESSION['2fa_code'] = $verification_code;
$_SESSION['2fa_expiry'] = time() + (10 * 60);  // 10 minutos

// Enviar código por email
sendEmail($user_email, "Código de Verificación", "Tu código es: $verification_code");

// Redirigir a página de verificación
header('Location: verify_2fa.php');
```

### 4. Registro de Accesos Administrativos

```php
// Log cada acción administrativa
function logAdminAction($admin_id, $action, $description = '') {
    global $conn;
    
    $ip = $_SERVER['REMOTE_ADDR'];
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    
    $stmt = $conn->prepare(
        "INSERT INTO activity_logs (user_id, action, description, ip_address, user_agent) 
         VALUES (?, ?, ?, ?, ?)"
    );
    $stmt->bind_param("issss", $admin_id, $action, $description, $ip, $user_agent);
    $stmt->execute();
}

// Uso
logAdminAction($_SESSION['user_id'], 'approve_employer', "Approved company: TechCorp");
logAdminAction($_SESSION['user_id'], 'delete_user', "Deleted user ID: 123");
```

## 🎨 Personalización del Panel

### Cambiar Logo y Colores

```css
/* assets/css/admin-custom.css */

/* Logo del panel */
.admin-logo {
    background-image: url('../images/logo-admin.png');
    width: 200px;
    height: 60px;
}

/* Colores corporativos */
:root {
    --primary-color: #3498db;
    --secondary-color: #2c3e50;
    --success-color: #27ae60;
    --danger-color: #e74c3c;
    --warning-color: #f39c12;
}

.sidebar {
    background-color: var(--secondary-color);
}

.btn-primary {
    background-color: var(--primary-color);
}
```

### Agregar Módulo Personalizado

```php
// admin/custom_module.php

<?php
require_once '../includes/admin_auth.php';
require_once '../config/db_config.php';

checkAdminAuth();  // Verificar acceso

$page_title = "Mi Módulo Personalizado";
include 'includes/header.php';
?>

<div class="container-fluid">
    <h1><?php echo $page_title; ?></h1>
    
    <!-- Tu contenido personalizado aquí -->
    
</div>

<?php include 'includes/footer.php'; ?>
```

Agregar al menú en `includes/sidebar.php`:

```php
<li>
    <a href="custom_module.php">
        <i class="fa fa-cog"></i> Mi Módulo
    </a>
</li>
```

## 🔧 Mantenimiento del Panel Administrativo

### Actualizar el Sistema

```bash
# Hacer backup de archivos actuales
cp -r Administrador-Bolsa-de-Empleo Administrador-Bolsa-de-Empleo_backup_$(date +%Y%m%d)

# Descargar última versión
git pull origin main

# Verificar cambios en configuración
diff config/db_config.php config/db_config.php.example

# Aplicar migraciones de BD si las hay
mysql -u root -p empleatecsql < updates/migration_2025_01.sql
```

### Limpiar Logs Antiguos

```sql
-- Eliminar logs mayores a 90 días
DELETE FROM activity_logs 
WHERE created_at < DATE_SUB(NOW(), INTERVAL 90 DAY);

-- Optimizar tabla después de eliminar
OPTIMIZE TABLE activity_logs;
```

## ⚠️ Solución de Problemas

### No puedo acceder al panel (403 Forbidden)

**Solución:**
```bash
# Verificar permisos
chmod 755 Administrador-Bolsa-de-Empleo
chmod 644 Administrador-Bolsa-de-Empleo/*.php

# Verificar .htaccess
cat Administrador-Bolsa-de-Empleo/.htaccess
# Comentar restricciones de IP temporalmente
```

### Olvidé la contraseña del administrador

**Solución:**
```sql
-- Resetear contraseña desde MySQL
UPDATE users 
SET password = MD5('NuevaContraseña123!') 
WHERE email = 'admin@empleatec.com';

-- O usar SHA256
UPDATE users 
SET password = SHA2('NuevaContraseña123!', 256) 
WHERE email = 'admin@empleatec.com';
```

### Error de sesión al navegar

**Solución:**
```php
// Verificar configuración de sesiones en php.ini
session.cookie_httponly = 1
session.cookie_secure = 0  # 1 si usas HTTPS
session.gc_maxlifetime = 1440

// Limpiar sesiones antiguas
sudo rm -rf /var/lib/php/sessions/*
```

---
# Instalación Principal

Esta guía te llevará paso a paso por el proceso de instalación de EmpleaTec en tu entorno local o servidor.

## 🎯 Opciones de Instalación

Elige el método que mejor se adapte a tu situación:

| Método | Recomendado Para | Dificultad |
|--------|-----------------|------------|
| **Instalación Local** | Desarrollo y pruebas | 🟢 Fácil |
| **Instalación en Servidor** | Producción | 🟡 Media |

## 📥 Paso 1: Descargar el Proyecto

### Opción A: Clonar con Git (Recomendado)

#### 1.1 Verificar Git

```bash
# Verificar que Git esté instalado
git --version

# Si no está instalado:
# Ubuntu/Debian: sudo apt install git
# CentOS: sudo yum install git
# macOS: brew install git
# Windows: Descargar de https://git-scm.com/
```

#### 1.2 Clonar el Repositorio

**En Linux/macOS:**

```bash
# Navegar al directorio deseado
cd /var/www/html  # Servidor web
# O
cd ~/proyectos     # Desarrollo local

# Clonar el repositorio
git clone https://github.com/JuanChimarro/EmpleaTec.git

# Entrar al directorio
cd EmpleaTec

# Verificar archivos descargados
ls -la
```

**En Windows (Git Bash o PowerShell):**

```powershell
# Navegar a la carpeta de tu servidor local
cd C:\xampp\htdocs  # Si usas XAMPP
# O
cd C:\wamp64\www    # Si usas WAMP

# Clonar el repositorio
git clone https://github.com/JuanChimarro/EmpleaTec.git

# Entrar al directorio
cd EmpleaTec

# Verificar archivos
dir
```

:::tip Ubicación Recomendada
- **XAMPP**: `C:\xampp\htdocs\EmpleaTec`
- **WAMP**: `C:\wamp64\www\EmpleaTec`
- **Linux**: `/var/www/html/EmpleaTec`
- **macOS**: `/Applications/MAMP/htdocs/EmpleaTec`
:::

### Opción B: Descargar ZIP

Si no quieres usar Git:

1. Ve a: https://github.com/JuanChimarro/EmpleaTec
2. Haz clic en **"Code"** (botón verde)
3. Selecciona **"Download ZIP"**
4. Extrae el archivo en la carpeta de tu servidor web:
   - Windows XAMPP: `C:\xampp\htdocs\`
   - Windows WAMP: `C:\wamp64\www\`
   - Linux: `/var/www/html/`
   - macOS MAMP: `/Applications/MAMP/htdocs/`

5. Renombra la carpeta a `EmpleaTec` (si viene con otro nombre)

## 📁 Paso 2: Estructura del Proyecto

Después de descargar, deberías tener esta estructura:

```
EmpleaTec/
├── Administrador-Bolsa-de-Empleo/  # Módulo administrativo
│   ├── admin/
│   ├── assets/
│   └── ...
├── EmpleaTec/                       # Aplicación principal
│   ├── app/
│   ├── assets/
│   │   ├── css/
│   │   ├── js/
│   │   └── images/
│   ├── Constants/
│   │   ├── db_config.php           # Configuración BD
│   │   └── settings.php            # Configuración SMTP
│   ├── employee/                    # Módulo empleados
│   ├── employer/                    # Módulo empleadores
│   ├── uploads/                     # Archivos subidos
│   ├── index.php                    # Página principal
│   ├── login.php
│   ├── register.php
│   └── ...
├── database/                        # Archivos SQL
│   └── empleatecsql.sql
├── .gitignore
└── README.md
```

## ⚙️ Paso 3: Configurar Permisos (Linux/macOS)

Si estás en Linux o macOS, configura los permisos adecuados:

```bash
# Navegar al directorio del proyecto
cd /var/www/html/EmpleaTec

# Dar permisos al servidor web
sudo chown -R www-data:www-data .  # Ubuntu/Debian
# O
sudo chown -R apache:apache .      # CentOS/RHEL

# Configurar permisos de carpetas
sudo find . -type d -exec chmod 755 {} \;
sudo find . -type f -exec chmod 644 {} \;

# Permisos de escritura para uploads
sudo chmod -R 775 EmpleaTec/uploads/
sudo chmod 775 EmpleaTec/Constants/

# Si hay carpetas de logs o cache
sudo chmod -R 775 logs/ 2>/dev/null || true
sudo chmod -R 775 cache/ 2>/dev/null || true
```

:::warning Windows
En Windows (XAMPP/WAMP) los permisos generalmente no son un problema. Solo asegúrate de que las carpetas no estén en solo lectura.
:::

## 🔧 Paso 4: Configurar Archivo Virtual Host (Opcional)

Para acceder con un dominio personalizado local (ej: `empleatec.local`)

### Apache en Linux

```bash
# Crear archivo de configuración
sudo nano /etc/apache2/sites-available/empleatec.conf
```

Agrega este contenido:

```apache
<VirtualHost *:80>
    ServerName empleatec.local
    ServerAlias www.empleatec.local
    DocumentRoot /var/www/html/EmpleaTec/EmpleaTec
    
    <Directory /var/www/html/EmpleaTec/EmpleaTec>
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
    
    ErrorLog ${APACHE_LOG_DIR}/empleatec_error.log
    CustomLog ${APACHE_LOG_DIR}/empleatec_access.log combined
</VirtualHost>
```

```bash
# Habilitar el sitio
sudo a2ensite empleatec.conf

# Reiniciar Apache
sudo systemctl restart apache2

# Editar archivo hosts
sudo nano /etc/hosts
```

Agrega al final:
```
127.0.0.1   empleatec.local www.empleatec.local
```

### Apache en Windows (XAMPP)

1. Editar `C:\xampp\apache\conf\extra\httpd-vhosts.conf`

```apache
<VirtualHost *:80>
    ServerName empleatec.local
    DocumentRoot "C:/xampp/htdocs/EmpleaTec/EmpleaTec"
    <Directory "C:/xampp/htdocs/EmpleaTec/EmpleaTec">
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
</VirtualHost>
```

2. Editar `C:\Windows\System32\drivers\etc\hosts` (como Administrador)

Agrega:
```
127.0.0.1   empleatec.local
```

3. Reinicia Apache desde el panel de XAMPP

## 🌐 Paso 5: Verificar Acceso Web

Abre tu navegador y accede a:

**Sin Virtual Host:**
- `http://localhost/EmpleaTec/EmpleaTec/`
- O la ruta donde instalaste

**Con Virtual Host:**
- `http://empleatec.local/`

Deberías ver la página principal de EmpleaTec (aunque sin datos aún).

:::warning Error 403 o 404
Si ves error 403 (Forbidden) o 404 (Not Found):
1. Verifica la ruta en DocumentRoot
2. Revisa permisos de carpetas
3. Asegúrate de que Apache esté corriendo
4. Verifica que el archivo index.php exista
:::

## 📊 Paso 6: Crear Base de Datos

### Opción 1: Usando phpMyAdmin (Recomendado para principiantes)

1. **Acceder a phpMyAdmin:**
   - XAMPP/WAMP: `http://localhost/phpmyadmin`
   - Usuario por defecto: `root`
   - Contraseña: (vacío en instalación local)

2. **Crear base de datos:**
   - Haz clic en **"Nueva"** o **"New"** en el panel izquierdo
   - Nombre de la base de datos: `empleatecsql`
   - Cotejamiento: `utf8mb4_unicode_ci`
   - Haz clic en **"Crear"**


3. **Importar estructura:**
   - Selecciona la base de datos `empleatecsql` recién creada
   - Haz clic en la pestaña **"Importar"**
   - Haz clic en **"Seleccionar archivo"**
   - Busca: `EmpleaTec/database/empleatecsql.sql`
   - Haz clic en **"Continuar"** al final de la página
   - Espera a que se complete la importación



4. **Verificar importación:**
   - Verás las tablas creadas en el panel izquierdo:
     - `users`
     - `employees`
     - `employers`
     - `jobs`
     - `applications`
     - etc.

### Opción 2: Usando Terminal/CLI

```bash
# Conectar a MySQL
mysql -u root -p

# Crear base de datos
CREATE DATABASE empleatecsql CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

# Seleccionar base de datos
USE empleatecsql;

# Importar archivo SQL
SOURCE /ruta/completa/a/EmpleaTec/database/empleatecsql.sql;

# O desde fuera de MySQL:
mysql -u root -p empleatecsql < /ruta/completa/a/EmpleaTec/database/empleatecsql.sql

# Verificar tablas creadas
SHOW TABLES;

# Salir
EXIT;
```

### Opción 3: Usando MySQL Workbench

1. Abrir MySQL Workbench
2. Conectar a tu servidor local
3. Ejecutar query: `CREATE DATABASE empleatecsql;`
4. Ir a **Server** > **Data Import**
5. Seleccionar **Import from Self-Contained File**
6. Buscar `empleatecsql.sql`
7. Target Schema: `empleatecsql`
8. Clic en **Start Import**

## 🔑 Paso 7: Configurar Conexión a Base de Datos

### 7.1 Localizar Archivo de Configuración

Navega a:
```
EmpleaTec/EmpleaTec/Constants/db_config.php
```

### 7.2 Editar Configuración

**Usando Visual Studio Code:**

```bash
# Abrir proyecto en VS Code
code /ruta/a/EmpleaTec
```

**O abrir directamente el archivo:**

```bash
# Linux/macOS
nano EmpleaTec/Constants/db_config.php

# Windows
notepad EmpleaTec\Constants\db_config.php
```

### 7.3 Configurar Credenciales

**Para entorno local:**

```php
<?php
/**
 * Configuración de Base de Datos - EmpleaTec
 * Entorno: Desarrollo Local
 */

$servername = "localhost";           // Servidor MySQL
$username = "root";                   // Usuario por defecto XAMPP/WAMP
$password = "";                       // Sin contraseña en local
$dbname = "empleatecsql";            // Nombre de la base de datos

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Configurar charset
$conn->set_charset("utf8mb4");
?>
```

**Para entorno de producción:**

```php
<?php
/**
 * Configuración de Base de Datos - EmpleaTec
 * Entorno: Producción
 */

$servername = "localhost";           // O IP del servidor BD
$username = "empleatec_user";        // Usuario específico
$password = "contraseña_segura_aqui"; // Contraseña fuerte
$dbname = "empleatecsql";            // Nombre de la base de datos

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    // En producción, NO mostrar detalles del error
    error_log("Error de conexión BD: " . $conn->connect_error);
    die("Error al conectar con la base de datos. Contacte al administrador.");
}

// Configurar charset
$conn->set_charset("utf8mb4");
?>
```

:::danger Seguridad en Producción
**NUNCA** uses el usuario `root` con contraseña vacía en producción. Crea un usuario específico con permisos limitados.
:::

### 7.4 Crear Usuario MySQL (Producción)

```sql
-- Conectar como root
mysql -u root -p

-- Crear usuario específico
CREATE USER 'empleatec_user'@'localhost' IDENTIFIED BY 'contraseña_fuerte_123!';

-- Dar permisos solo a la base de datos de EmpleaTec
GRANT SELECT, INSERT, UPDATE, DELETE ON empleatecsql.* TO 'empleatec_user'@'localhost';

-- Aplicar cambios
FLUSH PRIVILEGES;

-- Verificar
SHOW GRANTS FOR 'empleatec_user'@'localhost';

-- Salir
EXIT;
```

### 7.5 Probar Conexión

Crea un archivo de prueba `test_connection.php`:

```php
<?php
// Incluir configuración
require_once 'Constants/db_config.php';

echo "<h1>Prueba de Conexión - EmpleaTec</h1>";

if ($conn) {
    echo "<p style='color: green;'>✅ Conexión exitosa a la base de datos</p>";
    
    // Probar consulta
    $result = $conn->query("SHOW TABLES");
    if ($result) {
        echo "<p>Tablas encontradas:</p><ul>";
        while ($row = $result->fetch_array()) {
            echo "<li>" . $row[0] . "</li>";
        }
        echo "</ul>";
    }
    
    $conn->close();
} else {
    echo "<p style='color: red;'>❌ Error de conexión</p>";
}
?>
```

Accede a: `http://localhost/EmpleaTec/EmpleaTec/test_connection.php`

Si ves "✅ Conexión exitosa", estás listo para continuar.

## 📧 Paso 8: Configurar SMTP (Opcional)

Para envío de correos electrónicos:

### 8.1 Editar Configuración SMTP

Abre: `EmpleaTec/Constants/settings.php`

```php
<?php
/**
 * Configuración SMTP - EmpleaTec
 * Para envío de correos electrónicos
 */

// Configuración SMTP
$smtp_host = 'smtp.gmail.com';              // Servidor SMTP
$smtp_port = 587;                            // Puerto (587=TLS, 465=SSL)
$smtp_user = 'tuemail@gmail.com';           // Tu correo
$smtp_pass = 'tu_contraseña_aplicacion';    // Contraseña de aplicación
$smtp_secure = 'tls';                        // tls o ssl

// Configuración de correos
$from_email = 'tuemail@gmail.com';          // Email remitente
$from_name = 'EmpleaTec';                   // Nombre remitente
$contact_mail = 'contacto@empleatec.com';   // Email de contacto

// Configuración adicional
$smtp_debug = 0;                            // 0=off, 1=client, 2=server
$smtp_charset = 'UTF-8';
?>
```

### 8.2 Configurar Gmail

Si usas Gmail, necesitas una contraseña de aplicación:

1. **Activar verificación en 2 pasos:**
   - Ve a https://myaccount.google.com/security
   - Activa "Verificación en dos pasos"

2. **Generar contraseña de aplicación:**
   - Ve a https://myaccount.google.com/apppasswords
   - Selecciona "Correo" y "Otro dispositivo"
   - Escribe "EmpleaTec"
   - Copia la contraseña generada (16 caracteres)
   - Úsala en `$smtp_pass`

### 8.3 Alternativas a Gmail

**SendGrid (Recomendado para producción):**
```php
$smtp_host = 'smtp.sendgrid.net';
$smtp_port = 587;
$smtp_user = 'apikey';
$smtp_pass = 'tu_api_key_sendgrid';
```

**Mailgun:**
```php
$smtp_host = 'smtp.mailgun.org';
$smtp_port = 587;
$smtp_user = 'postmaster@tu-dominio.mailgun.org';
$smtp_pass = 'tu_password_mailgun';
```

**Amazon SES:**
```php
$smtp_host = 'email-smtp.us-east-1.amazonaws.com';
$smtp_port = 587;
$smtp_user = 'tu_access_key';
$smtp_pass = 'tu_secret_key';
```

### 8.4 Probar Envío de Correo

Crea `test_email.php`:

```php
<?php
require_once 'Constants/settings.php';
// Aquí irá el código para probar PHPMailer
// Ver documentación de PHPMailer para detalles
?>
```

## ✅ Paso 9: Verificar Instalación

### 9.1 Acceder a la Plataforma

Abre tu navegador y ve a:
- `http://localhost/EmpleaTec/EmpleaTec/` (sin virtual host)
- `http://empleatec.local/` (con virtual host)

Deberías ver la página principal de EmpleaTec.

### 9.2 Probar Registro

1. Haz clic en **"Registrarse"**
2. Selecciona "Soy Graduado"
3. Completa el formulario
4. Verifica que se cree la cuenta

### 9.3 Probar Inicio de Sesión

1. Usa las credenciales que acabas de crear
2. Verifica que accedas al dashboard
3. Explora las diferentes secciones

### 9.4 Checklist de Verificación

- [ ] Página principal carga correctamente
- [ ] Los estilos CSS se aplican
- [ ] Las imágenes se muestran
- [ ] El formulario de registro funciona
- [ ] El login funciona
- [ ] Se pueden ver ofertas de empleo
- [ ] Se pueden subir archivos (CV)
- [ ] Los correos se envían (si configuraste SMTP)

## 🔧 Configuración Adicional

### URL Base de la Aplicación

Si la aplicación necesita conocer su URL base, busca y configura:

```php
// En algún archivo de configuración
define('BASE_URL', 'http://localhost/EmpleaTec/EmpleaTec/');
// O en producción:
// define('BASE_URL', 'https://serviciosint.com/bolsadeempleo/');
```

### Zona Horaria

Configura la zona horaria correcta:

```php
// En algún archivo de inicio o config
date_default_timezone_set('America/Guayaquil');  // Ecuador
// O la zona horaria de tu país
```

### Límites de Subida

Si necesitas ajustar los límites de archivos, edita `.htaccess`:

```apache
# Límites de subida
php_value upload_max_filesize 10M
php_value post_max_size 10M
php_value max_execution_time 300
php_value max_input_time 300
```

## 🚀 Paso 10: Acceso al Módulo Administrativo

El módulo administrativo se encuentra en:
- `http://localhost/EmpleaTec/Administrador-Bolsa-de-Empleo/`

Ver más detalles en [Módulo Administrador](./modulo-administrador.md)

---

**Siguiente paso**: Aprende a configurar la [Base de Datos](./configuracion-base-datos.md) en detalle.
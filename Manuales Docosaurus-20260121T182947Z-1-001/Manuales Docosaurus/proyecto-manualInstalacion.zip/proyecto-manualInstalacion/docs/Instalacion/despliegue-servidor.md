# Despliegue en Servidor

Guía para desplegar EmpleaTec en un servidor de producción usando Apache y PHP nativo.

## 🎯 Opciones de Hosting

| Tipo | Ejemplos | Recomendado Para |
|------|----------|------------------|
| **Shared Hosting** | Hostinger, Bluehost | Proyectos pequeños, bajo costo |
| **VPS** | DigitalOcean, Linode | Control total, escalabilidad |
| **Cloud** | AWS, Google Cloud | Proyectos grandes |
| **Servidor Dedicado** | OVH, Liquid Web | Alto tráfico |

## 🔧 Requisitos del Servidor

```bash
# Sistema Operativo
Ubuntu Server 20.04 LTS o superior

# Software
- Apache 2.4+ o Nginx
- PHP 7.4+
- MySQL 5.7+ o MariaDB 10.3+
- SSL/TLS (Let's Encrypt)
- Git

# Recursos Mínimos
- 2 CPU cores
- 4 GB RAM
- 50 GB SSD
- 100 Mbps conexión
```

## 📦 Instalación en VPS (Ubuntu)

### Paso 1: Preparar Servidor

```bash
# Actualizar sistema
sudo apt update && sudo apt upgrade -y

# Instalar Apache
sudo apt install apache2 -y

# Instalar PHP y extensiones
sudo apt install php php-mysqli php-mbstring php-json php-curl \
                 php-openssl php-fileinfo php-gd php-zip -y

# Instalar MySQL
sudo apt install mysql-server -y

# Configurar firewall
sudo ufw allow 'Apache Full'
sudo ufw allow OpenSSH
sudo ufw enable
```

### Paso 2: Configurar MySQL

```bash
# Configuración segura
sudo mysql_secure_installation

# Crear base de datos y usuario
sudo mysql -u root -p

CREATE DATABASE empleatecsql CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'empleatec_user'@'localhost' IDENTIFIED BY 'contraseña_segura_123!';
GRANT ALL PRIVILEGES ON empleatecsql.* TO 'empleatec_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

### Paso 3: Clonar Proyecto

```bash
# Navegar al directorio web
cd /var/www/html

# Clonar repositorio
sudo git clone https://github.com/JuanChimarro/EmpleaTec.git

# Establecer permisos
sudo chown -R www-data:www-data EmpleaTec
sudo chmod -R 755 EmpleaTec
sudo chmod -R 775 EmpleaTec/EmpleaTec/uploads
```

### Paso 4: Configurar Base de Datos

```bash
# Importar esquema
mysql -u empleatec_user -p empleatecsql < /var/www/html/EmpleaTec/database/empleatecsql.sql

# Editar configuración
sudo nano /var/www/html/EmpleaTec/EmpleaTec/Constants/db_config.php
```

```php
<?php
$servername = "localhost";
$username = "empleatec_user";
$password = "contraseña_segura_123!";
$dbname = "empleatecsql";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    error_log("Error BD: " . $conn->connect_error);
    die("Error de conexión");
}
$conn->set_charset("utf8mb4");
?>
```

### Paso 5: Configurar Virtual Host

```bash
sudo nano /etc/apache2/sites-available/empleatec.conf
```

```apache
<VirtualHost *:80>
    ServerName empleatec.com
    ServerAlias www.empleatec.com
    ServerAdmin admin@empleatec.com
    DocumentRoot /var/www/html/EmpleaTec/EmpleaTec
    
    <Directory /var/www/html/EmpleaTec/EmpleaTec>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
    
    # Proteger archivos sensibles
    <FilesMatch "^(db_config|settings)\.php$">
        Require all denied
    </FilesMatch>
    
    ErrorLog ${APACHE_LOG_DIR}/empleatec_error.log
    CustomLog ${APACHE_LOG_DIR}/empleatec_access.log combined
</VirtualHost>
```

```bash
# Habilitar sitio
sudo a2ensite empleatec.conf
sudo a2enmod rewrite headers
sudo systemctl restart apache2
```

## 🔐 Configurar SSL/HTTPS

### Con Let's Encrypt (Gratuito)

```bash
# Instalar Certbot
sudo apt install certbot python3-certbot-apache -y

# Obtener certificado
sudo certbot --apache -d empleatec.com -d www.empleatec.com

# Renovación automática (ya configurada)
sudo certbot renew --dry-run
```

## 🔒 Seguridad en Producción

### 1. Hardening de PHP

```bash
sudo nano /etc/php/7.4/apache2/php.ini
```

```ini
display_errors = Off
log_errors = On
error_log = /var/log/php/error.log
expose_php = Off
allow_url_fopen = Off
allow_url_include = Off
upload_max_filesize = 10M
post_max_size = 10M
max_execution_time = 60
memory_limit = 256M
```

### 2. Proteger Archivos Sensibles

```apache
# .htaccess en directorio Constants/
<Files "db_config.php">
    Require all denied
</Files>
<Files "settings.php">
    Require all denied
</Files>
```

### 3. Headers de Seguridad

```apache
# En VirtualHost
Header always set X-Frame-Options "SAMEORIGIN"
Header always set X-XSS-Protection "1; mode=block"
Header always set X-Content-Type-Options "nosniff"
Header always set Referrer-Policy "strict-origin-when-cross-origin"
Header always set Strict-Transport-Security "max-age=31536000; includeSubDomains"
```

## 📊 Monitoreo

### Instalar herramientas de monitoreo

```bash
# Instalar htop
sudo apt install htop -y

# Instalar netdata (panel de monitoreo)
bash <(curl -Ss https://my-netdata.io/kickstart.sh)
```

## 🔄 Actualización

```bash
# Hacer backup
sudo cp -r /var/www/html/EmpleaTec /var/www/backups/EmpleaTec_$(date +%Y%m%d)

# Actualizar código
cd /var/www/html/EmpleaTec
sudo git pull origin main

# Aplicar cambios de BD si hay
mysql -u empleatec_user -p empleatecsql < updates/migration.sql

# Limpiar caché si aplica
sudo rm -rf cache/*

# Reiniciar servicios
sudo systemctl restart apache2
```

## 🧹 Mantenimiento

### Script de Backup Automático

```bash
#!/bin/bash
# /home/scripts/backup_empleatec.sh

DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/home/backups/empleatec"
mkdir -p $BACKUP_DIR

# Backup BD
mysqldump -u empleatec_user -p'contraseña' empleatecsql | gzip > $BACKUP_DIR/db_$DATE.sql.gz

# Backup archivos
tar -czf $BACKUP_DIR/files_$DATE.tar.gz /var/www/html/EmpleaTec

# Eliminar backups antiguos (más de 30 días)
find $BACKUP_DIR -type f -mtime +30 -delete

echo "$(date): Backup completado" >> /var/log/backup_empleatec.log
```

```bash
# Programar con cron (diario a las 2 AM)
crontab -e
0 2 * * * /home/scripts/backup_empleatec.sh
```

---

**Siguiente**: Revisa [Solución de Problemas](../solucion-problemas.md) para resolver errores comunes.
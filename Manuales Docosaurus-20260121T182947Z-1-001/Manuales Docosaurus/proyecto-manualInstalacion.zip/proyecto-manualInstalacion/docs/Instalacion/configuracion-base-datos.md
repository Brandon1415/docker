# Configuración de Base de Datos

Guía detallada para configurar, optimizar y mantener la base de datos de EmpleaTec.

## 📊 Estructura de la Base de Datos

### Diagrama Entidad-Relación

```
┌─────────────┐         ┌──────────────┐
│    users    │────────<│  employees   │
│             │         │              │
│ • id (PK)   │         │ • id (PK)    │
│ • email     │         │ • user_id FK │
│ • password  │         │ • first_name │
│ • user_type │         │ • last_name  │
│ • status    │         │ • cv_path    │
└─────────────┘         └──────────────┘
      │
      │
      ▼
┌─────────────┐         ┌──────────────┐
│  employers  │────────<│     jobs     │
│             │         │              │
│ • id (PK)   │         │ • id (PK)    │
│ • user_id FK│         │ • employer_id│
│ • company   │         │ • title      │
│ • ruc       │         │ • salary     │
└─────────────┘         │ • location   │
                        └──────────────┘
                              │
                              │
                              ▼
                        ┌──────────────┐
                        │ applications │
                        │              │
                        │ • id (PK)    │
                        │ • job_id FK  │
                        │ • employee_id│
                        │ • status     │
                        └──────────────┘
```

## 🗃️ Tablas Principales

### Tabla: users

Almacena información básica de autenticación de todos los usuarios.

```sql
CREATE TABLE `users` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(255) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `user_type` ENUM('employee', 'employer', 'admin') NOT NULL,
  `status` ENUM('active', 'inactive', 'pending') DEFAULT 'pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_login` TIMESTAMP NULL DEFAULT NULL,
  `email_verified` TINYINT(1) DEFAULT 0,
  `verification_token` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_user_type` (`user_type`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

**Campos importantes:**
- `user_type`: Define si es empleado, empleador o administrador
- `status`: Estado de la cuenta (activa, inactiva, pendiente aprobación)
- `email_verified`: Si el correo ha sido verificado

### Tabla: employees

Información detallada de los graduados.

```sql
CREATE TABLE `employees` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL,
  `first_name` VARCHAR(100) NOT NULL,
  `last_name` VARCHAR(100) NOT NULL,
  `cedula` VARCHAR(20) NOT NULL,
  `phone` VARCHAR(20) DEFAULT NULL,
  `date_of_birth` DATE DEFAULT NULL,
  `gender` ENUM('male', 'female', 'other') DEFAULT NULL,
  `address` TEXT,
  `city` VARCHAR(100) DEFAULT NULL,
  `province` VARCHAR(100) DEFAULT NULL,
  `cv_path` VARCHAR(255) DEFAULT NULL,
  `photo_path` VARCHAR(255) DEFAULT NULL,
  `career` VARCHAR(255) DEFAULT NULL,
  `graduation_year` YEAR DEFAULT NULL,
  `campus` VARCHAR(255) DEFAULT NULL,
  `profile_completeness` INT(3) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `cedula` (`cedula`),
  KEY `idx_city` (`city`),
  KEY `idx_career` (`career`),
  KEY `idx_graduation_year` (`graduation_year`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

**Índices importantes:**
- `idx_city`: Para búsquedas por ubicación
- `idx_career`: Para filtrar por carrera
- `idx_graduation_year`: Para filtrar por año de graduación

### Tabla: employers

Información de empresas registradas.

```sql
CREATE TABLE `employers` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL,
  `company_name` VARCHAR(255) NOT NULL,
  `commercial_name` VARCHAR(255) DEFAULT NULL,
  `ruc` VARCHAR(20) NOT NULL,
  `industry` VARCHAR(100) DEFAULT NULL,
  `company_size` VARCHAR(50) DEFAULT NULL,
  `founded_year` YEAR DEFAULT NULL,
  `website` VARCHAR(255) DEFAULT NULL,
  `address` TEXT,
  `city` VARCHAR(100) DEFAULT NULL,
  `province` VARCHAR(100) DEFAULT NULL,
  `phone` VARCHAR(20) DEFAULT NULL,
  `contact_email` VARCHAR(255) DEFAULT NULL,
  `description` TEXT,
  `logo_path` VARCHAR(255) DEFAULT NULL,
  `representative_name` VARCHAR(255) DEFAULT NULL,
  `representative_cedula` VARCHAR(20) DEFAULT NULL,
  `representative_position` VARCHAR(100) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `ruc` (`ruc`),
  KEY `idx_city` (`city`),
  KEY `idx_industry` (`industry`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

### Tabla: jobs

Ofertas de empleo publicadas.

```sql
CREATE TABLE `jobs` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `employer_id` INT(11) NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `description` TEXT NOT NULL,
  `requirements` TEXT,
  `responsibilities` TEXT,
  `benefits` TEXT,
  `job_type` ENUM('full-time', 'part-time', 'internship', 'freelance', 'temporary') NOT NULL,
  `work_mode` ENUM('presential', 'remote', 'hybrid') DEFAULT 'presential',
  `location` VARCHAR(255) DEFAULT NULL,
  `city` VARCHAR(100) DEFAULT NULL,
  `province` VARCHAR(100) DEFAULT NULL,
  `salary_min` DECIMAL(10,2) DEFAULT NULL,
  `salary_max` DECIMAL(10,2) DEFAULT NULL,
  `salary_visible` TINYINT(1) DEFAULT 1,
  `vacancies` INT(3) DEFAULT 1,
  `experience_required` VARCHAR(50) DEFAULT NULL,
  `education_required` VARCHAR(100) DEFAULT NULL,
  `status` ENUM('active', 'closed', 'pending', 'paused') DEFAULT 'pending',
  `deadline` DATE DEFAULT NULL,
  `published_date` TIMESTAMP NULL DEFAULT NULL,
  `views_count` INT(11) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_employer` (`employer_id`),
  KEY `idx_status` (`status`),
  KEY `idx_city` (`city`),
  KEY `idx_job_type` (`job_type`),
  KEY `idx_deadline` (`deadline`),
  KEY `idx_published` (`published_date`),
  FULLTEXT KEY `idx_fulltext_search` (`title`, `description`),
  FOREIGN KEY (`employer_id`) REFERENCES `employers`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

**Índice FULLTEXT:**
- Permite búsquedas de texto completo eficientes
- Busca en título y descripción simultáneamente

### Tabla: applications

Aplicaciones de empleados a ofertas.

```sql
CREATE TABLE `applications` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `job_id` INT(11) NOT NULL,
  `employee_id` INT(11) NOT NULL,
  `status` ENUM('sent', 'reviewing', 'shortlisted', 'interview', 'rejected', 'hired', 'cancelled') DEFAULT 'sent',
  `cover_letter` TEXT,
  `applied_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `status_updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `notes` TEXT,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_application` (`job_id`, `employee_id`),
  KEY `idx_job` (`job_id`),
  KEY `idx_employee` (`employee_id`),
  KEY `idx_status` (`status`),
  KEY `idx_applied_date` (`applied_date`),
  FOREIGN KEY (`job_id`) REFERENCES `jobs`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

**Restricción UNIQUE:**
- Un empleado solo puede aplicar una vez a cada oferta
- `unique_application` (`job_id`, `employee_id`)

### Tablas Adicionales

```sql
-- Habilidades de empleados
CREATE TABLE `employee_skills` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `employee_id` INT(11) NOT NULL,
  `skill_name` VARCHAR(100) NOT NULL,
  `proficiency_level` ENUM('basic', 'intermediate', 'advanced', 'expert') DEFAULT 'intermediate',
  PRIMARY KEY (`id`),
  KEY `idx_employee` (`employee_id`),
  KEY `idx_skill` (`skill_name`),
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Experiencia laboral
CREATE TABLE `employee_experience` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `employee_id` INT(11) NOT NULL,
  `company_name` VARCHAR(255) NOT NULL,
  `position` VARCHAR(255) NOT NULL,
  `start_date` DATE NOT NULL,
  `end_date` DATE DEFAULT NULL,
  `is_current` TINYINT(1) DEFAULT 0,
  `description` TEXT,
  `location` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_employee` (`employee_id`),
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Educación
CREATE TABLE `employee_education` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `employee_id` INT(11) NOT NULL,
  `institution` VARCHAR(255) NOT NULL,
  `degree` VARCHAR(255) NOT NULL,
  `field_of_study` VARCHAR(255) DEFAULT NULL,
  `start_date` DATE DEFAULT NULL,
  `end_date` DATE DEFAULT NULL,
  `is_current` TINYINT(1) DEFAULT 0,
  `grade` VARCHAR(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_employee` (`employee_id`),
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Certificaciones
CREATE TABLE `employee_certifications` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `employee_id` INT(11) NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `issuing_organization` VARCHAR(255) NOT NULL,
  `issue_date` DATE DEFAULT NULL,
  `expiration_date` DATE DEFAULT NULL,
  `credential_id` VARCHAR(255) DEFAULT NULL,
  `credential_url` VARCHAR(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_employee` (`employee_id`),
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Mensajes entre empresas y candidatos
CREATE TABLE `messages` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `sender_id` INT(11) NOT NULL,
  `receiver_id` INT(11) NOT NULL,
  `subject` VARCHAR(255) DEFAULT NULL,
  `message` TEXT NOT NULL,
  `is_read` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_sender` (`sender_id`),
  KEY `idx_receiver` (`receiver_id`),
  KEY `idx_is_read` (`is_read`),
  FOREIGN KEY (`sender_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`receiver_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Favoritos de empleados
CREATE TABLE `favorites` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `employee_id` INT(11) NOT NULL,
  `job_id` INT(11) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_favorite` (`employee_id`, `job_id`),
  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`job_id`) REFERENCES `jobs`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Logs de actividad
CREATE TABLE `activity_logs` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) DEFAULT NULL,
  `action` VARCHAR(100) NOT NULL,
  `description` TEXT,
  `ip_address` VARCHAR(45) DEFAULT NULL,
  `user_agent` VARCHAR(255) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_action` (`action`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

## ⚙️ Configuración de MySQL

### Archivo de Configuración (my.cnf)

**Linux:** `/etc/mysql/my.cnf` o `/etc/my.cnf`  
**Windows:** `C:\ProgramData\MySQL\MySQL Server 8.0\my.ini`

```ini
[mysqld]
# Configuración general
port = 3306
socket = /var/run/mysqld/mysqld.sock

# Codificación
character-set-server = utf8mb4
collation-server = utf8mb4_unicode_ci
init_connect = 'SET NAMES utf8mb4'

# Límites de conexión
max_connections = 200
max_connect_errors = 100
wait_timeout = 600
interactive_timeout = 600

# Tamaño de paquetes
max_allowed_packet = 64M

# Motor InnoDB
default-storage-engine = InnoDB
innodb_buffer_pool_size = 1G          # 50-80% de RAM disponible
innodb_log_file_size = 256M
innodb_flush_log_at_trx_commit = 2
innodb_file_per_table = 1

# Consultas lentas
slow_query_log = 1
slow_query_log_file = /var/log/mysql/slow-query.log
long_query_time = 2

# Binario y replicación (producción)
server-id = 1
log_bin = /var/log/mysql/mysql-bin.log
expire_logs_days = 7
max_binlog_size = 100M

[client]
default-character-set = utf8mb4
```

Reiniciar MySQL después de cambios:
```bash
sudo systemctl restart mysql
```

## 🔐 Seguridad de la Base de Datos

### 1. Crear Usuario Específico

```sql
-- Conectar como root
mysql -u root -p

-- Crear usuario para EmpleaTec
CREATE USER 'empleatec_user'@'localhost' 
IDENTIFIED WITH mysql_native_password BY 'Contraseña_Segura_123!';

-- Otorgar permisos específicos
GRANT SELECT, INSERT, UPDATE, DELETE 
ON empleatecsql.* 
TO 'empleatec_user'@'localhost';

-- Para desarrollo (permisos adicionales)
-- GRANT CREATE, DROP, ALTER, INDEX ON empleatecsql.* TO 'empleatec_user'@'localhost';

-- Aplicar cambios
FLUSH PRIVILEGES;

-- Verificar permisos
SHOW GRANTS FOR 'empleatec_user'@'localhost';
```

### 2. Política de Contraseñas

```sql
-- Establecer política de contraseñas (MySQL 8.0+)
SET GLOBAL validate_password.policy = STRONG;
SET GLOBAL validate_password.length = 12;
SET GLOBAL validate_password.mixed_case_count = 1;
SET GLOBAL validate_password.number_count = 1;
SET GLOBAL validate_password.special_char_count = 1;
```

### 3. Limitar Acceso por IP

```sql
-- Solo permitir conexiones desde localhost
-- Ya configurado con 'usuario'@'localhost'

-- Si necesitas acceso remoto específico
CREATE USER 'empleatec_user'@'192.168.1.100' 
IDENTIFIED BY 'Contraseña_Segura_123!';
```

### 4. Eliminar Usuarios por Defecto

```sql
-- Ver usuarios existentes
SELECT user, host FROM mysql.user;

-- Eliminar usuarios anónimos
DELETE FROM mysql.user WHERE user = '';

-- Eliminar usuario root remoto
DELETE FROM mysql.user WHERE user = 'root' AND host != 'localhost';

FLUSH PRIVILEGES;
```

## 📈 Optimización de Consultas

### Índices Importantes

```sql
-- Verificar índices existentes
SHOW INDEX FROM empleatecsql.jobs;

-- Crear índices adicionales si es necesario
CREATE INDEX idx_salary_range ON jobs(salary_min, salary_max);
CREATE INDEX idx_location_search ON jobs(city, province);
CREATE INDEX idx_created_date ON jobs(created_at);

-- Índice compuesto para búsquedas comunes
CREATE INDEX idx_active_jobs ON jobs(status, deadline, city);
```

### Analizar Consultas Lentas

```sql
-- Habilitar análisis de consultas
SET GLOBAL slow_query_log = 'ON';

-- Ver consultas lentas
-- Revisar archivo: /var/log/mysql/slow-query.log

-- Analizar una consulta específica
EXPLAIN SELECT * FROM jobs 
WHERE status = 'active' 
AND city = 'Quito' 
ORDER BY created_at DESC 
LIMIT 10;
```

### Optimizar Tablas

```sql
-- Analizar tabla
ANALYZE TABLE empleatecsql.jobs;

-- Optimizar tabla
OPTIMIZE TABLE empleatecsql.jobs;

-- Para todas las tablas
OPTIMIZE TABLE empleatecsql.users, empleatecsql.employees, 
               empleatecsql.employers, empleatecsql.jobs, 
               empleatecsql.applications;
```

## 🔄 Respaldos (Backups)

### Backup Manual

```bash
# Backup completo
mysqldump -u root -p empleatecsql > empleatec_backup_$(date +%Y%m%d).sql

# Backup comprimido
mysqldump -u root -p empleatecsql | gzip > empleatec_backup_$(date +%Y%m%d).sql.gz

# Backup de estructura solamente (sin datos)
mysqldump -u root -p --no-data empleatecsql > empleatec_schema_$(date +%Y%m%d).sql

# Backup de datos solamente (sin estructura)
mysqldump -u root -p --no-create-info empleatecsql > empleatec_data_$(date +%Y%m%d).sql
```

### Script de Backup Automático

Crea `/home/scripts/backup_empleatec.sh`:

```bash
#!/bin/bash
#
# Script de backup automático para EmpleaTec
#

# Configuración
DB_NAME="empleatecsql"
DB_USER="root"
DB_PASS="tu_password"
BACKUP_DIR="/home/backups/empleatec"
DATE=$(date +%Y%m%d_%H%M%S)
RETENTION_DAYS=30

# Crear directorio si no existe
mkdir -p $BACKUP_DIR

# Realizar backup
mysqldump -u $DB_USER -p$DB_PASS $DB_NAME | gzip > $BACKUP_DIR/empleatec_$DATE.sql.gz

# Verificar que el backup se creó
if [ -f "$BACKUP_DIR/empleatec_$DATE.sql.gz" ]; then
    echo "Backup exitoso: empleatec_$DATE.sql.gz"
    
    # Eliminar backups antiguos
    find $BACKUP_DIR -name "empleatec_*.sql.gz" -type f -mtime +$RETENTION_DAYS -delete
    
    # Log
    echo "$(date): Backup completado - $BACKUP_DIR/empleatec_$DATE.sql.gz" >> /var/log/backup_empleatec.log
else
    echo "ERROR: Backup falló"
    echo "$(date): ERROR - Backup falló" >> /var/log/backup_empleatec.log
    exit 1
fi
```

Hacer ejecutable:
```bash
chmod +x /home/scripts/backup_empleatec.sh
```

### Programar Backups con Cron

```bash
# Editar crontab
crontab -e

# Backup diario a las 2:00 AM
0 2 * * * /home/scripts/backup_empleatec.sh

# Backup cada 6 horas
0 */6 * * * /home/scripts/backup_empleatec.sh
```

### Restaurar desde Backup

```bash
# Descomprimir si está comprimido
gunzip empleatec_backup_20250115.sql.gz

# Restaurar base de datos
mysql -u root -p empleatecsql < empleatec_backup_20250115.sql

# O crear nueva base de datos y restaurar
mysql -u root -p
CREATE DATABASE empleatecsql_restored;
EXIT;

mysql -u root -p empleatecsql_restored < empleatec_backup_20250115.sql
```

## 📊 Monitoreo de la Base de Datos

### Consultas Útiles de Monitoreo

```sql
-- Ver estadísticas de tablas
SELECT 
    table_name AS 'Tabla',
    ROUND((data_length + index_length) / 1024 / 1024, 2) AS 'Tamaño (MB)',
    table_rows AS 'Filas'
FROM information_schema.TABLES
WHERE table_schema = 'empleatecsql'
ORDER BY (data_length + index_length) DESC;

-- Ver conexiones activas
SHOW FULL PROCESSLIST;

-- Ver variables de estado
SHOW STATUS LIKE 'Threads_connected';
SHOW STATUS LIKE 'Queries';
SHOW STATUS LIKE 'Slow_queries';

-- Ver configuración actual
SHOW VARIABLES LIKE 'max_connections';
SHOW VARIABLES LIKE 'innodb_buffer_pool_size';
```

### Herramientas de Monitoreo

1. **mysqladmin** (línea de comandos):
```bash
# Ver estado
mysqladmin -u root -p status

# Monitoreo continuo
mysqladmin -u root -p -i 2 status

# Ver variables
mysqladmin -u root -p variables
```

2. **MySQL Workbench** (GUI):
- Performance Dashboard
- Server Status
- Client Connections

3. **phpMyAdmin**:
- Pestaña "Estado"
- Muestra estadísticas y gráficos

## 🔧 Mantenimiento Regular

### Checklist Semanal

```sql
-- 1. Analizar tablas
ANALYZE TABLE empleatecsql.jobs, empleatecsql.applications;

-- 2. Verificar fragmentación
SELECT 
    table_name,
    ROUND(data_free / 1024 / 1024, 2) AS 'Fragmentación (MB)'
FROM information_schema.TABLES
WHERE table_schema = 'empleatecsql'
AND data_free > 0;

-- 3. Optimizar si es necesario
OPTIMIZE TABLE empleatecsql.jobs;
```

### Checklist Mensual

```bash
# 1. Backup completo
mysqldump -u root -p empleatecsql > backup_mensual_$(date +%Y%m).sql

# 2. Verificar logs de errores
sudo tail -100 /var/log/mysql/error.log

# 3. Revisar consultas lentas
sudo tail -50 /var/log/mysql/slow-query.log

# 4. Verificar espacio en disco
df -h
```

## 📝 Datos de Prueba

Para poblar la base de datos con datos de prueba:

```sql
-- Insertar usuarios de prueba
INSERT INTO users (email, password, user_type, status, email_verified) VALUES
('admin@empleatec.com', MD5('admin123'), 'admin', 'active', 1),
('empleado1@test.com', MD5('test123'), 'employee', 'active', 1),
('empresa1@test.com', MD5('test123'), 'employer', 'active', 1);

-- Insertar empleado de prueba
INSERT INTO employees (user_id, first_name, last_name, cedula, phone, city) VALUES
(2, 'Juan', 'Pérez', '1234567890', '0999123456', 'Quito');

-- Insertar empresa de prueba
INSERT INTO employers (user_id, company_name, ruc, city) VALUES
(3, 'Tech Solutions S.A.', '1234567890001', 'Quito');

-- Insertar oferta de prueba
INSERT INTO jobs (employer_id, title, description, job_type, location, status) VALUES
(1, 'Desarrollador Junior', 'Buscamos desarrollador con React', 'full-time', 'Quito', 'active');
```

---

**Siguiente**: Configura el [Módulo Administrador](./modulo-administrador.md) para gestión del sistema.
export default [
  require("C:\\docusaurus\\proyecto-manualUsuario\\node_modules\\infima\\dist\\css\\default\\default.css"),
  require("C:\\docusaurus\\proyecto-manualUsuario\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages"),
  require("C:\\docusaurus\\proyecto-manualUsuario\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress"),
  require("C:\\docusaurus\\proyecto-manualUsuario\\src\\css\\custom.css"),
];

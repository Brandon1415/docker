// @ts-check
import {themes as prismThemes} from 'prism-react-renderer';

/** @type {import('@docusaurus/types').Config} */
const config = {
  title: 'Manual de Usuario - EmpleaTec',
  tagline: 'Guía completa para usuarios del sistema',
  favicon: 'img/favicon.ico',

  url: 'https://your-docusaurus-site.example.com',
  baseUrl: '/',

  organizationName: 'tu-organizacion',
  projectName: 'proyecto-manual-usuario',

  onBrokenLinks: 'throw',
  
  // ✅ CORRECCIÓN: Movido a markdown.hooks según la nueva estructura
  // onBrokenMarkdownLinks: 'warn',  // ❌ DEPRECATED (obsoleto)

  // ✅ SOLUCIÓN: Configuración actualizada para Docusaurus v3+
  markdown: {
    hooks: {
      onBrokenMarkdownLinks: 'warn',      // ← Nueva ubicación
      onBrokenMarkdownImages: 'ignore',   // ← Ignora imágenes rotas
    },
  },

  i18n: {
    defaultLocale: 'es',
    locales: ['es'],
  },

  presets: [
    [
      'classic',
      /** @type {import('@docusaurus/preset-classic').Options} */
      ({
        docs: {
          sidebarPath: './sidebars.js',
        },
        blog: {
          showReadingTime: true,
          feedOptions: {
            type: ['rss', 'atom'],
            xslt: true,
          },
          onInlineTags: 'warn',
          onInlineAuthors: 'warn',
          onUntruncatedBlogPosts: 'warn',
        },
        theme: {
          customCss: './src/css/custom.css',
        },
      }),
    ],
  ],

  themeConfig:
    /** @type {import('@docusaurus/preset-classic').ThemeConfig} */
    ({
      image: 'img/docusaurus-social-card.jpg',
      navbar: {
        title: 'EmpleaTec',
        logo: {
          alt: 'Logo EmpleaTec',
          src: 'img/logo.svg',
        },
        items: [
          {
            type: 'docSidebar',
            sidebarId: 'tutorialSidebar',
            position: 'left',
            label: 'Tutorial',
          },
          {
            type: 'docSidebar',
            sidebarId: 'manualUsuarioSidebar',
            position: 'left',
            label: 'Manual de Usuario',
          },
          {
            type: 'docSidebar',
            sidebarId: 'manualTecnicoSidebar',
            position: 'left',
            label: 'Introduccion',
          },
          {to: '/blog', label: 'Blog', position: 'left'},
          {
            href: 'https://github.com/facebook/docusaurus',
            label: 'GitHub',
            position: 'right',
          },
        ],
      },
      footer: {
        style: 'dark',
        links: [
          {
            title: 'Documentación',
            items: [
              {
                label: 'Manual de Usuario',
                to: '/docs/intro',
              },
              {
                label: 'Tutorial',
                to: '/docs/tutorial-basics/create-a-document',
              },
            ],
          },
          {
            title: 'Comunidad',
            items: [
              {
                label: 'Stack Overflow',
                href: 'https://stackoverflow.com/questions/tagged/docusaurus',
              },
              {
                label: 'Discord',
                href: 'https://discordapp.com/invite/docusaurus',
              },
              {
                label: 'Twitter',
                href: 'https://twitter.com/docusaurus',
              },
            ],
          },
          {
            title: 'Más',
            items: [
              {
                label: 'Blog',
                to: '/blog',
              },
              {
                label: 'GitHub',
                href: 'https://github.com/facebook/docusaurus',
              },
            ],
          },
        ],
        copyright: `Copyright © ${new Date().getFullYear()} EmpleaTec - Instituto Nelson Torres. Construido con Docusaurus.`,
      },
      prism: {
        theme: prismThemes.github,
        darkTheme: prismThemes.dracula,
      },
    }),
};

export default config;
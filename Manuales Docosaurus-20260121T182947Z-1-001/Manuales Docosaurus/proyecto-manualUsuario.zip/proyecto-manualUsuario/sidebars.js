// @ts-check

/** @type {import('@docusaurus/plugin-content-docs').SidebarsConfig} */
const sidebars = {
  
  // =====================================================
  // SIDEBAR: TUTORIAL (por defecto de Docusaurus)
  // =====================================================
  tutorialSidebar: [
    {
      type: 'category',
      label: 'Tutorial',
      items: [
        'tutorial-basics/create-a-document',
        'tutorial-basics/create-a-blog-post',
        'tutorial-basics/create-a-page',
        'tutorial-basics/markdown-features',
        'tutorial-basics/deploy-your-site',
        'tutorial-basics/congratulations',
      ],
    },
  ],

  // =====================================================
  // SIDEBAR: MANUAL DE USUARIO (tu contenido principal)
  // =====================================================
  // CORRECCIÓN: El sidebar debe ser un array directamente, 
  // no un objeto con otra categoría dentro
  manualUsuarioSidebar: [
    // Documento principal de introducción
    'intro',
    
    // Categoría: Perfiles
    {
      type: 'category',
      label: 'Perfiles',
      collapsed: false,
      items: [
        'perfiles/perfil-publico',
        'perfiles/perfil-empresa',
        'perfiles/perfil-usuario',
      ],
    },
    
    // Categoría: Funcionalidades
    {
      type: 'category',
      label: 'Funcionalidades',
      collapsed: false,
      items: [
        'funcionalidades/registro',
        'funcionalidades/inicio-sesion',
        'funcionalidades/recuperar-contraseña',
      ],
    },
  ],

  // =====================================================
  // SIDEBAR: MANUAL TÉCNICO (opcional)
  // =====================================================
  manualTecnicoSidebar: [
    {
      type: 'category',
      label: 'Introduccion',
      items: [
        'Introduccion/intro',
        'Introduccion/requisitos-acceso',
        'Introduccion/ingreso-sistema',
      ],
    },
  ],
};

module.exports = sidebars;

/**
 * EXPLICACIÓN DEL ERROR Y LA CORRECCIÓN:
 * 
 * ❌ INCORRECTO (lo que tenías antes):
 * manualUsuarioSidebar: [
 *   {
 *     type: 'category',
 *     label: 'Manual de Usuario',  // ← Categoría innecesaria extra
 *     items: [
 *       'intro',
 *       { type: 'category', label: 'Perfiles', ... }
 *     ]
 *   }
 * ]
 * 
 * ✅ CORRECTO (estructura actual):
 * manualUsuarioSidebar: [
 *   'intro',                        // ← Documento directo
 *   { type: 'category', label: 'Perfiles', ... }  // ← Categoría directa
 * ]
 * 
 * RAZÓN:
 * - Cada sidebar (tutorialSidebar, manualUsuarioSidebar, etc.) debe ser 
 *   un ARRAY de items directamente
 * - No necesitas envolver todo en una categoría adicional
 * - Las categorías van dentro del array, no envolviendo el array
 * 
 * ESTRUCTURA CORRECTA:
 * nombreDelSidebar: [
 *   'documento1',                    // item directo
 *   'documento2',                    // item directo
 *   { type: 'category', ... },       // categoría
 *   { type: 'category', ... },       // otra categoría
 * ]
 */
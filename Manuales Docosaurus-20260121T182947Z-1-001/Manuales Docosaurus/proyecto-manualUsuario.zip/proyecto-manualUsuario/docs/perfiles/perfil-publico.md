---
sidebar_position: 1
title: Perfil Público
---

# Perfil Público

El perfil público es accesible sin necesidad de iniciar sesión y permite conocer información básica sobre la plataforma y las entidades que se encuentran registradas en ella.

## Características del Perfil Público

### 1. Página Principal

Al acceder al perfil público, se muestra la página principal que contiene:

- **Nombre de la Institución**: La institución que tiene la licencia para el uso de la plataforma
- **Información de Licencia**: Una breve nota indicando que la institución está autorizada para utilizar y distribuir la plataforma
- **QR de Descarga**: Un código QR que permite descargar la aplicación móvil directamente

![Texto alternativo](/img/perfilP.png)

### 2. Entidades Registradas

Debajo de la información principal, se listan las entidades registradas en la plataforma, con los siguientes detalles:

- **Nombre de la Entidad**: La razón social o nombre completo
- **Descripción Breve**: Una pequeña descripción que puede incluir su sector de actividad o misión
- **Logo**: Imagen representativa de la entidad

:::info Nota
Las entidades mostradas en el perfil público son aquellas que han autorizado la visualización de su información.
:::

### 3. Información Adicional

El perfil público también puede mostrar:

- Lista de servicios disponibles
- Estadísticas generales de la plataforma
- Noticias o anuncios importantes

### 4. Usuarios Registrados

En algunas configuraciones, el perfil público muestra una lista de usuarios activos que han optado por hacer visible su perfil, ofreciendo:

- Nombre del usuario
- Profesión o área de especialización
- Ubicación general

:::warning Privacidad
Los usuarios pueden configurar la visibilidad de su perfil desde las opciones de privacidad.
:::

![Texto alternativo](/img/personas.png)

## Ventajas del Perfil Público

✅ Acceso sin necesidad de registro  
✅ Vista previa de la plataforma  
✅ Información actualizada de entidades  
✅ Descarga rápida de la app móvil

## Navegación

Desde el perfil público puedes:

- **Registrarte**: Crear una cuenta nueva
- **Iniciar Sesión**: Acceder a tu cuenta existente
- **Explorar**: Navegar por la información pública disponible

## Próximos Pasos

Si deseas acceder a todas las funcionalidades de la plataforma, procede a:

- [Registrarte como Usuario](../funcionalidades/registro#registro-usuario)
- [Registrarte como Empresa](./perfil-empresa#registro)
- [Iniciar Sesión](../funcionalidades/inicio-sesion)
# Perfil de Usuario (Graduado)

El **Perfil de Usuario** es para graduados del Instituto Nelson Torres que buscan oportunidades laborales. Este perfil te permite postularte a ofertas, crear tu perfil profesional y ser encontrado por empresas.

![Dashboard Usuario](/img/manual/dashboard-usuario.png)

## 👤 ¿Qué es el Perfil de Usuario?

Es tu cuenta personal en EmpleaTec que te permite:
- Crear y gestionar tu perfil profesional completo
- Subir tu CV y certificaciones
- Buscar y postularte a ofertas de empleo
- Seguimiento de tus aplicaciones
- Ser contactado por empresas interesadas en tu perfil

## ✨ Funcionalidades Completas

### 1. Dashboard Personal

Al iniciar sesión verás tu panel principal con:


![Texto alternativo](/img/PerfilS.png)


### 2. Crear y Gestionar tu Perfil Profesional

Un perfil completo aumenta tus oportunidades. Sigue estos pasos:

![Perfil Usuario Completo](/img/manual/perfil-usuario-completo.png)

#### 📸 Foto de Perfil

1. Haz clic en **"Mi Perfil"** en el menú
2. Clic en el ícono de cámara 📷 sobre tu foto
3. Selecciona una foto de tu computadora
4. Ajusta el recorte (cuadrado)
5. Haz clic en **"Guardar"**

:::tip Foto Profesional
- Usa fondo neutro
- Viste formal o business casual
- Sonríe naturalmente
- Solo tú en la foto (no selfies grupales)
- Resolución mínima: 400x400px
- Formato: JPG o PNG (máx 2MB)
:::

#### 👨‍💼 Información Personal

Completa estos campos obligatorios:

| Campo | Ejemplo | Validación |
|-------|---------|------------|
| **Nombre Completo** | Juan Carlos Pérez | Requerido |
| **Cédula** | 1234567890 | 10 dígitos |
| **Fecha de Nacimiento** | 15/03/1998 | Mayor de 18 años |
| **Teléfono** | 0999123456 | 10 dígitos |
| **Correo Electrónico** | juan.perez@email.com | Formato válido |
| **Dirección** | Av. Principal y Secundaria | Opcional |
| **Ciudad** | Quito | Requerido |
| **Provincia** | Pichincha | Requerido |

#### 🎓 Educación

Agrega tu formación académica:

1. En **"Educación"**, haz clic en **"+ Agregar Educación"**
2. Completa el formulario:

```
┌─────────────────────────────────────────┐
│ Agregar Educación                       │
├─────────────────────────────────────────┤
│ Nivel de Estudios:                      │
│ [▼ Tecnología Superior]                 │
│                                          │
│ Institución Educativa:                  │
│ [Instituto Nelson Torres           ]    │
│                                          │
│ Título Obtenido:                        │
│ [Tecnólogo en Desarrollo de Software]   │
│                                          │
│ Área de Estudio:                        │
│ [▼ Tecnología de la Información]        │
│                                          │
│ Fecha de Inicio:                        │
│ [09/2019]                               │
│                                          │
│ Fecha de Graduación:                    │
│ [06/2022]   ☐ Actualmente estudio aquí │
│                                          │
│ Promedio Final (opcional):              │
│ [9.2]                                   │
│                                          │
│ [ Cancelar ]      [ Guardar ]           │
└─────────────────────────────────────────┘
```

3. Puedes agregar múltiples estudios (cursos, certificaciones, etc.)

#### 💼 Experiencia Laboral

Si has trabajado anteriormente:

1. En **"Experiencia"**, haz clic en **"+ Agregar Experiencia"**
2. Completa los datos:

**Información del Empleo:**
- Nombre de la empresa
- Cargo/Puesto desempeñado
- Tipo de empleo (Tiempo completo, medio tiempo, pasantía)
- Ubicación (ciudad)

**Período:**
- Fecha de inicio (mes/año)
- Fecha de fin (o marca "Actualmente trabajo aquí")

**Descripción:**
- Responsabilidades principales (usa viñetas)
- Logros específicos
- Tecnologías o herramientas utilizadas

```
Ejemplo de descripción:
• Desarrollé 3 aplicaciones web usando React y Node.js
• Colaboré con equipo de 5 personas en metodología Scrum
• Incrementé la eficiencia del proceso en un 30%
• Mantuve bases de datos MySQL y MongoDB
```

:::tip Destaca tus Logros
En lugar de solo listar tareas, menciona **resultados concretos**:
- ❌ "Responsable de ventas"
- ✅ "Aumenté las ventas en un 25% en 6 meses"
:::

#### 🛠️ Habilidades y Competencias

Agrega todas tus habilidades relevantes:

1. En **"Habilidades"**, haz clic en **"+ Agregar Habilidad"**
2. Escribe la habilidad o selecciona de la lista sugerida
3. Selecciona tu nivel de dominio:
   - 🔵 **Básico**: Conocimiento introductorio
   - 🟢 **Intermedio**: Uso regular, experiencia práctica
   - 🟠 **Avanzado**: Dominio completo, puedo enseñar a otros
   - 🔴 **Experto**: Referente en el tema

**Tipos de habilidades a agregar:**

**Habilidades Técnicas:**
- Lenguajes de programación (Python, Java, JavaScript)
- Software (Microsoft Office, Adobe Photoshop, AutoCAD)
- Herramientas (Git, Docker, Jira)
- Tecnologías (React, Node.js, MySQL)

**Habilidades Blandas:**
- Trabajo en equipo
- Liderazgo
- Comunicación efectiva
- Resolución de problemas
- Gestión del tiempo

**Idiomas:**
- Español - Nativo
- Inglés - Intermedio
- Francés - Básico

#### 📄 Currículum Vitae (CV)

Tu CV es esencial para las aplicaciones:

1. Ve a **"Mi Perfil"** > **"Documentos"**
2. Haz clic en **"Subir CV"** o **"Cargar Currículum"**
3. Selecciona tu archivo PDF
   - **Formato**: Solo PDF
   - **Tamaño máximo**: 5 MB
   - **Nombre sugerido**: "CV_TuNombre_2025.pdf"
4. Espera la confirmación de carga exitosa

:::warning Importante
- Mantén tu CV actualizado
- Usa un formato profesional y limpio
- Incluye información de contacto
- Revisa ortografía y gramática
- Muchas empresas descargan directamente este documento
:::

#### 📜 Certificaciones

![Certificaciones](/img/manual/certificaciones.png)

Agrega certificaciones que te distingan:

1. En **"Certificaciones"**, haz clic en **"+ Agregar Certificación"**
2. Completa:
   - Nombre de la certificación
   - Institución emisora
   - Fecha de obtención
   - Fecha de expiración (si aplica)
   - ID de credencial (opcional)
   - URL de verificación (opcional)
3. Opcionalmente, sube el certificado PDF

#### ⚙️ Preferencias Laborales

Define qué tipo de trabajo buscas:

```
┌─────────────────────────────────────────┐
│ Preferencias Laborales                  │
├─────────────────────────────────────────┤
│ Tipo de Empleo Deseado:                │
│ ☑ Tiempo completo                       │
│ ☑ Medio tiempo                          │
│ ☐ Freelance                             │
│ ☑ Pasantías                             │
│                                          │
│ Áreas de Interés:                       │
│ ☑ Tecnología                            │
│ ☑ Desarrollo de Software                │
│ ☐ Marketing Digital                     │
│ ☐ Diseño Gráfico                        │
│                                          │
│ Ubicaciones Preferidas:                 │
│ ☑ Quito                                 │
│ ☑ Guayaquil                             │
│ ☐ Cuenca                                │
│ ☑ Remoto                                │
│                                          │
│ Rango Salarial Esperado:                │
│ Mínimo: [$800 ]  Máximo: [$1,500 ]     │
│                                          │
│ Disponibilidad:                         │
│ [▼ Inmediata]                           │
│                                          │
│ ☑ Dispuesto a relocalizarme             │
│                                          │
│ [ Cancelar ]      [ Guardar ]           │
└─────────────────────────────────────────┘
```

### 3. Buscar y Explorar Ofertas

#### Búsqueda Personalizada

1. Ve a **"Buscar Empleos"** en el menú principal
2. Usa la barra de búsqueda y filtros:

**Filtros Disponibles:**
- 📍 **Ubicación**: Ciudad o provincia
- 💼 **Tipo de empleo**: Tiempo completo, medio tiempo, pasantías
- 💰 **Salario**: Rango salarial deseado
- 📊 **Nivel de experiencia**: Sin experiencia, junior, senior
- 🏢 **Categoría**: Área profesional
- 📅 **Fecha**: Publicadas hoy, esta semana, este mes
- 🔄 **Modalidad**: Presencial, híbrido, remoto

#### Ofertas Recomendadas

EmpleaTec te muestra ofertas basadas en:
- Tu perfil y habilidades
- Tu experiencia laboral
- Tus preferencias laborales
- Ofertas que empresas similares buscan en tu perfil

#### Guardar Ofertas Favoritas

¿Encontraste algo interesante pero no estás listo para aplicar?

1. En el detalle de la oferta, haz clic en la **estrella** ⭐
2. La oferta se guarda en **"Mis Favoritos"**
3. Accede cuando quieras desde el menú
4. Para eliminar, vuelve a hacer clic en la estrella

### 4. Postularse a Ofertas de Empleo

#### Proceso de Aplicación

1. **Encuentra** una oferta que te interese
2. Haz clic en **"Ver Detalles"**
3. Lee completamente la descripción y requisitos
4. Verifica que tu perfil esté completo (mínimo 80%)
5. Haz clic en **"Postularme"** o **"Aplicar"**

#### Formulario de Aplicación

Se abrirá un formulario con:

```
┌─────────────────────────────────────────┐
│ Aplicar a: Desarrollador Full Stack     │
├─────────────────────────────────────────┤
│ ✓ Tu perfil está completo al 90%       │
│ ✓ Tu CV está actualizado                │
│ ✓ Información de contacto correcta      │
│                                          │
│ Carta de Presentación (opcional):       │
│ ┌─────────────────────────────────────┐ │
│ │ Me interesa esta posición porque... │ │
│ │                                     │ │
│ │ (Máximo 300 palabras)               │ │
│ └─────────────────────────────────────┘ │
│                                          │
│ Documentos a enviar:                     │
│ ☑ CV (curriculum_juan_perez.pdf)        │
│ ☐ Portafolio (opcional)                 │
│   [ Subir archivo ]                      │
│                                          │
│ [ Cancelar ]      [ Enviar Aplicación ] │
└─────────────────────────────────────────┘
```

#### Carta de Presentación

:::tip Escribe una Buena Carta
Tu carta debe incluir:
1. **Por qué te interesa** el puesto
2. **Habilidades relevantes** que coincidan con requisitos
3. **Experiencia relacionada** (si tienes)
4. **Qué puedes aportar** a la empresa

Ejemplo:
```
Estimados señores de [Empresa],

Me dirijo a ustedes para expresar mi interés en la posición 
de Desarrollador Full Stack. Como recién graduado del Instituto 
Nelson Torres en Desarrollo de Software, he adquirido sólidos 
conocimientos en React, Node.js y MySQL.

Durante mi formación, desarrollé 3 proyectos web completos que 
demuestran mi capacidad para crear aplicaciones escalables. 
Además, cuento con certificación en JavaScript ES6+.

Estoy entusiasmado por aportar mis habilidades técnicas y mi 
capacidad de aprendizaje rápido a su equipo.

Quedo atento a su respuesta.

Atentamente,
Juan Pérez
```
:::

### 5. Gestionar tus Aplicaciones

#### Ver Aplicaciones Enviadas

1. Ve a **"Mis Aplicaciones"** en el menú
2. Verás todas tus postulaciones con:

```
┌─────────────────────────────────────────────────┐
│ Mis Aplicaciones (5)              [🔍 Buscar]  │
├─────────────────────────────────────────────────┤
│                                                  │
│ 💼 Desarrollador Junior                         │
│ 🏢 Tech Solutions S.A.                          │
│ 📅 Aplicado: 15 Ene 2025                        │
│ 📊 Estado: 🟢 Preseleccionado                   │
│ [Ver detalles]                                  │
│                                                  │
│ ─────────────────────────────────────────────  │
│                                                  │
│ 💼 Diseñador Gráfico                            │
│ 🏢 Creative Agency                              │
│ 📅 Aplicado: 12 Ene 2025                        │
│ 📊 Estado: 🟡 En revisión                       │
│ [Ver detalles]                                  │
│                                                  │
│ ─────────────────────────────────────────────  │
│                                                  │
│ 💼 Asistente Administrativo                     │
│ 🏢 Corporación XYZ                              │
│ 📅 Aplicado: 08 Ene 2025                        │
│ 📊 Estado: 🔴 No seleccionado                   │
│ [Ver detalles]                                  │
└─────────────────────────────────────────────────┘
```

#### Estados de Aplicación

Tu aplicación puede tener diferentes estados:

| Estado | Ícono | Significado | Qué hacer |
|--------|-------|-------------|-----------|
| **Enviada** | 📨 | Aplicación recibida | Esperar respuesta |
| **En revisión** | 🟡 | La empresa está evaluando | Mantente atento |
| **Preseleccionado** | 🟢 | Pasaste a siguiente fase | Prepárate para entrevista |
| **Entrevista programada** | 📞 | Te contactarán pronto | Revisa tu correo/teléfono |
| **Rechazada** | 🔴 | No fuiste seleccionado | Sigue aplicando a otras |
| **Contratado** | ⭐ | ¡Felicitaciones! | Has sido contratado |

#### Detalle de Aplicación

Haz clic en cualquier aplicación para ver:
- Información completa de la oferta
- Tu carta de presentación enviada
- Documentos adjuntos
- Historial de cambios de estado
- Fecha y hora de cada actualización
- Mensajes de la empresa (si hay)

#### Cancelar una Aplicación

Si cambias de opinión:

1. Abre la aplicación específica
2. Haz clic en **"Opciones"** (⋮)
3. Selecciona **"Cancelar Aplicación"**
4. Confirma la acción

:::warning Atención
- No puedes deshacer esta acción
- La empresa será notificada
- Si quieres volver a aplicar, tendrás que hacerlo nuevamente
:::

### 6. Notificaciones y Alertas

#### Tipos de Notificaciones

Recibirás notificaciones cuando:
- 🆕 Hay nuevas ofertas que coinciden con tu perfil
- 📊 Cambia el estado de tus aplicaciones
- 💬 Una empresa te envía un mensaje
- ⭐ Una oferta guardada está por expirar
- ⚠️ Tu perfil está incompleto

#### Configurar Notificaciones

1. Ve a **"Configuración"** > **"Notificaciones"**
2. Activa/desactiva cada tipo:

```
┌─────────────────────────────────────────┐
│ Configuración de Notificaciones         │
├─────────────────────────────────────────┤
│                                          │
│ ☑ Nuevas ofertas recomendadas           │
│   Frecuencia: [▼ Diaria]                │
│                                          │
│ ☑ Cambios en mis aplicaciones           │
│   ☑ Por correo  ☑ En plataforma         │
│                                          │
│ ☑ Mensajes de empresas                  │
│   ☑ Por correo  ☑ En plataforma         │
│                                          │
│ ☑ Ofertas favoritas por expirar         │
│   Avisar con: [▼ 3 días de anticipación]│
│                                          │
│ ☐ Recordatorios de perfil incompleto    │
│                                          │
│ ☑ Boletín semanal de EmpleaTec          │
│                                          │
│ [ Cancelar ]      [ Guardar Cambios ]   │
└─────────────────────────────────────────┘
```

### 7. Mensajes y Comunicación

#### Recibir Mensajes

Las empresas pueden contactarte directamente:

1. Ve a **"Mensajes"** en el menú
2. Verás conversaciones activas
3. Los mensajes sin leer tienen un badge rojo: **Mensajes (3)**

#### Leer y Responder

1. Haz clic en una conversación para abrirla
2. Lee el mensaje de la empresa
3. Para responder:
   - Escribe tu mensaje en el cuadro de texto
   - Sé profesional y cortés
   - Revisa ortografía antes de enviar
   - Haz clic en **"Enviar"**

:::tip Responde Rápido
Las empresas valoran candidatos comunicativos. Intenta responder en menos de 24 horas.
:::

### 8. Configuración de la Cuenta

#### Cambiar Contraseña

1. Ve a **"Configuración"** > **"Seguridad"**
2. Haz clic en **"Cambiar Contraseña"**
3. Ingresa:
   - Contraseña actual
   - Nueva contraseña
   - Confirmar nueva contraseña
4. Haz clic en **"Actualizar"**

#### Privacidad del Perfil

Controla quién puede ver tu información:

```
┌─────────────────────────────────────────┐
│ Configuración de Privacidad             │
├─────────────────────────────────────────┤
│                                          │
│ Visibilidad del Perfil:                 │
│ ⚫ Público (recomendado)                 │
│    Las empresas pueden encontrarte       │
│                                          │
│ ○ Solo visible para empresas a las que │
│   he aplicado                            │
│                                          │
│ ○ Privado                                │
│    No apareces en búsquedas              │
│                                          │
│ ☑ Permitir que empresas me contacten    │
│                                          │
│ ☑ Mostrar mi foto de perfil              │
│                                          │
│ Mi CV es visible:                        │
│ ⚫ Para empresas a las que apliqué       │
│ ○ Para todas las empresas registradas   │
│ ○ Solo cuando yo lo comparta             │
│                                          │
│ [ Cancelar ]      [ Guardar Cambios ]   │
└─────────────────────────────────────────┘
```

## 📊 Medidor de Completitud del Perfil

EmpleaTec calcula qué tan completo está tu perfil:

```
Tu perfil está completo al: ████████░░ 85%

Completa estos elementos para llegar al 100%:
□ Agregar una certificación
□ Completar sección "Acerca de mí"
□ Agregar 2 habilidades más
```

**Beneficios de un perfil 100% completo:**
- 🚀 Apareces más alto en búsquedas de empresas
- ⭐ Recibes más recomendaciones de ofertas
- 💼 Aumentas tus probabilidades de ser contactado
- 📈 Las empresas tienen más confianza en tu profesionalismo

## 💡 Consejos para el Éxito

### Optimiza tu Perfil

1. **Completa TODO** - Un perfil incompleto reduce visibilidad
2. **Usa palabras clave** relevantes a tu industria
3. **Actualiza regularmente** - Los perfiles activos destacan
4. **Sé específico** en logros y responsabilidades

### Al Buscar Empleo

1. **Aplica temprano** - Las ofertas nuevas tienen menos competencia
2. **Personaliza aplicaciones** - Las cartas genéricas se notan
3. **Sigue instrucciones** - Lee y cumple todos los requisitos
4. **Calidad sobre cantidad** - Aplica solo a ofertas relevantes

### Preparación para Entrevistas

1. **Investiga la empresa** - Conoce su misión, valores, productos
2. **Prepara respuestas** a preguntas comunes
3. **Ten preguntas listas** para el entrevistador
4. **Llega puntual** (5-10 minutos antes)
5. **Viste apropiadamente** según la cultura de la empresa

## 📱 Sincronización con App Móvil

Usa la misma cuenta en la app móvil:
- Tus datos se sincronizan automáticamente
- Las aplicaciones son visibles en ambas plataformas
- Los favoritos se comparten
- Las notificaciones llegan a ambos

---

**Siguiente**: Conoce el [Perfil de Empresa](./perfil-empresa.md) para entender cómo las empresas usan la plataforma.
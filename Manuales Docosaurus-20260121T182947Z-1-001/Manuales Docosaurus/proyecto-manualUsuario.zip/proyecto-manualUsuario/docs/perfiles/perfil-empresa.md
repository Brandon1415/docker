---
sidebar_position: 2
title: Perfil de Empresa
---

# Perfil de Empresa

El perfil de empresa está diseñado para organizaciones que desean utilizar la plataforma para gestionar sus necesidades y conectar con usuarios calificados.

## Registro de Empresa {#registro}

Para registrarte como empresa, sigue estos pasos:

### 1. Acceder al Formulario de Registro

En la página de inicio de la plataforma, haz clic en el botón **"Crear Cuenta Gratis"** o **"Registro de Empresa"** para comenzar el proceso.

![Texto alternativo](/img/loginemp.png)
### 2. Completar el Formulario

Ingresa los siguientes datos:

| Campo | Descripción |
|-------|-------------|
| **Nombre de Empresa** | Razón social de tu organización |
| **Rubro de la Empresa** | Sector o industria a la que pertenece |
| **Correo Electrónico** | Email corporativo válido |
| **Contraseña** | Mínimo 8 caracteres, incluye mayúsculas y números |
| **Confirmar Contraseña** | Debe coincidir con la contraseña anterior |

:::tip Consejo
Usa un correo corporativo para facilitar la verificación de tu empresa.
:::

### 3. Opciones Adicionales

- **Mostrar contraseñas**: Activa esta opción para verificar que las contraseñas sean correctas
- **Términos y Condiciones**: Lee y acepta los términos antes de continuar

### 4. Finalizar Registro

Haz clic en **"Registrar Empresa"** para completar el proceso. Recibirás un correo de confirmación para validar tu cuenta.

<!-- ![Formulario Registro](../../../static/img/manual/formulario-empresa.png) -->

---

## Inicio de Sesión

Si tu empresa ya está registrada:

1. Haz clic en el botón **"Ingresar"**
2. Ingresa tus credenciales:
   - Correo electrónico corporativo
   - Contraseña
3. Haz clic en **"Iniciar Sesión"**

:::note Recuperar Contraseña
Si olvidaste tu contraseña, usa la opción [Recuperar Contraseña](../funcionalidades/recuperar-contraseña)
:::

---

## Completar Información del Perfil

Una vez dentro del perfil, completa la información de la empresa para maximizar la visibilidad y efectividad en la plataforma.

### Información Básica

- **Nombre de Empresa**: Indica el nombre de tu organización
- **Establecida en**: Selecciona el año de fundación
- **Rubro**: Especifica el sector de actividad (ej: Ventas, Tecnología, Servicios)
- **Personas**: Indica el número de empleados de tu empresa
- **Página Web**: Proporciona la URL de tu sitio web corporativo

### Ubicación

- **Ciudad/Pueblo**: Ingresa la ubicación principal
- **Calle**: Detalla la dirección física
- **Código Postal**: Código postal de la ubicación
- **País**: Selecciona el país de operación

### Contacto

- **Teléfono**: Número de contacto corporativo
- **Correo Electrónico**: Email de contacto público

### Descripción de la Empresa

- **Historia de la Empresa**: Describe brevemente la historia y evolución de tu organización
- **Servicios**: Detalla los servicios que ofrece tu empresa
- **Experiencia**: Proporciona información sobre la experiencia y logros en tu sector

### Logo de la Empresa

Carga una imagen que represente el logo de tu empresa:
- Formatos aceptados: JPG, PNG
- Tamaño recomendado: 500x500 px
- Peso máximo: 2 MB

![Texto alternativo](/img/empresas.png)


## Funcionalidades del Perfil de Empresa

### Panel de Control

En la parte derecha del perfil encontrarás las siguientes opciones:

#### 🔵 Publicar Empleo
Utiliza esta función para añadir nuevas ofertas laborales o servicios.

#### 🔑 Cambiar Contraseña
Actualiza la contraseña de acceso desde la configuración de la cuenta para mantener la seguridad.

#### 📝 Descripción Empresa
Agrega o modifica la descripción de la empresa destacando su historia, misión y valores.

#### 🚪 Cerrar Sesión
Recuerda cerrar sesión para proteger la información de perfil de la empresa, especialmente en dispositivos compartidos.

:::warning Importante
Mantén actualizada la información de tu empresa para mejorar tu presencia en la plataforma.
:::

---

## Gestión de Ofertas

Los usuarios con perfil de empresa pueden:

✅ **Publicar ofertas**: Crear nuevas vacantes o servicios  
✅ **Gestionar publicaciones**: Editar y actualizar las ofertas activas  
✅ **Visualizar postulaciones**: Ver candidatos interesados  
✅ **Contactar candidatos**: Comunicarse con perfiles que se ajusten a tus necesidades

---

## Consejos para Empresas

💡 **Completa el 100% de tu perfil** para mayor visibilidad  
💡 **Actualiza regularmente** tu información y ofertas  
💡 **Responde rápido** a las postulaciones recibidas  
💡 **Usa imágenes profesionales** en tu logo y publicaciones

---

## Próximos Pasos

- Aprende a [Publicar una Oferta](#)
- Conoce el [Perfil de Usuario](./perfil-usuario)
- Revisa las [Funcionalidades Avanzadas](#)
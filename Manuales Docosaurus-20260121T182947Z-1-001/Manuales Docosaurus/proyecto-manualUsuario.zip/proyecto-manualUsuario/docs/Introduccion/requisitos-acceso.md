---
sidebar_position: 2
title: Requisitos de Acceso
---

# Requisitos de Acceso

Para utilizar la plataforma de manera óptima y sin interrupciones, asegúrate de cumplir con los siguientes requisitos técnicos.

---

## Navegadores Recomendados

La plataforma funciona correctamente en los navegadores web modernos. Te recomendamos utilizar las versiones más recientes de:

### 🌐 Navegadores Compatibles

| Navegador | Versión Mínima | Recomendación |
|-----------|----------------|---------------|
| **Google Chrome** | Versión 90+ | ⭐ Altamente recomendado |
| **Mozilla Firefox** | Versión 88+ | ⭐ Altamente recomendado |
| **Microsoft Edge** | Versión 90+ | ✅ Recomendado |
| **Safari** | Versión 14+ | ✅ Recomendado (macOS/iOS) |
| **Opera** | Versión 76+ | ✅ Compatible |
| **Brave** | Versión 1.24+ | ✅ Compatible |

:::tip Recomendación Importante
Mantén tu navegador siempre actualizado a la última versión para:
- ✅ Evitar problemas de compatibilidad
- ✅ Mejorar la seguridad
- ✅ Disfrutar de mejor rendimiento
- ✅ Acceder a todas las funcionalidades
:::

### Cómo Verificar la Versión de tu Navegador

**Google Chrome:**
1. Haz clic en los tres puntos (⋮) en la esquina superior derecha
2. Ve a **Ayuda** → **Información de Google Chrome**
3. La versión aparecerá automáticamente

**Mozilla Firefox:**
1. Haz clic en las tres líneas (≡) en la esquina superior derecha
2. Ve a **Ayuda** → **Acerca de Firefox**
3. La versión se mostrará

**Microsoft Edge:**
1. Haz clic en los tres puntos (⋯) en la esquina superior derecha
2. Ve a **Ayuda y comentarios** → **Acerca de Microsoft Edge**

### Navegadores No Recomendados

❌ **Internet Explorer** (cualquier versión) - Ya no recibe soporte  
❌ Versiones desactualizadas de cualquier navegador  
❌ Navegadores móviles desactualizados

---

## Conexión a Internet

### Requisitos de Conectividad

Es necesario contar con una **conexión a internet estable** para acceder y navegar por la plataforma sin interrupciones.

#### Velocidad Recomendada

| Tipo de Uso | Velocidad Mínima | Velocidad Recomendada |
|-------------|------------------|----------------------|
| **Navegación básica** | 1 Mbps | 3 Mbps |
| **Uso estándar** | 3 Mbps | 5 Mbps |
| **Subir archivos** | 5 Mbps | 10 Mbps |
| **Videollamadas** | 5 Mbps | 10+ Mbps |

:::info Nota
Mbps = Megabits por segundo. Puedes verificar tu velocidad en sitios como [speedtest.net](https://www.speedtest.net)
:::

### Tipos de Conexión Compatibles

✅ **Wi-Fi** (Recomendado para uso en casa u oficina)  
✅ **Ethernet/Cable** (Mayor estabilidad)  
✅ **Datos móviles 4G/5G** (Para uso en dispositivos móviles)  
✅ **Conexión compartida** (Hotspot móvil)

### Problemas Comunes de Conexión

**Si experimentas problemas:**

1. **Conexión lenta**
   - Cierra otras aplicaciones que usen internet
   - Reinicia tu router
   - Acércate al router Wi-Fi

2. **Conexión intermitente**
   - Verifica los cables de red
   - Cambia la ubicación de tu dispositivo
   - Contacta a tu proveedor de internet

3. **Sin conexión**
   - Verifica que otros dispositivos puedan conectarse
   - Reinicia tu router/módem
   - Verifica el pago de tu servicio de internet

---

## Dispositivos Compatibles

Puedes acceder a la plataforma desde múltiples tipos de dispositivos:

### 💻 Computadoras de Escritorio y Portátiles

#### Sistemas Operativos Compatibles

| Sistema Operativo | Versión Mínima | Estado |
|-------------------|----------------|--------|
| **Windows** | Windows 10 | ✅ Compatible |
| **macOS** | macOS 10.15 (Catalina) | ✅ Compatible |
| **Linux** | Ubuntu 18.04 o superior | ✅ Compatible |
| **Chrome OS** | Última versión | ✅ Compatible |

#### Especificaciones Recomendadas

**Mínimas:**
- Procesador: Intel Core i3 o equivalente
- RAM: 4 GB
- Espacio en disco: 500 MB libres
- Resolución: 1024x768 px

**Recomendadas:**
- Procesador: Intel Core i5 o superior
- RAM: 8 GB o más
- Espacio en disco: 1 GB libres
- Resolución: 1920x1080 px (Full HD)

### 📱 Dispositivos Móviles

#### Smartphones

| Sistema | Versión Mínima | Estado |
|---------|----------------|--------|
| **Android** | Android 8.0 (Oreo) | ✅ Compatible |
| **iOS** | iOS 13.0 | ✅ Compatible |

#### Tabletas

| Sistema | Versión Mínima | Estado |
|---------|----------------|--------|
| **iPad** | iPadOS 13.0 | ✅ Compatible |
| **Android Tablet** | Android 8.0 | ✅ Compatible |

#### Especificaciones Móviles Recomendadas

**Mínimas:**
- RAM: 2 GB
- Almacenamiento: 100 MB libres
- Pantalla: 4.5 pulgadas

**Recomendadas:**
- RAM: 4 GB o más
- Almacenamiento: 500 MB libres
- Pantalla: 5.5 pulgadas o más

### 📲 Aplicación Móvil

La plataforma ofrece una aplicación móvil nativa para una mejor experiencia:

**Ventajas de la App:**
- ⚡ Mayor velocidad
- 📵 Funcionalidad offline limitada
- 🔔 Notificaciones push
- 📸 Acceso directo a la cámara
- 💾 Mejor gestión de archivos

**Descarga:**
- [Google Play Store](#) (Android)
- [Apple App Store](#) (iOS)
- O escanea el código QR en la página principal

---

## Requisitos Adicionales

### JavaScript

JavaScript **debe estar habilitado** en tu navegador para el correcto funcionamiento de la plataforma.

**Verificar si JavaScript está habilitado:**

**Chrome:**
1. Ve a `chrome://settings/content/javascript`
2. Asegúrate que esté en "Permitido"

**Firefox:**
1. Escribe `about:config` en la barra de direcciones
2. Busca `javascript.enabled`
3. Debe estar en `true`

### Cookies

Las cookies deben estar habilitadas para mantener tu sesión activa y guardar preferencias.

**Habilitar cookies:**

**Chrome:**
1. Configuración → Privacidad y seguridad → Cookies
2. Selecciona "Permitir todas las cookies" o al menos las del sitio

**Firefox:**
1. Opciones → Privacidad y seguridad
2. En "Cookies y datos del sitio", selecciona "Estándar" o "Personalizada"

### Ventanas Emergentes

Algunas funcionalidades pueden requerir ventanas emergentes (pop-ups). Asegúrate de permitirlas para este sitio.

### Almacenamiento Local

La plataforma utiliza almacenamiento local del navegador para mejorar el rendimiento. Asegúrate de tener al menos 50 MB disponibles.

---

## Permisos Necesarios (Dispositivos Móviles)

Para usar todas las funcionalidades en dispositivos móviles, la aplicación puede solicitar los siguientes permisos:

### Permisos Comunes

| Permiso | Uso | Obligatorio |
|---------|-----|-------------|
| **📸 Cámara** | Tomar fotos de perfil, escanear documentos | No |
| **📁 Almacenamiento** | Guardar y cargar archivos | Sí |
| **📞 Teléfono** | Hacer llamadas desde la app | No |
| **📧 Contactos** | Importar referencias | No |
| **📍 Ubicación** | Búsqueda por ubicación | No |
| **🔔 Notificaciones** | Recibir alertas | No |

:::note Privacidad
Todos los permisos son opcionales excepto el acceso al almacenamiento. Puedes revocarlos en cualquier momento desde la configuración de tu dispositivo.
:::

---

## Seguridad y Privacidad

### Certificado SSL/HTTPS

La plataforma utiliza conexión segura (HTTPS). Verifica el candado 🔒 en la barra de direcciones antes de ingresar información sensible.

### Antivirus y Firewall

- Mantén actualizado tu antivirus
- Asegúrate de que tu firewall no bloquee el acceso a la plataforma
- Agrega el sitio a la lista blanca si es necesario

### VPN

Si usas una VPN, asegúrate de que no cause problemas de conexión. Algunas funcionalidades pueden verse afectadas.

---

## Accesibilidad

La plataforma está diseñada para ser accesible:

### Funcionalidades de Accesibilidad

✅ Compatible con lectores de pantalla  
✅ Navegación por teclado  
✅ Contraste ajustable  
✅ Tamaño de texto escalable  
✅ Subtítulos en videos

### Recomendaciones

- Usa el zoom del navegador si necesitas texto más grande (Ctrl/Cmd + +)
- Activa el modo alto contraste en la configuración si lo necesitas
- Usa atajos de teclado para navegación rápida

---

## Resolución de Problemas

### La plataforma no carga correctamente

**Soluciones:**

1. **Actualiza tu navegador** a la última versión
2. **Limpia la caché**:
   - Chrome: Ctrl + Shift + Supr
   - Firefox: Ctrl + Shift + Supr
   - Safari: Cmd + Opt + E
3. **Desactiva extensiones** que puedan interferir
4. **Intenta en modo incógnito** para descartar problemas de caché
5. **Prueba con otro navegador**

### Elementos visuales no se muestran

- Verifica que JavaScript esté habilitado
- Actualiza los drivers de tu tarjeta gráfica
- Reduce el nivel de zoom del navegador a 100%

### Archivos no se cargan

- Verifica el tamaño del archivo (límite típico: 5-10 MB)
- Confirma que el formato sea compatible
- Revisa tu conexión a internet

---

## Lista de Verificación Rápida

Antes de empezar a usar la plataforma, verifica:

- [ ] Navegador actualizado (Chrome, Firefox, Edge o Safari)
- [ ] Conexión a internet estable (mínimo 3 Mbps)
- [ ] JavaScript habilitado
- [ ] Cookies permitidas
- [ ] Dispositivo compatible (PC, Mac, smartphone o tablet)
- [ ] Sistema operativo actualizado
- [ ] Espacio de almacenamiento disponible
- [ ] (Opcional) Aplicación móvil descargada

---

## Soporte Técnico

Si después de verificar todos los requisitos sigues teniendo problemas:

📧 **Email**: soporte@tusistema.com  
📞 **Teléfono**: +593-XXX-XXXX  
💬 **Chat en vivo**: Disponible en la página principal  
⏰ **Horario**: Lunes a Viernes, 8:00 AM - 6:00 PM

---

## Próximos Pasos

Ahora que conoces los requisitos, continúa con:

- [Ingreso al Sistema](./ingreso-sistema) - Aprende cómo acceder a la plataforma
- [Registro](./funcionalidades/registro) - Crea tu cuenta
- [Inicio de Sesión](./funcionalidades/inicio-sesion) - Accede a tu cuenta existente
# Bienvenido a EmpleaTec

¡Bienvenido al manual de usuario de **EmpleaTec**! Esta guía te ayudará a aprovechar al máximo nuestra plataforma de bolsa de empleo.

![Página de inicio](/img/manual/pagina-inicio.png)

## ¿Qué es EmpleaTec?

EmpleaTec es una plataforma tecnológica híbrida (web y móvil) diseñada para **facilitar la inserción laboral de graduados del Instituto Nelson Torres** y conectarlos eficientemente con empresas en búsqueda de talento.

## 🎯 Objetivos de la Plataforma

- **Para Graduados**: Facilitar la búsqueda de empleo y conexión con empresas
- **Para Empresas**: Acceder a una base de talento calificado del instituto
- **Para el Instituto**: Generar reportes y estadísticas de inserción laboral

## ✨ Características Principales

### 🎓 Para Graduados

- ✅ Crear y gestionar perfil profesional completo
- ✅ Subir CV y certificaciones
- ✅ Buscar ofertas con filtros avanzados
- ✅ Postularse a vacantes en un clic
- ✅ Seguimiento de aplicaciones en tiempo real
- ✅ Recibir notificaciones de nuevas oportunidades

### 🏢 Para Empresas

- ✅ Publicar ofertas de empleo ilimitadas
- ✅ Buscar candidatos por perfil y habilidades
- ✅ Gestionar aplicaciones recibidas
- ✅ Acceder a base de datos de graduados
- ✅ Descargar CVs de candidatos
- ✅ Generar reportes de reclutamiento

### 🌐 Acceso a la Plataforma

EmpleaTec está disponible en:

- **🌐 Plataforma Web**: [https://serviciosint.com/bolsadeempleo/](https://serviciosint.com/bolsadeempleo/)
- **📱 Aplicación Móvil**: Disponible para Android (descarga el APK)

## 📋 Requisitos para Usar EmpleaTec

### Para acceder desde la web:

- Navegador web actualizado (Chrome, Firefox, Edge, Safari)
- Conexión a Internet estable
- Correo electrónico válido
- Documento de identidad (cédula)

### Para usar la app móvil:

- Dispositivo Android 5.0 o superior
- Espacio de almacenamiento: mínimo 50 MB
- Conexión a Internet (WiFi o datos móviles)

## 👥 Tipos de Usuarios

EmpleaTec tiene tres tipos principales de perfiles:

| Tipo de Usuario | Descripción | ¿Quién lo usa? |
|-----------------|-------------|----------------|
| **Perfil Público** | Acceso sin registro para explorar ofertas | Cualquier visitante |
| **Perfil Usuario** | Graduado registrado que busca empleo | Graduados del Instituto |
| **Perfil Empresa** | Empresa que publica ofertas y busca talento | Departamentos de RRHH |

## 🗺️ Cómo Navegar este Manual

Este manual está organizado en secciones fáciles de seguir:

### 1. 👥 Tipos de Perfiles
Conoce los diferentes tipos de usuarios y sus capacidades:
- [Perfil Público](./perfiles/perfil-publico.md) - Explorar sin registro
- [Perfil Usuario](./perfiles/perfil-usuario.md) - Para graduados
- [Perfil Empresa](./perfiles/perfil-empresa.md) - Para empleadores

### 2. ⚙️ Funcionalidades
Aprende a usar las características principales:
- [Registro](./funcionalidades/registro.md) - Cómo crear tu cuenta
- [Inicio de Sesión](./funcionalidades/inicio-sesion.md) - Acceder a tu cuenta
- [Recuperar Contraseña](./funcionalidades/recuperar-contrasena.md) - Restablecer acceso

### 3. 📘 Manual Técnico
Para desarrolladores y administradores del sistema.

## 🚀 Primeros Pasos

### Si eres Graduado:

1. **Explora** las ofertas disponibles sin registrarte
2. **Regístrate** como usuario para aplicar a empleos
3. **Completa tu perfil** al 100% para mejor visibilidad
4. **Sube tu CV** y certificaciones
5. **Comienza a aplicar** a las ofertas que te interesen

### Si eres Empresa:

1. **Regístrate** como empresa
2. **Completa el perfil** de tu empresa
3. **Publica** tu primera oferta de empleo
4. **Busca** candidatos en la base de datos
5. **Gestiona** las aplicaciones recibidas

## 📞 Soporte y Ayuda

Si tienes problemas o preguntas:

- **📧 Correo de soporte**: contacto@empleatec.com
- **📱 Teléfono**: [Contacta al Instituto Nelson Torres]
- **⏰ Horario**: Lunes a Viernes, 8:00 AM - 5:00 PM

## 🎓 Acerca del Instituto Nelson Torres

EmpleaTec es una iniciativa del Instituto Nelson Torres para apoyar la inserción laboral de sus graduados y fortalecer los vínculos con el sector empresarial.

---

**¿Listo para comenzar?** Continúa con la siguiente sección para conocer los [Tipos de Perfiles](./perfiles/perfil-publico.md) disponibles en EmpleaTec.
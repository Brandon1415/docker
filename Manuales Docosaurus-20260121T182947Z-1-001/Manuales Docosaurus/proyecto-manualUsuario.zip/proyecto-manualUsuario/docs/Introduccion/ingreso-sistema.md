---
sidebar_position: 3
title: Ingreso al Sistema
---

# Ingreso al Sistema

Esta sección te guiará paso a paso para acceder a la plataforma y comenzar a utilizarla.

---

## Acceso desde Computadora

### Paso 1: Abrir el Navegador Web

1. Abre tu navegador de preferencia:
   - Google Chrome
   - Mozilla Firefox
   - Microsoft Edge
   - Safari
   - Otros navegadores compatibles

<!--![Navegadores](../../../static/img/manual/navegadores.png)-->

### Paso 2: Ingresar la URL del Sistema

1. Haz clic en la **barra de direcciones** (parte superior del navegador)
2. Escribe o copia la URL del sistema:

```
https://tusistema.com
```

3. Presiona **Enter** en tu teclado

:::tip Consejo
Guarda la página en tus favoritos para acceder más rápido la próxima vez:
- **Chrome/Edge**: Ctrl + D (Windows) o Cmd + D (Mac)
- **Firefox**: Ctrl + D (Windows) o Cmd + D (Mac)
- **Safari**: Cmd + D
:::

### Paso 3: Esperar a que Cargue la Página

La página principal se cargará automáticamente. Verás:

- 🏠 Logo de la plataforma
- 📋 Información general
- 🔘 Botones de acceso ("Ingresar", "Registrarse")
- 📱 Código QR para la app móvil
- 🏢 Lista de empresas registradas (si aplica)

<!--![Página Principal](../../../static/img/manual/pagina-principal-completa.png)-->

---

## Acceso desde Dispositivos Móviles

### Opción 1: Navegador Móvil

#### Para Android

1. Abre **Chrome**, **Firefox** o tu navegador preferido
2. Toca la barra de búsqueda
3. Escribe: `https://tusistema.com`
4. Toca el resultado o presiona "Ir"

#### Para iOS (iPhone/iPad)

1. Abre **Safari** o tu navegador preferido
2. Toca la barra de búsqueda
3. Escribe: `https://tusistema.com`
4. Toca "Ir" en el teclado

:::tip Acceso Rápido Móvil
**Añade un icono a tu pantalla principal:**

**Android:**
1. Abre el menú del navegador (⋮)
2. Selecciona "Añadir a pantalla de inicio"
3. Confirma el nombre y toca "Añadir"

**iOS:**
1. Toca el botón de compartir (□↑)
2. Desplázate y selecciona "Añadir a pantalla de inicio"
3. Confirma y toca "Añadir"
:::

### Opción 2: Aplicación Móvil

Si prefieres usar la aplicación nativa:

#### Descargar desde Tiendas de Aplicaciones

**Android (Google Play):**
1. Abre **Google Play Store**
2. Busca "[Nombre de tu App]"
3. Toca **"Instalar"**
4. Espera a que se complete la descarga
5. Toca **"Abrir"**

**iOS (App Store):**
1. Abre **App Store**
2. Busca "[Nombre de tu App]"
3. Toca el botón de descarga (☁️ o precio)
4. Autentica con Face ID, Touch ID o contraseña
5. Toca **"Abrir"** cuando termine la instalación

#### Escanear Código QR

En la página principal de la web encontrarás un **código QR**:

1. Abre la cámara de tu teléfono
2. Apunta al código QR
3. Toca la notificación que aparece
4. Serás redirigido a la tienda de aplicaciones
5. Descarga e instala la app

<!--![Código QR](../../../static/img/manual/qr-download.png) -->

---

## Primera Visita a la Plataforma

### ¿Qué Verás en la Página Principal?

Al ingresar por primera vez, encontrarás:

#### 1. **Encabezado (Header)**
- Logo de la plataforma
- Menú de navegación
- Botones de acción: "Ingresar" / "Registrarse"

#### 2. **Sección de Bienvenida**
- Título y descripción de la plataforma
- Imagen o video promocional
- Llamado a la acción

#### 3. **Información del Instituto/Institución**
- Nombre de la organización
- Información de licencia
- Datos de contacto

#### 4. **Empresas Registradas**
Lista de empresas u organizaciones que usan la plataforma:
- Logo de la empresa
- Nombre
- Descripción breve
- Enlace para ver más detalles

#### 5. **Usuarios Destacados** (opcional)
Perfiles de usuarios que han dado permiso para aparecer públicamente

#### 6. **Pie de Página (Footer)**
- Enlaces importantes
- Información de contacto
- Redes sociales
- Términos y condiciones

<!-- ![Estructura Página](../../../static/img/manual/estructura-pagina.png)-->

---

## Tipos de Acceso

Desde la página principal, puedes acceder de diferentes formas según tu situación:

### 1. Acceso Público (Sin Registro)

Puedes navegar sin crear cuenta para:

✅ Ver información general de la plataforma  
✅ Conocer empresas registradas  
✅ Leer términos y condiciones  
✅ Ver perfiles públicos  
✅ Contactar al soporte

**Limitaciones:**
- ❌ No puedes postularte o interactuar
- ❌ No puedes guardar información
- ❌ No tienes acceso a funciones personalizadas

### 2. Acceso como Usuario Registrado

Haz clic en **"Ingresar"** si ya tienes cuenta:

- Ingresa tus credenciales (correo y contraseña)
- Accede a tu perfil personal
- Usa todas las funcionalidades

👉 [Guía de Inicio de Sesión](./funcionalidades/inicio-sesion)

### 3. Crear Nueva Cuenta

Haz clic en **"Registrarse"** para crear una cuenta nueva:

**Opciones disponibles:**
- 👤 Registro como Usuario/Persona
- 🏢 Registro como Empresa

👉 [Guía de Registro](./funcionalidades/registro)

---

## Navegación por la Interfaz

### Menú Principal

El menú de navegación te permite moverte por diferentes secciones:

| Opción | Descripción |
|--------|-------------|
| **Inicio** | Página principal |
| **Acerca de** | Información sobre la plataforma |
| **Empresas** | Lista de empresas registradas |
| **Contacto** | Formulario de contacto |
| **FAQ** | Preguntas frecuentes |

### Barra de Búsqueda

Si está disponible, puedes buscar:
- Empresas específicas
- Perfiles de usuarios
- Información general

### Botones de Acción Rápida

Los botones principales que verás:

🔵 **Ingresar**: Para usuarios registrados  
🟢 **Registrarse**: Para crear una cuenta nueva  
📱 **Descargar App**: Enlace a tiendas de aplicaciones  
❓ **Ayuda**: Acceso a soporte o FAQ

---

## Configuración Inicial del Navegador

### Aceptar Cookies

La primera vez que visites el sitio, verás un aviso sobre cookies:

1. Lee la información sobre el uso de cookies
2. Haz clic en **"Aceptar"** o **"Aceptar todas"**
3. O personaliza tus preferencias si lo deseas

:::info ¿Qué son las cookies?
Las cookies son pequeños archivos que mejoran tu experiencia al recordar tus preferencias y mantener tu sesión activa.
:::

### Permitir Notificaciones (Opcional)

El sitio puede solicitar permiso para enviar notificaciones:

- **Permitir**: Recibirás alertas importantes
- **Bloquear**: No recibirás notificaciones (puedes activarlo después)

---

## Problemas Comunes al Ingresar

### ❌ La página no carga

**Posibles causas y soluciones:**

1. **Sin conexión a internet**
   - Verifica tu conexión Wi-Fi o datos móviles
   - Intenta abrir otros sitios web
   - Reinicia tu router

2. **URL incorrecta**
   - Verifica que hayas escrito correctamente la dirección
   - Copia y pega la URL desde una fuente confiable
   - Elimina espacios antes o después de la URL

3. **Problema del servidor**
   - El sitio puede estar en mantenimiento
   - Espera unos minutos y vuelve a intentar
   - Revisa redes sociales oficiales para anuncios

4. **Caché del navegador**
   - Limpia la caché: Ctrl + Shift + Supr (Windows) o Cmd + Shift + Supr (Mac)
   - Intenta en modo incógnito: Ctrl + Shift + N (Windows) o Cmd + Shift + N (Mac)
   - Reinicia el navegador

### ❌ La página se ve mal o rota

**Soluciones:**

1. **Actualiza el navegador** a la última versión
2. **Desactiva extensiones** que puedan interferir
3. **Ajusta el zoom** al 100% (Ctrl/Cmd + 0)
4. **Intenta con otro navegador**
5. **Limpia caché y cookies**

### ❌ Mensajes de "Sitio no seguro"

Si ves advertencias de seguridad:

1. **Verifica la URL**: Debe empezar con `https://` (con la 's')
2. **Busca el candado** 🔒 en la barra de direcciones
3. **No continúes** si el navegador advierte de peligro real
4. **Contacta al soporte** para reportar el problema

### ❌ Certificado SSL expirado

Si aparece este error:

1. Verifica la fecha y hora de tu dispositivo (debe ser correcta)
2. Actualiza tu navegador
3. Contacta al administrador del sitio

---

## Acceso desde Diferentes Redes

### Red Doméstica

- Generalmente sin restricciones
- Conexión estable
- Ideal para trabajar con la plataforma

### Red Corporativa/Trabajo

- Puede tener filtros de contenido
- Algunos puertos pueden estar bloqueados
- Consulta con el departamento de IT si tienes problemas

### Redes Públicas (Wi-Fi de cafeterías, bibliotecas, etc.)

:::warning Precaución en Redes Públicas
- Evita ingresar información sensible
- No guardes contraseñas
- Usa una VPN si es posible
- Cierra sesión al terminar
:::

### Datos Móviles (4G/5G)

- Asegúrate de tener datos disponibles
- Puede consumir tu plan de datos
- Velocidad variable según cobertura

---

## Mejores Prácticas de Acceso

### 🔐 Seguridad

1. **Verifica siempre la URL** antes de ingresar datos
2. **Busca el candado** 🔒 en la barra de direcciones
3. **No accedas desde enlaces sospechosos** en correos
4. **Usa la URL oficial** guardada en favoritos

### ⚡ Rendimiento

1. **Cierra pestañas innecesarias** para mejorar el rendimiento
2. **Actualiza tu navegador** regularmente
3. **Limpia la caché** cada cierto tiempo
4. **Usa una conexión estable**

### 📱 Acceso Móvil

1. **Descarga la app oficial** para mejor experiencia
2. **Mantén la app actualizada**
3. **Habilita notificaciones** para alertas importantes
4. **Usa Wi-Fi** cuando sea posible para ahorrar datos

---

## Verificación de Acceso Exitoso

Sabrás que ingresaste correctamente cuando:

✅ La página carga completamente  
✅ Ves el logo y diseño oficial de la plataforma  
✅ Los botones e imágenes funcionan correctamente  
✅ Puedes navegar por diferentes secciones  
✅ No hay mensajes de error

---

## Soporte y Ayuda

### ¿Necesitas Ayuda para Ingresar?

Si tienes problemas técnicos:

📧 **Email**: soporte@tusistema.com  
📞 **Teléfono**: +593-XXX-XXXX  
💬 **Chat en vivo**: Disponible en la página principal  
⏰ **Horario de atención**: Lunes a Viernes, 8:00 AM - 6:00 PM

### Información Útil al Contactar Soporte

Proporciona los siguientes datos:

- Navegador que estás usando (Chrome, Firefox, etc.)
- Sistema operativo (Windows, Mac, Android, iOS)
- Descripción del problema
- Capturas de pantalla del error (si es posible)
- Pasos que seguiste antes del problema

---

## Próximos Pasos

Después de ingresar exitosamente a la plataforma:

### Si NO tienes cuenta:
- 📝 [Crea tu cuenta](./funcionalidades/registro) como Usuario o Empresa
- 👀 Explora el [Perfil Público](./perfiles/perfil-publico)
- 📖 Lee la información disponible públicamente

### Si YA tienes cuenta:
- 🔐 [Inicia sesión](./funcionalidades/inicio-sesion) con tus credenciales
- 👤 Accede a tu [Perfil de Usuario](./perfiles/perfil-usuario) o [Perfil de Empresa](./perfiles/perfil-empresa)
- ⚙️ Configura tus preferencias

### Si olvidaste tu contraseña:
- 🔑 Usa la opción [Recuperar Contraseña](./funcionalidades/recuperar-contraseña)
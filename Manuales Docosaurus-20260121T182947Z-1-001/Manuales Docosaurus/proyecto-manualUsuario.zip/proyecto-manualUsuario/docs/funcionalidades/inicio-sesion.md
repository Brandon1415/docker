# Iniciar Sesión en EmpleaTec

Esta guía te mostrará cómo acceder a tu cuenta de EmpleaTec desde la plataforma web y la aplicación móvil.

![Formulario de Login](/img/manual/formulario-login.png)

## 🔐 Acceder a tu Cuenta

### Desde la Plataforma Web

#### Paso 1: Ir a la Página de Inicio de Sesión

**Opción A:**
1. Ve a [https://serviciosint.com/bolsadeempleo/](https://serviciosint.com/bolsadeempleo/)
2. Haz clic en **"Iniciar Sesión"** o **"Login"** en la esquina superior derecha

**Opción B:**
1. Accede directamente a: [https://serviciosint.com/bolsadeempleo/login](https://serviciosint.com/bolsadeempleo/login)

#### Paso 2: Ingresar Credenciales

```
┌─────────────────────────────────────────────────┐
│           🎓 Bienvenido a EmpleaTec             │
│                                                  │
│         Inicia sesión en tu cuenta               │
├─────────────────────────────────────────────────┤
│                                                  │
│  Correo Electrónico: *                          │
│  [juan.perez@email.com                     ]    │
│                                                  │
│  Contraseña: *                                   │
│  [••••••••••••••••          ] 👁️              │
│                                                  │
│  ☐ Recordarme                                   │
│                                                  │
│  [         INICIAR SESIÓN         ]             │
│                                                  │
│  ¿Olvidaste tu contraseña?                       │
│                                                  │
│  ───────────── o ─────────────                  │
│                                                  │
│  ¿No tienes cuenta? [Regístrate aquí]           │
└─────────────────────────────────────────────────┘
```

**Completa los campos:**

- **Correo Electrónico**: El correo que usaste al registrarte
- **Contraseña**: Tu contraseña secreta

**Consejos:**
- ✅ Verifica que el correo esté escrito correctamente (sin espacios)
- ✅ La contraseña distingue mayúsculas y minúsculas
- ✅ Asegúrate de que Caps Lock esté desactivado

#### Paso 3: Opción "Recordarme"

```
☑ Recordarme
```

**¿Qué hace esta opción?**
- Mantiene tu sesión activa por más tiempo
- No necesitarás ingresar tu contraseña en cada visita
- La sesión permanece abierta por 30 días

:::warning Seguridad
Solo marca "Recordarme" si:
- Usas tu propia computadora
- No es un equipo compartido
- No es una computadora pública
:::

#### Paso 4: Hacer Clic en "Iniciar Sesión"

Después de ingresar tus credenciales, haz clic en el botón **"INICIAR SESIÓN"**

**Lo que sucede:**
1. El sistema verifica tu correo y contraseña
2. Si son correctas, serás redirigido a tu dashboard
3. Si hay un error, verás un mensaje de advertencia

### Desde la Aplicación Móvil

#### Paso 1: Abrir la App

1. Localiza el ícono de **EmpleaTec** en tu celular
2. Toca el ícono para abrir la aplicación
3. Espera a que cargue la pantalla de inicio

#### Paso 2: Pantalla de Login

```
┌───────────────────────────┐
│                           │
│      [Logo EmpleaTec]     │
│                           │
│   Iniciar Sesión          │
│                           │
│  Correo electrónico       │
│  ┌─────────────────────┐ │
│  │                     │ │
│  └─────────────────────┘ │
│                           │
│  Contraseña               │
│  ┌─────────────────────┐ │
│  │ ••••••••••      👁️  │ │
│  └─────────────────────┘ │
│                           │
│  ☐ Mantener sesión activa │
│                           │
│  [ INICIAR SESIÓN ]       │
│                           │
│  ¿Olvidaste tu contraseña?│
│                           │
│  ¿No tienes cuenta?       │
│  [Regístrate]             │
└───────────────────────────┘
```

#### Paso 3: Ingresa tus Datos

1. Toca el campo **"Correo electrónico"**
2. Escribe tu correo
3. Toca el campo **"Contraseña"**
4. Escribe tu contraseña
5. Toca el ícono del ojo (👁️) si quieres ver la contraseña mientras escribes

#### Paso 4: Toca "INICIAR SESIÓN"

La app verificará tus credenciales y te llevará a tu dashboard.

## ✅ Inicio de Sesión Exitoso

### Para Usuarios (Graduados)

Después de iniciar sesión correctamente, verás:

```
┌─────────────────────────────────────────────────┐
│  ☰ EmpleaTec           [🔔 3] [👤 Juan]        │
├─────────────────────────────────────────────────┤
│                                                  │
│  ¡Bienvenido de nuevo, Juan! 👋                │
│                                                  │
│  Tu perfil está completo al: ████████░░ 85%    │
│  [Completar perfil]                             │
│                                                  │
│  📊 Resumen                                     │
│  • Aplicaciones activas: 5                      │
│  • Ofertas guardadas: 12                        │
│  • Nuevas notificaciones: 3                     │
│                                                  │
│  💼 Ofertas Recomendadas                        │
│  [Ver todas las ofertas →]                      │
│                                                  │
└─────────────────────────────────────────────────┘
```

**Menú disponible:**
- 🏠 Inicio
- 🔍 Buscar Empleos
- 💼 Mis Aplicaciones
- ⭐ Favoritos
- 👤 Mi Perfil
- ⚙️ Configuración

### Para Empresas (Empleadores)

Dashboard empresarial:

```
┌─────────────────────────────────────────────────┐
│  ☰ EmpleaTec           [🔔 2] [🏢 TechCorp]    │
├─────────────────────────────────────────────────┤
│                                                  │
│  Bienvenido, TechCorp 🏢                        │
│                                                  │
│  📊 Estadísticas                                │
│  • Ofertas activas: 3                           │
│  • Aplicaciones recibidas: 45                   │
│  • Candidatos preseleccionados: 8               │
│                                                  │
│  📋 Tus Ofertas Recientes                       │
│  • Desarrollador Full Stack - 12 aplicaciones   │
│  • Diseñador UI/UX - 18 aplicaciones            │
│  • Analista de Datos - 15 aplicaciones          │
│                                                  │
│  [+ Publicar Nueva Oferta]                      │
│                                                  │
└─────────────────────────────────────────────────┘
```

**Menú disponible:**
- 🏠 Dashboard
- 📋 Mis Ofertas
- 👥 Candidatos
- 🔍 Buscar Talento
- 📊 Reportes
- 🏢 Perfil de Empresa
- ⚙️ Configuración

## ❌ Errores Comunes al Iniciar Sesión

### Error: "Correo o contraseña incorrectos"

```
┌─────────────────────────────────────────┐
│  ⚠️ Error de Inicio de Sesión           │
│                                          │
│  El correo o la contraseña son          │
│  incorrectos. Por favor, verifica       │
│  e intenta nuevamente.                  │
│                                          │
│  [Aceptar]                              │
└─────────────────────────────────────────┘
```

**Causas comunes:**
- ❌ Correo electrónico mal escrito
- ❌ Contraseña incorrecta
- ❌ Espacios extra al inicio o final
- ❌ Caps Lock activado
- ❌ Teclado en otro idioma

**Soluciones:**

1. **Verifica el correo**:
   - Revisa que no haya espacios
   - Confirma que sea el correo registrado
   - Verifica si tiene mayúsculas (aunque no suele importar)

2. **Verifica la contraseña**:
   - Haz clic en el ícono del ojo 👁️ para verla
   - Confirma que Caps Lock esté desactivado
   - Verifica el idioma del teclado

3. **Intenta copiar y pegar**:
   - Copia tu contraseña desde donde la guardaste
   - Pégala directamente en el campo

4. **Usa "Olvidé mi contraseña"**:
   - Si no recuerdas tu contraseña
   - Sigue el proceso de recuperación

### Error: "Tu cuenta no ha sido verificada"

```
┌─────────────────────────────────────────┐
│  ⚠️ Cuenta no Verificada                 │
│                                          │
│  Por favor, verifica tu correo          │
│  electrónico antes de iniciar sesión.   │
│                                          │
│  [Reenviar correo de verificación]      │
│  [Aceptar]                              │
└─────────────────────────────────────────┘
```

**Qué hacer:**
1. Haz clic en **"Reenviar correo de verificación"**
2. Revisa tu correo (incluyendo spam)
3. Haz clic en el enlace de verificación
4. Intenta iniciar sesión nuevamente

### Error: "Tu cuenta está pendiente de aprobación" (Empresas)

```
┌─────────────────────────────────────────┐
│  ⏳ Cuenta Pendiente                     │
│                                          │
│  Tu cuenta empresarial está siendo      │
│  revisada por el administrador.         │
│                                          │
│  Recibirás un correo cuando sea         │
│  aprobada (24-48 horas hábiles).        │
│                                          │
│  [Aceptar]                              │
└─────────────────────────────────────────┘
```

**Qué hacer:**
- Esperar la aprobación del administrador
- Verificar que enviaste todos los documentos
- Contactar soporte si han pasado más de 3 días

### Error: "Tu cuenta ha sido suspendida"

```
┌─────────────────────────────────────────┐
│  🚫 Cuenta Suspendida                    │
│                                          │
│  Tu cuenta ha sido suspendida.          │
│  Por favor, contacta a soporte para     │
│  más información.                       │
│                                          │
│  [Contactar Soporte]                    │
│  [Aceptar]                              │
└─────────────────────────────────────────┘
```

**Posibles razones:**
- Violación de términos de uso
- Actividad sospechosa
- Información falsa
- Reportes de otros usuarios

**Qué hacer:**
- Contacta inmediatamente a soporte
- Explica tu situación
- Proporciona documentación si es necesario

### Error: "Demasiados intentos fallidos"

```
┌─────────────────────────────────────────┐
│  🔒 Cuenta Bloqueada Temporalmente       │
│                                          │
│  Has excedido el número máximo de       │
│  intentos de inicio de sesión.          │
│                                          │
│  Por favor, espera 15 minutos e         │
│  intenta nuevamente.                    │
│                                          │
│  O recupera tu contraseña:              │
│  [Recuperar Contraseña]                 │
│                                          │
│  [Aceptar]                              │
└─────────────────────────────────────────┘
```

**Por seguridad:**
- Después de 5 intentos fallidos, la cuenta se bloquea por 15 minutos
- Esto previene ataques de fuerza bruta

**Qué hacer:**
1. Espera 15 minutos
2. O usa la opción de recuperar contraseña
3. Verifica que estás usando las credenciales correctas

## 🔐 Mantener tu Sesión Segura

### Buenas Prácticas

**Siempre:**
- ✅ Cierra sesión al usar computadoras públicas o compartidas
- ✅ No compartas tu contraseña con nadie
- ✅ Usa contraseñas diferentes para cada sitio
- ✅ Verifica que estás en el sitio oficial (serviciosint.com)
- ✅ Mantén tu navegador actualizado

**Nunca:**
- ❌ Guardes tu contraseña en computadoras públicas
- ❌ Inicies sesión desde enlaces en correos sospechosos
- ❌ Uses contraseñas obvias o fáciles de adivinar
- ❌ Compartas tu sesión activa con otras personas

### Cerrar Sesión Correctamente

**En la Web:**
1. Haz clic en tu foto de perfil o nombre (esquina superior derecha)
2. En el menú desplegable, selecciona **"Cerrar Sesión"**
3. Serás redirigido a la página principal

**En la App Móvil:**
1. Toca el menú (☰) o tu foto de perfil
2. Desplázate hasta el final
3. Toca **"Cerrar Sesión"**
4. Confirma la acción

:::tip Recuerda Cerrar Sesión
Especialmente importante en:
- Computadoras de trabajo compartidas
- Computadoras de cibercafés
- Dispositivos prestados
- Navegadores de otras personas
:::

## 🔄 Iniciar Sesión en Múltiples Dispositivos

EmpleaTec permite estar conectado desde:
- 💻 Computadora de escritorio
- 📱 Smartphone (app móvil)
- 💻 Laptop
- 📱 Tablet

**Todo se sincroniza:**
- Tus aplicaciones
- Tus favoritos
- Tu perfil
- Tus notificaciones
- Tus mensajes

## 📱 Problemas Específicos de la App Móvil

### La app no acepta mis credenciales

**Soluciones:**
1. Verifica tu conexión a Internet
2. Actualiza la app a la última versión
3. Intenta desde la web para confirmar que las credenciales son correctas
4. Borra caché y datos de la app (Configuración > Apps > EmpleaTec)
5. Desinstala y reinstala la app

### La app se cierra al iniciar sesión

**Soluciones:**
1. Verifica que tu Android sea 5.0 o superior
2. Actualiza la app
3. Reinicia tu dispositivo
4. Libera espacio de almacenamiento
5. Reporta el problema a soporte técnico

### No recibo notificaciones después de iniciar sesión

**Soluciones:**
1. Verifica permisos de notificaciones:
   - **Configuración del teléfono** > **Apps** > **EmpleaTec** > **Notificaciones**
   - Asegúrate de que estén habilitadas
2. Verifica en la app:
   - **Perfil** > **Configuración** > **Notificaciones**
   - Activa las que desees recibir

## ⏱️ Duración de la Sesión

### Sin "Recordarme"
- Sesión activa por **1 hora** de inactividad
- Después deberás iniciar sesión nuevamente

### Con "Recordarme"
- Sesión activa por **30 días**
- O hasta que cierres sesión manualmente

### En la App Móvil
- Generalmente permanece activa
- Hasta que cierres sesión o desinstales la app
- Por seguridad, puede requerir login después de actualizaciones

## 💡 Consejos Útiles

### Acceso Rápido

**Guarda la página como favorito:**
1. En tu navegador, presiona **Ctrl + D** (Windows) o **Cmd + D** (Mac)
2. Guarda como: "EmpleaTec - Login"
3. Accede rápidamente desde tus favoritos

**Crea un acceso directo en el escritorio:**
1. Arrastra el ícono del candado (🔒) de la barra de direcciones
2. Suéltalo en tu escritorio
3. Tendrás un acceso directo instantáneo

### Primera Vez Iniciando Sesión

Si es tu primera vez después de registrarte:

**Para Graduados:**
1. Completa tu perfil inmediatamente (aprovecha el momento)
2. Sube tu CV
3. Configura tus preferencias
4. Explora ofertas disponibles

**Para Empresas:**
1. Completa el perfil de tu empresa
2. Agrega logo e información
3. Revisa la base de datos de candidatos
4. Publica tu primera oferta

## 📞 ¿Necesitas Ayuda?

Si no puedes iniciar sesión después de intentar estas soluciones:

- **📧 Correo**: soporte@empleatec.com
- **📱 WhatsApp**: [Número del Instituto]
- **⏰ Horario**: Lunes a Viernes, 8:00 AM - 5:00 PM

---

**Siguiente**: Si olvidaste tu contraseña, aprende a [Recuperarla](./recuperar-contrasena.md).
# Recuperar Contraseña en EmpleaTec

Si olvidaste tu contraseña, no te preocupes. Esta guía te mostrará cómo recuperar el acceso a tu cuenta de forma segura.

## 🔑 ¿Cuándo Usar Esta Opción?

Usa la recuperación de contraseña cuando:
- ❌ Olvidaste tu contraseña completamente
- ❌ Tu contraseña ya no funciona
- ❌ Has sido bloqueado por múltiples intentos fallidos
- ❌ Sospechas que alguien cambió tu contraseña

:::warning No Uses Esta Opción Si:
- Tu cuenta nunca fue creada → Necesitas [Registrarte](./registro.md)
- No recuerdas tu correo → Contacta soporte
- Tu cuenta fue suspendida → Contacta soporte
:::

## 🔐 Proceso de Recuperación

### Paso 1: Acceder al Formulario

**Desde la Web:**

1. Ve a la página de inicio de sesión: [https://serviciosint.com/bolsadeempleo/login](https://serviciosint.com/bolsadeempleo/login)
2. Haz clic en **"¿Olvidaste tu contraseña?"** debajo del botón de inicio de sesión

```
┌─────────────────────────────────────────┐
│  Correo Electrónico: *                  │
│  [                                  ]   │
│                                          │
│  Contraseña: *                          │
│  [                                  ]   │
│                                          │
│  [    INICIAR SESIÓN    ]               │
│                                          │
│  👉 ¿Olvidaste tu contraseña?           │
│                                          │
└─────────────────────────────────────────┘
```

**Desde la App Móvil:**

1. Abre la app EmpleaTec
2. En la pantalla de inicio de sesión
3. Toca **"¿Olvidaste tu contraseña?"**

### Paso 2: Ingresar tu Correo Electrónico

Serás redirigido a la página de recuperación:

```
┌─────────────────────────────────────────────────┐
│         🔐 Recuperar Contraseña                  │
├─────────────────────────────────────────────────┤
│                                                  │
│  Ingresa tu correo electrónico y te enviaremos  │
│  un enlace para restablecer tu contraseña.      │
│                                                  │
│  Correo Electrónico: *                          │
│  ┌────────────────────────────────────────────┐ │
│  │ juan.perez@email.com                      │ │
│  └────────────────────────────────────────────┘ │
│                                                  │
│  [← Volver al inicio]  [Enviar enlace →]       │
│                                                  │
└─────────────────────────────────────────────────┘
```

**Importante:**
- ✅ Usa el correo con el que te registraste
- ✅ Verifica que esté escrito correctamente
- ✅ No incluyas espacios al inicio o final

### Paso 3: Confirmación de Envío

Después de hacer clic en **"Enviar enlace"**, verás:

```
┌─────────────────────────────────────────────────┐
│  ✓ Correo Enviado                                │
├─────────────────────────────────────────────────┤
│                                                  │
│  Si el correo juan.perez@email.com está         │
│  registrado, recibirás un enlace para           │
│  restablecer tu contraseña.                      │
│                                                  │
│  📧 Revisa tu bandeja de entrada                │
│                                                  │
│  El enlace expirará en 1 hora.                  │
│                                                  │
│  Si no recibes el correo en 5 minutos:          │
│  • Revisa tu carpeta de spam                     │
│  • Verifica que el correo sea correcto           │
│  • Intenta reenviar el enlace                    │
│                                                  │
│  [Reenviar enlace]      [Ir al inicio]          │
└─────────────────────────────────────────────────┘
```

:::info Por Seguridad
Por razones de seguridad, el sistema no indica si el correo existe o no. Recibirás el enlace SOLO si el correo está registrado.
:::

### Paso 4: Revisar tu Correo Electrónico

1. **Abre tu correo electrónico** (Gmail, Outlook, etc.)
2. **Busca un mensaje** de:
   - Remitente: **EmpleaTec** o **noreply@serviciosint.com**
   - Asunto: **"Recupera tu contraseña de EmpleaTec"**

3. **El correo contendrá:**

```
┌─────────────────────────────────────────────────┐
│  De: EmpleaTec <noreply@serviciosint.com>       │
│  Para: juan.perez@email.com                      │
│  Asunto: Recupera tu contraseña de EmpleaTec     │
├─────────────────────────────────────────────────┤
│                                                  │
│  Hola Juan,                                      │
│                                                  │
│  Recibimos una solicitud para restablecer la    │
│  contraseña de tu cuenta en EmpleaTec.          │
│                                                  │
│  Si tú solicitaste este cambio, haz clic en     │
│  el siguiente botón:                             │
│                                                  │
│      [  Restablecer mi contraseña  ]            │
│                                                  │
│  O copia y pega este enlace en tu navegador:    │
│  https://serviciosint.com/reset-password?       │
│  token=abc123xyz789...                           │
│                                                  │
│  Este enlace expirará en 1 hora.                │
│                                                  │
│  Si no solicitaste este cambio, ignora este     │
│  correo. Tu contraseña permanecerá sin cambios. │
│                                                  │
│  Saludos,                                        │
│  El equipo de EmpleaTec                         │
└─────────────────────────────────────────────────┘
```

4. **Haz clic en el botón** "Restablecer mi contraseña" o en el enlace

:::warning ¿No Ves el Correo?
- Espera 5-10 minutos (puede tardar)
- **Revisa SPAM** o correo no deseado
- Revisa la pestaña "Promociones" (Gmail)
- Agrega noreply@serviciosint.com a tus contactos
- Intenta reenviar desde la plataforma
:::

### Paso 5: Crear Nueva Contraseña

Serás redirigido a la página para crear tu nueva contraseña:

```
┌─────────────────────────────────────────────────┐
│         🔐 Restablecer Contraseña                │
├─────────────────────────────────────────────────┤
│                                                  │
│  Crea una nueva contraseña para tu cuenta.      │
│                                                  │
│  Nueva Contraseña: *                             │
│  ┌────────────────────────────────────────────┐ │
│  │ ••••••••••••••••                     👁️  │ │
│  └────────────────────────────────────────────┘ │
│                                                  │
│  Fortaleza: ████████░░ Fuerte                   │
│                                                  │
│  Confirmar Nueva Contraseña: *                   │
│  ┌────────────────────────────────────────────┐ │
│  │ ••••••••••••••••                     👁️  │ │
│  └────────────────────────────────────────────┘ │
│                                                  │
│  Requisitos de contraseña:                       │
│  ✓ Mínimo 8 caracteres                          │
│  ✓ Al menos una letra mayúscula                 │
│  ✓ Al menos una letra minúscula                 │
│  ✓ Al menos un número                           │
│  ○ Al menos un carácter especial (recomendado) │
│                                                  │
│  [       Cambiar Contraseña       ]             │
│                                                  │
└─────────────────────────────────────────────────┘
```

**Requisitos de la nueva contraseña:**

| Requisito | Ejemplo Válido | Ejemplo Inválido |
|-----------|----------------|------------------|
| Mínimo 8 caracteres | `Password123` | `Pass12` (muy corta) |
| Una mayúscula | `Password` | `password` (sin mayúscula) |
| Una minúscula | `PASSword` | `PASSWORD` (sin minúscula) |
| Un número | `Password1` | `Password` (sin número) |
| Carácter especial (opcional) | `Pass@123` | - |

**Ejemplos de contraseñas:**
- ❌ `password` - Muy simple
- ❌ `12345678` - Solo números
- ❌ `Password` - Sin números
- ✅ `Password123` - Cumple requisitos básicos
- ✅ `MiClave2025!` - Excelente (incluye especial)
- ✅ `EmpleaTec@2025` - Muy buena

:::tip Crea una Contraseña Segura
**Mejores prácticas:**
- Usa una frase fácil de recordar: `MiPerr0SeLL4maMax!`
- Combina palabras con números: `Cafe24Horas`
- Evita información personal (nombre, fecha de nacimiento)
- No uses contraseñas que hayas usado en otros sitios
- Considera usar un gestor de contraseñas

**NO uses:**
- 123456789
- password123
- TuNombre123
- fechadenacimiento
- qwerty123
:::

### Paso 6: Confirmación de Cambio

Después de hacer clic en **"Cambiar Contraseña"**:

```
┌─────────────────────────────────────────────────┐
│  ✓ ¡Contraseña Cambiada Exitosamente!           │
├─────────────────────────────────────────────────┤
│                                                  │
│  Tu contraseña ha sido actualizada.              │
│                                                  │
│  Por seguridad:                                  │
│  • Hemos cerrado todas tus sesiones activas     │
│  • Deberás iniciar sesión nuevamente            │
│  • Se ha enviado un correo de confirmación      │
│                                                  │
│  [    Ir a Iniciar Sesión    ]                  │
│                                                  │
└─────────────────────────────────────────────────┘
```

**Recibirás un correo de confirmación:**

```
┌─────────────────────────────────────────────────┐
│  Asunto: Tu contraseña ha sido cambiada          │
├─────────────────────────────────────────────────┤
│                                                  │
│  Hola Juan,                                      │
│                                                  │
│  Te confirmamos que la contraseña de tu         │
│  cuenta ha sido cambiada exitosamente.          │
│                                                  │
│  Fecha: 15 de enero de 2025, 10:30 AM          │
│  IP: 192.168.1.100                              │
│  Dispositivo: Chrome en Windows                 │
│                                                  │
│  Si NO fuiste tú quien realizó este cambio,     │
│  contacta inmediatamente a nuestro equipo de    │
│  soporte: soporte@empleatec.com                 │
│                                                  │
│  Saludos,                                        │
│  EmpleaTec                                      │
└─────────────────────────────────────────────────┘
```

### Paso 7: Iniciar Sesión con Nueva Contraseña

1. Haz clic en **"Ir a Iniciar Sesión"**
2. Ingresa tu correo electrónico
3. Ingresa tu **nueva contraseña**
4. Haz clic en **"INICIAR SESIÓN"**
5. ¡Listo! Ya tienes acceso a tu cuenta

## ⏱️ Límites de Tiempo

### Enlace de Recuperación
- **Válido por**: 1 hora (60 minutos)
- **Después de**: El enlace expira y debes solicitar uno nuevo
- **Razón**: Seguridad para evitar accesos no autorizados

### Límite de Solicitudes
- **Máximo**: 3 solicitudes por hora
- **Si excedes**: Deberás esperar 1 hora para solicitar nuevamente
- **Razón**: Prevenir abuso del sistema

## 🚨 Problemas Comunes y Soluciones

### 1. No Recibo el Correo de Recuperación

**Posibles causas y soluciones:**

**a) Correo en Spam/Basura**
```
Solución:
1. Abre tu carpeta de Spam o Correo no deseado
2. Busca correos de "EmpleaTec" o "noreply@serviciosint.com"
3. Si lo encuentras, márcalo como "No es spam"
4. Agrega el remitente a tus contactos
```

**b) Correo Incorrecto**
```
Problema: Escribiste mal tu correo
Solución:
1. Verifica que el correo esté correcto
2. Revisa por espacios al inicio o final
3. Confirma que sea el correo con el que te registraste
4. Intenta con otro correo si tienes más de uno
```

**c) Filtros de Correo**
```
Problema: Tu proveedor bloqueó el correo
Solución:
1. Agrega noreply@serviciosint.com a tu lista blanca
2. Verifica configuración de filtros en tu correo
3. Contacta a tu proveedor de correo
```

**d) Problemas del Servidor**
```
Problema: Retraso en el envío
Solución:
1. Espera 10-15 minutos
2. Revisa tu conexión a Internet
3. Intenta reenviar el enlace
4. Si persiste, contacta soporte
```

### 2. El Enlace de Recuperación Ya Expiró

```
┌─────────────────────────────────────────────────┐
│  ⚠️ Enlace Expirado                              │
│                                                  │
│  Este enlace de recuperación ha expirado.        │
│  Por favor, solicita un nuevo enlace.            │
│                                                  │
│  [Solicitar nuevo enlace]                        │
└─────────────────────────────────────────────────┘
```

**Solución:**
1. Haz clic en "Solicitar nuevo enlace"
2. O ve a la página de recuperación manualmente
3. Ingresa tu correo nuevamente
4. Revisa tu correo y usa el nuevo enlace dentro de 1 hora

### 3. El Enlace Ya Fue Usado

```
┌─────────────────────────────────────────────────┐
│  ⚠️ Enlace Inválido                              │
│                                                  │
│  Este enlace ya fue utilizado.                   │
│  Si necesitas cambiar tu contraseña             │
│  nuevamente, solicita un nuevo enlace.           │
│                                                  │
│  [Solicitar nuevo enlace]                        │
│  [Ir a iniciar sesión]                          │
└─────────────────────────────────────────────────┘
```

**Qué hacer:**
- Si ya cambiaste tu contraseña: Usa la nueva contraseña para iniciar sesión
- Si no la cambiaste: Solicita un nuevo enlace de recuperación

### 4. La Nueva Contraseña No es Aceptada

**Errores comunes:**

**a) No cumple requisitos**
```
⚠️ Error: La contraseña no cumple los requisitos

Verifica:
○ Mínimo 8 caracteres
✓ Al menos una mayúscula
○ Al menos una minúscula
✓ Al menos un número
```

**Solución**: Ajusta tu contraseña hasta que todos los requisitos tengan ✓

**b) Las contraseñas no coinciden**
```
⚠️ Error: Las contraseñas no coinciden

Asegúrate de escribir la misma contraseña
en ambos campos.
```

**Solución**: Verifica que ambas contraseñas sean idénticas

**c) Contraseña muy común**
```
⚠️ Error: Esta contraseña es muy común

Por seguridad, no puedes usar contraseñas
comunes como "Password123" o "12345678".
```

**Solución**: Crea una contraseña más única y segura

### 5. Excedí el Límite de Solicitudes

```
┌─────────────────────────────────────────────────┐
│  ⏳ Límite Excedido                              │
│                                                  │
│  Has excedido el número máximo de               │
│  solicitudes de recuperación de contraseña.     │
│                                                  │
│  Por favor, espera 60 minutos antes de          │
│  intentar nuevamente.                            │
│                                                  │
│  Si necesitas ayuda urgente, contacta a:        │
│  soporte@empleatec.com                           │
│                                                  │
│  [Aceptar]                                      │
└─────────────────────────────────────────────────┘
```

**Qué hacer:**
1. Espera el tiempo indicado (60 minutos)
2. O contacta a soporte si es urgente
3. Verifica que estés usando el correo correcto

## 🔒 Seguridad en la Recuperación

### Señales de Alerta

🚨 **NO hagas clic en enlaces** si:
- No solicitaste recuperar tu contraseña
- El correo proviene de un remitente desconocido
- El enlace no va a serviciosint.com
- El correo tiene errores gramaticales u ortográficos
- Te piden información bancaria o datos sensibles

### Si Recibes un Correo Sospechoso

```
1. NO hagas clic en ningún enlace
2. NO descargues archivos adjuntos
3. Reporta el correo como phishing
4. Cambia tu contraseña desde el sitio oficial
5. Contacta a soporte inmediatamente
```

### Protege tu Cuenta

**Después de recuperar tu contraseña:**
- ✅ Cambia tu contraseña en otros sitios si era la misma
- ✅ Activa autenticación de dos factores (si disponible)
- ✅ Revisa las sesiones activas
- ✅ Verifica que tu correo no haya sido comprometido
- ✅ Usa un gestor de contraseñas

## 📱 Recuperación desde la App Móvil

El proceso es similar, pero en tu dispositivo móvil:

### Pasos en la App

1. **Abre la app** EmpleaTec
2. En la pantalla de inicio de sesión, toca **"¿Olvidaste tu contraseña?"**
3. **Ingresa tu correo** electrónico
4. Toca **"Enviar enlace"**
5. **Abre tu app de correo** en el móvil
6. **Toca el enlace** en el correo recibido
7. Se abrirá en el navegador del móvil
8. **Crea tu nueva contraseña**
9. **Regresa a la app** EmpleaTec
10. **Inicia sesión** con tu nueva contraseña

:::tip Usa el Navegador
El enlace de recuperación se abre en el navegador, no en la app. Esto es normal y por seguridad.
:::

## 💡 Consejos para Recordar tu Contraseña

### Usa una Frase Memorable

En lugar de contraseñas aleatorias, crea frases:
- ❌ `kJ8@mL2pQ` (difícil de recordar)
- ✅ `MiGatoSeLlamaLuna2024!` (fácil de recordar, muy segura)

### Gestor de Contraseñas

Considera usar un gestor de contraseñas:
- **LastPass** (gratuito/premium)
- **1Password** (premium)
- **Bitwarden** (gratuito/premium)
- **Google Password Manager** (integrado en Chrome)

**Ventajas:**
- Genera contraseñas seguras automáticamente
- Las recuerda por ti
- Se sincronizan entre dispositivos
- Una sola contraseña maestra

### Notas Seguras

Si prefieres escribirla:
- 📝 Guárdala en un lugar físico seguro
- 🔒 No la dejes en notas adhesivas en tu monitor
- 💻 No la guardes en un archivo de texto sin protección
- 📱 Usa apps de notas cifradas (como Notes en iPhone con contraseña)

## 🆘 ¿Aún No Puedes Recuperar tu Contraseña?

Si después de seguir todos estos pasos no puedes recuperar tu contraseña, contacta a soporte:

### Información para Proporcionar

Cuando contactes a soporte, ten lista esta información:
- ✅ Correo electrónico registrado
- ✅ Nombre completo
- ✅ Cédula (últimos 4 dígitos)
- ✅ Fecha aproximada de registro
- ✅ Descripción del problema
- ✅ Capturas de pantalla de los errores

### Canales de Soporte

- **📧 Correo**: soporte@empleatec.com
- **📱 WhatsApp**: [Número del Instituto Nelson Torres]
- **📞 Teléfono**: [Teléfono del Instituto]
- **⏰ Horario**: Lunes a Viernes, 8:00 AM - 5:00 PM

**Tiempo de respuesta**: Generalmente 24-48 horas hábiles

---

**Siguiente**: Ahora que recuperaste tu acceso, aprende a [Iniciar Sesión](./inicio-sesion.md) correctamente.
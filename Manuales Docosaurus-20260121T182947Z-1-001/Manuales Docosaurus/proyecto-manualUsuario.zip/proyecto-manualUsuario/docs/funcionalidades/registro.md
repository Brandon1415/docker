# Cómo Registrarse en EmpleaTec

Esta guía te mostrará paso a paso cómo crear tu cuenta en EmpleaTec, ya sea como graduado buscando empleo o como empresa buscando talento.

![Formulario de Registro](/img/manual/formulario-registro.png)

## 🚀 Antes de Comenzar

### Requisitos Previos

**Para registrarte como Graduado necesitas:**
- ✅ Correo electrónico válido
- ✅ Número de teléfono activo
- ✅ Cédula de identidad
- ✅ Ser graduado del Instituto Nelson Torres
- ✅ Tener tu CV en formato PDF (opcional pero recomendado)

**Para registrarte como Empresa necesitas:**
- ✅ Correo electrónico corporativo
- ✅ RUC o identificación fiscal de la empresa
- ✅ Documentos de la empresa (RUC, cédula del representante)
- ✅ Información de contacto de la empresa

## 📝 Acceder al Formulario de Registro

### Opción 1: Desde la Página Principal

1. Ve a [https://serviciosint.com/bolsadeempleo/](https://serviciosint.com/bolsadeempleo/)
2. Haz clic en el botón **"Registrarse"** o **"Crear Cuenta"** en la esquina superior derecha
3. Selecciona el tipo de perfil:
   - **"Soy Graduado"** → Si buscas empleo
   - **"Soy Empresa"** → Si buscas contratar talento

### Opción 2: Al Intentar Postularte

1. Navega por las ofertas de empleo
2. Haz clic en **"Postularme"** en cualquier oferta
3. Serás redirigido automáticamente al formulario de registro
4. El sistema recordará la oferta a la que querías aplicar

### Opción 3: Desde la App Móvil

1. Descarga e instala la app EmpleaTec
2. Abre la aplicación
3. En la pantalla de bienvenida, toca **"Registrarse"**
4. Selecciona tu tipo de perfil

## 👤 Registro como Graduado (Usuario)

### Paso 1: Información Básica

Completa el primer formulario con tus datos personales:

 
 ![Texto alternativo](/img/registroP.png)

**Validaciones:**
- Nombres y apellidos: Solo letras y espacios
- Cédula: 10 dígitos, debe ser válida
- Fecha de nacimiento: Debes ser mayor de 18 años

:::warning Cédula Ecuatoriana
El sistema valida que la cédula sea ecuatoriana válida usando el algoritmo del dígito verificador.
:::

### Paso 2: Información de Contacto

```
┌─────────────────────────────────────────────────┐
│  Crear Cuenta - Contacto                        │
├─────────────────────────────────────────────────┤
│                                                  │
│  Correo Electrónico: *                          │
│  [juan.perez@email.com                     ]    │
│                                                  │
│  Confirmar Correo: *                            │
│  [juan.perez@email.com                     ]    │
│                                                  │
│  Teléfono Celular: *                            │
│  [0999123456                               ]    │
│                                                  │
│  Teléfono Convencional (opcional):              │
│  [022345678                                ]    │
│                                                  │
│  [← Atrás]              [Continuar →]           │
└─────────────────────────────────────────────────┘
```

**Validaciones:**
- Correo: Formato válido (ej: usuario@dominio.com)
- Ambos correos deben coincidir
- Celular: 10 dígitos, debe empezar con 09
- Convencional: 9 dígitos, código de área válido

:::tip Usa un Correo Activo
Este correo será tu medio principal de comunicación. Asegúrate de:
- Tener acceso permanente
- Revisar la bandeja de entrada regularmente
- Verificar que no esté en spam
:::

### Paso 3: Dirección

```
┌─────────────────────────────────────────────────┐
│  Crear Cuenta - Ubicación                       │
├─────────────────────────────────────────────────┤
│                                                  │
│  Provincia: *                                    │
│  [▼ Pichincha                              ]    │
│                                                  │
│  Ciudad: *                                       │
│  [▼ Quito                                  ]    │
│                                                  │
│  Dirección Completa:                             │
│  [Av. Principal y Secundaria, N12-34       ]    │
│  [Sector Norte                             ]    │
│                                                  │
│  Código Postal (opcional):                      │
│  [170201                                   ]    │
│                                                  │
│  [← Atrás]              [Continuar →]           │
└─────────────────────────────────────────────────┘
```

### Paso 4: Información Académica

```
┌─────────────────────────────────────────────────┐
│  Crear Cuenta - Educación                       │
├─────────────────────────────────────────────────┤
│                                                  │
│  Carrera/Programa de Estudios: *                │
│  [▼ Tecnología en Desarrollo de Software   ]    │
│                                                  │
│  Año de Graduación: *                           │
│  [▼ 2024                                   ]    │
│                                                  │
│  Campus/Sede:                                    │
│  [▼ Campus Principal - Quito               ]    │
│                                                  │
│  Número de Título (opcional):                   │
│  [TEC-2024-001234                          ]    │
│                                                  │
│  [← Atrás]              [Continuar →]           │
└─────────────────────────────────────────────────┘
```

:::info Solo Graduados del Instituto
EmpleaTec está diseñado para graduados del Instituto Nelson Torres. Si no encuentras tu carrera en la lista, contacta al administrador.
:::

### Paso 5: Seguridad de la Cuenta

```
┌─────────────────────────────────────────────────┐
│  Crear Cuenta - Contraseña                      │
├─────────────────────────────────────────────────┤
│                                                  │
│  Contraseña: *                                   │
│  [••••••••••••••••          ] 👁️              │
│                                                  │
│  Fortaleza: ████████░░ Fuerte                   │
│                                                  │
│  Confirmar Contraseña: *                         │
│  [••••••••••••••••          ] 👁️              │
│                                                  │
│  Requisitos de contraseña:                       │
│  ✓ Mínimo 8 caracteres                          │
│  ✓ Al menos una letra mayúscula                 │
│  ✓ Al menos una letra minúscula                 │
│  ✓ Al menos un número                           │
│  ○ Al menos un carácter especial (!@#$%&*)     │
│                                                  │
│  [← Atrás]              [Continuar →]           │
└─────────────────────────────────────────────────┘
```

**Requisitos de contraseña:**
- ✅ Mínimo 8 caracteres
- ✅ Al menos una letra mayúscula (A-Z)
- ✅ Al menos una letra minúscula (a-z)
- ✅ Al menos un número (0-9)
- ⚠️ Recomendado: Un carácter especial (!@#$%&*)

**Ejemplos:**
- ❌ `password123` - Sin mayúsculas
- ❌ `Password` - Muy corta, sin números
- ✅ `Password123` - Cumple requisitos básicos
- ✅ `MiClave2024!` - Excelente (incluye especial)

:::tip Crea una Contraseña Segura
- No uses información personal (nombre, fecha de nacimiento)
- No uses contraseñas comunes (123456, password)
- Considera usar un gestor de contraseñas
- No compartas tu contraseña con nadie
:::

### Paso 6: Términos y Condiciones

```
┌─────────────────────────────────────────────────┐
│  Crear Cuenta - Términos y Condiciones          │
├─────────────────────────────────────────────────┤
│                                                  │
│  Por favor, lee y acepta los siguientes          │
│  documentos:                                     │
│                                                  │
│  ☑ He leído y acepto los Términos y             │
│    Condiciones de Uso                            │
│    [Ver documento completo]                      │
│                                                  │
│  ☑ He leído y acepto la Política de             │
│    Privacidad                                    │
│    [Ver documento completo]                      │
│                                                  │
│  ☑ Acepto recibir comunicaciones y              │
│    notificaciones de EmpleaTec                   │
│                                                  │
│  ☐ Acepto recibir boletín semanal con           │
│    ofertas recomendadas (opcional)               │
│                                                  │
│  [← Atrás]              [Crear Cuenta]          │
└─────────────────────────────────────────────────┘
```

:::warning Acepta los Términos
Es obligatorio aceptar los Términos y Condiciones y la Política de Privacidad para crear tu cuenta.
:::

### Paso 7: Verificación de Correo

Después de hacer clic en **"Crear Cuenta"**:

```
┌─────────────────────────────────────────────────┐
│  ✓ ¡Cuenta Creada Exitosamente!                 │
├─────────────────────────────────────────────────┤
│                                                  │
│  Hemos enviado un correo de verificación a:      │
│                                                  │
│  📧 juan.perez@email.com                        │
│                                                  │
│  Por favor, revisa tu bandeja de entrada y       │
│  haz clic en el enlace de verificación para      │
│  activar tu cuenta.                              │
│                                                  │
│  Si no recibes el correo en 5 minutos:          │
│  • Revisa tu carpeta de spam                     │
│  • Verifica que el correo sea correcto           │
│  • Solicita reenvío del correo                   │
│                                                  │
│  [Reenviar Correo]      [Ir a Inicio]           │
└─────────────────────────────────────────────────┘
```

**Pasos de verificación:**

1. Abre tu correo electrónico
2. Busca un mensaje de **"EmpleaTec"** o **"noreply@serviciosint.com"**
3. El asunto será: **"Verifica tu cuenta de EmpleaTec"**
4. Haz clic en el botón **"Verificar mi cuenta"** dentro del correo
5. Serás redirigido a la plataforma
6. Tu cuenta quedará activada automáticamente

:::info Tiempo de Expiración
El enlace de verificación es válido por **24 horas**. Después deberás solicitar un nuevo correo.
:::

## 🏢 Registro como Empresa

### Paso 1: Información de la Empresa

```
┌─────────────────────────────────────────────────┐
│  Crear Cuenta Empresarial - Datos de Empresa    │
├─────────────────────────────────────────────────┤
│                                                  │
│  Nombre Legal de la Empresa: *                   │
│  [TECNOLOGÍA AVANZADA S.A.                 ]    │
│                                                  │
│  Nombre Comercial:                               │
│  [TechAdvance                              ]    │
│                                                  │
│  RUC: *                                          │
│  [1234567890001                            ]    │
│                                                  │
│  Sector/Industria: *                             │
│  [▼ Tecnología de la Información           ]    │
│                                                  │
│  Tamaño de la Empresa: *                         │
│  [▼ 50-200 empleados                       ]    │
│                                                  │
│  Sitio Web:                                      │
│  [https://www.techadvance.com              ]    │
│                                                  │
│  [← Atrás]              [Continuar →]           │
└─────────────────────────────────────────────────┘
```

**Validaciones:**
- RUC: 13 dígitos para empresas, debe ser válido
- Nombre legal: Como aparece en documentos oficiales
- Sitio web: Formato URL válido (opcional)

### Paso 2: Ubicación de la Empresa

```
┌─────────────────────────────────────────────────┐
│  Crear Cuenta Empresarial - Ubicación           │
├─────────────────────────────────────────────────┤
│                                                  │
│  Provincia: *                                    │
│  [▼ Pichincha                              ]    │
│                                                  │
│  Ciudad: *                                       │
│  [▼ Quito                                  ]    │
│                                                  │
│  Dirección Completa: *                           │
│  [Av. República y Naciones Unidas           ]    │
│  [Edificio Corporativo, Piso 5             ]    │
│                                                  │
│  Teléfono Empresarial: *                         │
│  [022345678                                ]    │
│                                                  │
│  [← Atrás]              [Continuar →]           │
└─────────────────────────────────────────────────┘
```

### Paso 3: Representante Legal

```
┌─────────────────────────────────────────────────┐
│  Crear Cuenta Empresarial - Representante       │
├─────────────────────────────────────────────────┤
│                                                  │
│  Nombre Completo del Representante: *            │
│  [María Fernanda López                     ]    │
│                                                  │
│  Cédula del Representante: *                     │
│  [0987654321                               ]    │
│                                                  │
│  Cargo en la Empresa: *                          │
│  [▼ Gerente de Recursos Humanos            ]    │
│                                                  │
│  Correo Electrónico Corporativo: *               │
│  [m.lopez@techadvance.com                  ]    │
│                                                  │
│  Teléfono Directo: *                             │
│  [0987654321                               ]    │
│                                                  │
│  [← Atrás]              [Continuar →]           │
└─────────────────────────────────────────────────┘
```

:::tip Correo Corporativo
Usa un correo con el dominio de tu empresa (ej: @tuempresa.com) para mayor credibilidad. No uses correos personales como Gmail o Hotmail.
:::

### Paso 4: Documentación

```
┌─────────────────────────────────────────────────┐
│  Crear Cuenta Empresarial - Documentos          │
├─────────────────────────────────────────────────┤
│                                                  │
│  Por favor, sube los siguientes documentos       │
│  para verificar tu empresa:                      │
│                                                  │
│  RUC de la Empresa: * (PDF, máx 5MB)            │
│  [📄 ruc_empresa.pdf] [✓ Cargado]              │
│  [Cambiar archivo]                              │
│                                                  │
│  Cédula del Representante: * (PDF, máx 5MB)     │
│  [📄 cedula_representante.pdf] [✓ Cargado]     │
│  [Cambiar archivo]                              │
│                                                  │
│  Nombramiento del Representante: (Opcional)      │
│  [Seleccionar archivo...]                        │
│                                                  │
│  Estos documentos serán revisados por el         │
│  administrador antes de aprobar tu cuenta.       │
│                                                  │
│  [← Atrás]              [Continuar →]           │
└─────────────────────────────────────────────────┘
```

**Requisitos de archivos:**
- Formato: Solo PDF
- Tamaño máximo: 5 MB por archivo
- Calidad: Legibles y escaneados correctamente
- Vigencia: Documentos actualizados

### Paso 5: Contraseña y Términos

Similar al registro de usuario, completa:
- Contraseña segura
- Confirmar contraseña
- Aceptar términos y condiciones
- Aceptar política de privacidad

### Paso 6: Revisión Administrativa

```
┌─────────────────────────────────────────────────┐
│  ✓ Solicitud Enviada                             │
├─────────────────────────────────────────────────┤
│                                                  │
│  Tu solicitud ha sido enviada exitosamente.      │
│                                                  │
│  Tu cuenta será revisada por el equipo           │
│  administrativo de EmpleaTec.                    │
│                                                  │
│  ⏱️ Tiempo estimado: 24-48 horas hábiles        │
│                                                  │
│  Recibirás un correo cuando tu cuenta sea:       │
│  • ✅ Aprobada - Podrás acceder completamente   │
│  • ❌ Rechazada - Con motivos y cómo proceder   │
│                                                  │
│  📧 Correo de notificación:                     │
│  m.lopez@techadvance.com                         │
│                                                  │
│  [Ir al Inicio]                                  │
└─────────────────────────────────────────────────┘
```

:::info Revisión Manual
Las cuentas empresariales requieren aprobación manual para garantizar la legitimidad de las ofertas de empleo y proteger a los graduados.
:::

## ✅ Después del Registro

### Para Graduados

Una vez verificada tu cuenta:

1. **Inicia sesión** con tu correo y contraseña
2. **Completa tu perfil** al 100%:
   - Sube tu foto profesional
   - Carga tu CV
   - Agrega experiencia laboral
   - Lista tus habilidades
   - Agrega certificaciones
3. **Configura tus preferencias** laborales
4. **Comienza a buscar** y aplicar a ofertas

### Para Empresas

Después de que tu cuenta sea aprobada:

1. **Inicia sesión** por primera vez
2. **Completa el perfil** de tu empresa:
   - Logo empresarial
   - Descripción atractiva
   - Beneficios que ofreces
   - Cultura organizacional
3. **Publica tu primera oferta** de empleo
4. **Explora la base** de datos de candidatos

## ❗ Problemas Comunes y Soluciones

### No recibí el correo de verificación

**Soluciones:**
1. Espera 5-10 minutos (puede tardar)
2. Revisa tu carpeta de **spam** o **correo no deseado**
3. Verifica que escribiste correctamente tu correo
4. Haz clic en **"Reenviar Correo"** en la pantalla de confirmación
5. Agrega **noreply@serviciosint.com** a tus contactos

### La cédula ya está registrada

**Posibles causas:**
- Ya tienes una cuenta creada anteriormente
- Alguien más usó tu cédula (reporta esto)

**Solución:**
1. Intenta **recuperar tu contraseña**
2. Si no recuerdas haber creado cuenta, contacta soporte
3. Si sospechas uso indebido, reporta inmediatamente

### El correo ya está en uso

**Solución:**
- Usa otro correo electrónico
- O recupera tu cuenta existente si la olvidaste

### Mi RUC no es aceptado (empresas)

**Verificar:**
- Que tengas 13 dígitos
- Que el RUC esté activo en el SRI
- Que sea de una empresa, no persona natural

### Documentos rechazados (empresas)

**Razones comunes:**
- Archivos ilegibles o de mala calidad
- Documentos vencidos
- Información inconsistente
- Formato incorrecto

**Solución:**
- Escanea nuevamente con mejor calidad
- Asegúrate de que sean los documentos correctos
- Verifica que la información coincida
- Contacta soporte si tienes dudas

## 🔒 Seguridad en el Registro

### Protege tu Información

- ✅ Usa una contraseña única para EmpleaTec
- ✅ No compartas tus credenciales con nadie
- ✅ Verifica que estás en el sitio oficial (serviciosint.com)
- ✅ No respondas a correos sospechosos que pidan tu contraseña
- ✅ Cierra sesión en computadoras públicas

### Señales de Phishing

🚨 **NUNCA** confíes en:
- Correos que piden tu contraseña
- Enlaces a sitios que no sean serviciosint.com
- Solicitudes de información bancaria
- Mensajes urgentes amenazando con cerrar tu cuenta

## 📞 ¿Necesitas Ayuda?

Si tienes problemas durante el registro:

- **📧 Correo**: soporte@empleatec.com
- **📱 Teléfono**: [Contacto del Instituto]
- **⏰ Horario**: Lunes a Viernes, 8:00 AM - 5:00 PM
- **💬 Chat en línea**: Disponible en la plataforma

---

**Siguiente paso**: Una vez registrado, aprende a [Iniciar Sesión](./inicio-sesion.md) en tu cuenta.